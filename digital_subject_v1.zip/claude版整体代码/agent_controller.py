# agent_controller.py
"""
数字主体运行控制器
负责启动、停止、重置、状态查询
"""

import threading
import time
import json
import os
import shutil
from datetime import datetime
from typing import Optional, Dict, Any

STATE_DIR = "./agent_state"

class AgentController:
    
    def __init__(self):
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.start_time: Optional[str] = None
        self.stop_flag = threading.Event()
        
        # 缓存的状态（供快速查询）
        self.cached_state = {
            'tick_count': 0,
            'location': 'unknown',
            'recent_actions': [],
            'needs': [],
            'attention': {},
            'active_concerns': 0
        }
    
    def start(self) -> Dict[str, Any]:
        """启动主体"""
        if self.running:
            return {'success': False, 'message': '主体已在运行'}
        
        try:
            # 检查必要文件
            if not os.path.exists(f"{STATE_DIR}/concerns.json"):
                return {'success': False, 'message': '请先配置人格数据'}
            
            # 重置停止标志
            self.stop_flag.clear()
            
            # 启动主循环线程
            self.thread = threading.Thread(target=self._run_loop, daemon=True)
            self.thread.start()
            
            self.running = True
            self.start_time = datetime.now().isoformat()
            
            return {'success': True, 'message': '主体已启动'}
        except Exception as e:
            return {'success': False, 'message': f'启动失败: {str(e)}'}
    
    def pause(self) -> Dict[str, Any]:
        """暂停主体"""
        if not self.running:
            return {'success': False, 'message': '主体未在运行'}
        
        try:
            # 设置停止标志
            self.stop_flag.set()
            
            # 等待线程结束（最多5秒）
            if self.thread:
                self.thread.join(timeout=5.0)
            
            self.running = False
            
            return {'success': True, 'message': '主体已暂停'}
        except Exception as e:
            return {'success': False, 'message': f'暂停失败: {str(e)}'}
    
    def reset(self) -> Dict[str, Any]:
        """重置主体（清除运行状态，保留人格配置）"""
        # 如果正在运行，先停止
        if self.running:
            self.pause()
        
        try:
            # 删除运行状态文件（保留concerns.json）
            files_to_remove = [
                f"{STATE_DIR}/core_state.json",
                f"{STATE_DIR}/goals.json",
                f"{STATE_DIR}/world_observation.json",
                f"{STATE_DIR}/memory/episodic_hot.json",
                f"{STATE_DIR}/memory/episodic_archive.jsonl",
                f"{STATE_DIR}/memory/working.json"
            ]
            
            for file_path in files_to_remove:
                if os.path.exists(file_path):
                    os.remove(file_path)
            
            # 重置缓存状态
            self.cached_state = {
                'tick_count': 0,
                'location': 'unknown',
                'recent_actions': [],
                'needs': [],
                'attention': {},
                'active_concerns': 0
            }
            
            self.start_time = None
            
            return {'success': True, 'message': '主体已重置'}
        except Exception as e:
            return {'success': False, 'message': f'重置失败: {str(e)}'}
    
    def get_status(self) -> Dict[str, Any]:
        """获取当前状态"""
        try:
            # 读取最新状态
            self._update_cached_state()
            
            return {
                'is_running': self.running,
                'start_time': self.start_time,
                'tick_count': self.cached_state['tick_count'],
                'location': self.cached_state['location'],
                'active_concerns': self.cached_state['active_concerns'],
                'recent_actions': self.cached_state['recent_actions'],
                'needs': self.cached_state['needs'],
                'attention': self.cached_state['attention'],
                'system_info': {
                    'config_path': 'config.py',
                    'state_path': STATE_DIR,
                    'last_save': self._get_last_save_time()
                }
            }
        except Exception as e:
            print(f"获取状态失败: {e}")
            return {
                'is_running': self.running,
                'error': str(e)
            }
    
    def export_state(self) -> str:
        """导出状态为zip文件，返回文件路径"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_path = f"agent_state_{timestamp}"
            
            # 打包整个agent_state目录
            shutil.make_archive(zip_path, 'zip', STATE_DIR)
            
            return f"{zip_path}.zip"
        except Exception as e:
            print(f"导出失败: {e}")
            return ""
    
    def _run_loop(self):
        """主循环（在独立线程中运行）"""
        try:
            # 动态导入main模块
            import importlib
            import sys
            
            # 重新加载以获取最新配置
            if 'config' in sys.modules:
                importlib.reload(sys.modules['config'])
            if 'main' in sys.modules:
                importlib.reload(sys.modules['main'])
            
            import main
            
            # 修改main的主循环，使其支持外部停止
            # 这里我们需要改造main.py，添加一个可控制的版本
            self._run_main_with_control()
            
        except Exception as e:
            print(f"主循环异常: {e}")
            self.running = False
    
    def _run_main_with_control(self):
        """
        运行main.py的主循环，但支持外部控制
        这个函数需要和修改后的main.py配合
        """
        import main
        
        # 调用main中的可控循环版本
        main.run_controlled_loop(stop_flag=self.stop_flag, state_callback=self._on_tick_update)
    
    def _on_tick_update(self, state: Dict[str, Any]):
        """每个tick的回调，用于更新缓存"""
        self.cached_state.update(state)
    
    def _update_cached_state(self):
        """从文件系统更新缓存状态"""
        try:
            # 读取core_state
            core_state_path = f"{STATE_DIR}/core_state.json"
            if os.path.exists(core_state_path):
                with open(core_state_path, 'r', encoding='utf-8') as f:
                    core_state = json.load(f)
                
                self.cached_state['tick_count'] = core_state.get('tick_count', 0)
                self.cached_state['needs'] = core_state.get('needs', [])
                self.cached_state['recent_actions'] = [
                    {
                        'ts': line.split('[')[0].strip(),
                        'tag': line.split('[')[1].split(']')[0] if '[' in line else 'unknown',
                        'summary': line.split(']')[1].strip() if ']' in line else line
                    }
                    for line in core_state.get('recent_log', [])[-100:]
                ]
            
            # 读取world_observation
            world_obs_path = f"{STATE_DIR}/world_observation.json"
            if os.path.exists(world_obs_path):
                with open(world_obs_path, 'r', encoding='utf-8') as f:
                    world_obs = json.load(f)
                self.cached_state['location'] = world_obs.get('location', 'unknown')
            
            
            # 读取concerns数量（兼容新旧格式）
            concerns_path = f"{STATE_DIR}/concerns.json"
            if os.path.exists(concerns_path):
                with open(concerns_path, 'r', encoding='utf-8') as f:
                    concerns_data = json.load(f)

                active_deep = 0
                active_current = 0

                if isinstance(concerns_data, dict):
                    deep_list = concerns_data.get("deep_concerns", []) or []
                    current_list = concerns_data.get("current_concerns", []) or []

                    active_deep = sum(
                        1 for c in deep_list
                        if isinstance(c, dict) and c.get("status", "active") == "active"
                    )
                    # current concerns：active + suppressed 都算“仍在起作用/会竞争”
                    active_current = sum(
                        1 for c in current_list
                        if isinstance(c, dict) and c.get("status", "active") in ("active", "suppressed")
                    )

                elif isinstance(concerns_data, list):
                    # 旧版：list[dict]
                    active_deep = sum(
                        1 for c in concerns_data
                        if isinstance(c, dict) and c.get("status", "active") == "active"
                    )
                    active_current = 0

                # 保持你前端字段不变的话：
                self.cached_state["active_concerns"] = active_current if active_current > 0 else active_deep
                # 如果你愿意更清晰，也可以额外给两个字段：
                self.cached_state["active_deep_concerns"] = active_deep
                self.cached_state["active_current_concerns"] = active_current
                    
        except Exception as e:
            print(f"更新缓存状态失败: {e}")
    
    def _get_last_save_time(self) -> str:
        """获取最后保存时间"""
        try:
            core_state_path = f"{STATE_DIR}/core_state.json"
            if os.path.exists(core_state_path):
                mtime = os.path.getmtime(core_state_path)
                return datetime.fromtimestamp(mtime).isoformat()
        except:
            pass
        return "未知"


# 全局单例
controller = AgentController()