# config.py
from __future__ import annotations
import os

# ── LLM ──────────────────────────────────────────
MODEL_DECISION   = os.getenv("MODEL_DECISION",   "deepseek-chat")
MODEL_WORLD      = os.getenv("MODEL_WORLD",      "deepseek-chat")
MODEL_GOAL_GEN   = os.getenv("MODEL_GOAL_GEN",   "deepseek-chat")
BASE_URL         = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
API_KEY          = "请用户自行填写"
# ── 时间 ──────────────────────────────────────────
TICK_SEC              = 30
WORLD_OBSERVE_EVERY   = 3       # 每N tick做一次world observe
GOAL_GEN_EVERY        = 20      # 每N tick做一次目标生成
MEMORY_CONSOLIDATE_EVERY = 60   # 每N tick做一次记忆巩固

# ── 记忆容量 ──────────────────────────────────────
WORKING_MEM_CAPACITY  = 7       # 工作记忆槽位（Miller's Law）
EPISODIC_HOT_KEEP     = 200     # 热episodic（state内）
SEMANTIC_KEEP         = 300
RECENT_KEEP           = 60

# ── 注意竞争 ──────────────────────────────────────
ATTENTION_TOP_K       = 3
CONCERN_MAX_ACTIVE    = 6
GOAL_MAX_ACTIVE       = 10

# ── 反卡死阈值 ────────────────────────────────────
STUCK_REPEAT_TAG      = 5
STUCK_NO_PROGRESS     = 100
STUCK_BOREDOM         = 0.9

# ── 世界拓扑 ──────────────────────────────────────
WORLD_LOCATIONS = [
    "home_bedroom", "home_kitchen", "home_yard",
    "home_toilet",  "home_living",  "outside_gate", "outside_road"
]
WORLD_NEIGHBORS = {
    "home_bedroom": ["home_living", "home_kitchen", "home_toilet"],
    "home_living":  ["home_bedroom", "home_kitchen", "home_yard"],
    "home_kitchen": ["home_living",  "home_yard"],
    "home_yard":    ["home_living",  "outside_gate"],
    "home_toilet":  ["home_bedroom", "home_living"],
    "outside_gate": ["home_yard",    "outside_road"],
    "outside_road": ["outside_gate"],
}
POSTURES = ["lying", "sitting", "standing", "walking"]

# ── Tag → 默认需求效果 ────────────────────────────
TAG_NEED_HEURISTICS = {
    "eat":           {"need_hunger":   (-0.14, True),  "need_stress": (-0.01, False)},
    "drink":         {"need_thirst":   (-0.12, True)},
    "toilet":        {"need_bladder":  (-0.35, True)},
    "rest":          {"need_fatigue":  (-0.12, True),  "need_stress": (-0.06, False)},
    "walk":          {"need_fatigue":  (+0.01, False),  "need_stress": (-0.02, False)},
    "tidy":          {"need_order":    (-0.08, True),   "need_stress": (-0.02, False)},
    "observe":       {"need_curiosity":(-0.06, True),   "need_stress": (-0.01, False)},
    "ruminate":      {"need_stress":   (+0.04, False)},
    "meta_replan":   {"need_stress":   (-0.03, False)},
    "context_change":{"need_stress":   (-0.02, False),  "need_curiosity":(-0.02, False)},
    "recovery":      {"need_stress":   (-0.05, False),  "need_fatigue": (-0.04, False)},
    "social":        {"need_social":   (-0.10, True),   "need_stress":  (-0.03, False)},
    "plan":          {"need_curiosity":(-0.03, False)},
}

import json

def load_identity():
    json_path = "./agent_state/identity.json"
    if os.path.exists(json_path):
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get("identity", "")
    return ""  # 或返回默认值

# ── 身份核心（可被覆盖） ──────────────────────────
DEFAULT_IDENTITY = load_identity()