# main.py
"""
主循环：整合所有模块，驱动30秒认知循环（改造版）
关键改动：
- WorldAgent: 引入 WorldState 真值；affordances规则计算；执行后 apply_action_effect() 让世界收敛
- GoalSystem: ExecutionEvidence 填 world_state_before/after；进度验证更严格
- ConcernSystem: cues 脉冲+冷却；执行证据回灌 observe_execution()
- 修复 repeat_last_tag_count 为“连续重复”而非窗口计数
- 修复 last_action 传参一直是旧值的问题
"""

from __future__ import annotations

import json
import math
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any, Dict, List

from openai import OpenAI

import config as cfg
from modules.world_agent import WorldAgent, WorldObservation
from modules.memory_system import MemorySystem, TickRecord
from modules.concern_system import ConcernSystem, ConcernTickContext
from modules.goal_system import GoalSystem, ExecutionEvidence
from modules.attention import run_attention_competition, AttentionResult


STATE_DIR = "./agent_state"
CORE_STATE_PATH = f"{STATE_DIR}/core_state.json"


# ── 需求（Need）──────────────────────────────────────────────

@dataclass
class Need:
    id: str
    name: str
    level: float = 0.2
    rise_per_min: float = 0.01
    weight: float = 1.0
    satisfied_drop: float = 0.30
    floor: float = 0.0
    ceil: float = 1.0

    def tick(self, dt_sec: float):
        self.level = _clamp(self.level + self.rise_per_min * (dt_sec / 60.0), self.floor, self.ceil)

    def apply_delta(self, delta: float, satisfied: bool, ts: str):
        self.level = _clamp(self.level + delta, self.floor, self.ceil)
        if satisfied:
            self.level = _clamp(self.level - self.satisfied_drop, self.floor, self.ceil)

    def bid(self) -> float:
        return self.weight * (self.level ** 2)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict) -> "Need":
        valid = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in valid})


def default_needs() -> List[Need]:
    return [
        Need("need_hunger",   "饥饿",     level=0.35, rise_per_min=0.010, weight=1.00, satisfied_drop=0.35),
        Need("need_thirst",   "口渴",     level=0.25, rise_per_min=0.008, weight=0.85, satisfied_drop=0.30),
        Need("need_bladder",  "尿意",     level=0.15, rise_per_min=0.006, weight=0.90, satisfied_drop=0.50),
        Need("need_fatigue",  "疲劳",     level=0.30, rise_per_min=0.007, weight=0.95, satisfied_drop=0.25),
        Need("need_stress",   "压力",     level=0.20, rise_per_min=0.004, weight=0.80, satisfied_drop=0.20),
        Need("need_social",   "陪伴",     level=0.25, rise_per_min=0.003, weight=0.55, satisfied_drop=0.20),
        Need("need_order",    "秩序",     level=0.22, rise_per_min=0.0035, weight=0.60, satisfied_drop=0.15),
        Need("need_curiosity","好奇",     level=0.25, rise_per_min=0.0025, weight=0.45, satisfied_drop=0.10),
    ]


# ── 核心状态 ──────────────────────────────────────────────────

def load_core_state() -> Dict[str, Any]:
    if os.path.exists(CORE_STATE_PATH):
        try:
            with open(CORE_STATE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "tick_count": 0,
        "needs": [n.to_dict() for n in default_needs()],
        "loop_guard": {
            "last_tags": [],
            "repeat_last_tag_count": 0,
            "no_progress_ticks": 0,
            "boredom": 0.20,
        },
        "last_action": {},
        "last_location_before": "",
        "last_location_after": "",
        "recent_log": [],
    }


def save_core_state(state: Dict[str, Any]):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(CORE_STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


# ── 决策Prompt ────────────────────────────────────────────────

def build_decision_messages(
    ts: str,
    tick_id: int,
    world_obs: WorldObservation,
    attention: AttentionResult,
    memory: MemorySystem,
    concern_system: ConcernSystem,
    goal_system: GoalSystem,
    needs: List[Need],
    loop_guard: Dict[str, Any],
    recent_log: List[str],
    reflection_mode: bool,
) -> List[Dict[str, str]]:

    needs_sorted = sorted(needs, key=lambda n: n.bid(), reverse=True)
    needs_text = "\n".join([
        f"  {n.id}: {n.name} level={n.level:.2f} (rise={n.rise_per_min:.3f}/min)"
        for n in needs_sorted
    ])
    need_ids = [n.id for n in needs_sorted]

    recent_text = "\n".join(f"  {r}" for r in recent_log[-8:]) or "  （空）"

    boredom = float(loop_guard.get("boredom", 0.2))
    repeat  = int(loop_guard.get("repeat_last_tag_count", 0))
    no_prog = int(loop_guard.get("no_progress_ticks", 0))

    stuck_warning = ""
    if repeat >= cfg.STUCK_REPEAT_TAG or no_prog >= cfg.STUCK_NO_PROGRESS or boredom >= cfg.STUCK_BOREDOM:
        stuck_warning = (
            "\n[ANTI-STUCK]\n"
            f"repeat={repeat} no_progress={no_prog} boredom={boredom:.2f}\n"
            "你必须把 action.tag 设为 meta_replan / context_change / recovery 之一，用于跳出反刍。\n"
        )

    reflection_note = ""
    if reflection_mode:
        reflection_note = (
            "\n[reflection_mode=true] 允许输出 concern_ops（deep/current 两层）。\n"
            "关切通常稳定，只在有充分理由时才变更。\n"
        )

    system = f"""
你是一个以30秒为时间步运行的数字认知主体控制器。

【角色】
{cfg.DEFAULT_IDENTITY}

【硬约束】
1. 只输出一个严格JSON对象，不含任何解释文字。
2. action.duration_sec <= 30，只有一个微行动。
3. 不能假装使用外部工具（上网/发消息/控设备）。
4. goal_ops.progress 的 goal_id 必须来自下方 [活跃目标] 列表。
5. concern_ops 只在 reflection_mode=true 时才输出。
6. effects.need_updates 中 need_id 必须来自该列表：{need_ids}
7. effects.need_updates 最多2条；每条 |delta|<=0.18；总 |delta|<=0.25。
8. internal/plan/observe 类型动作不得显著降低 need_hunger/need_thirst/need_bladder（除非极小调整<=0.01）。
9. 记忆系统由系统自动事件化编码与巩固，你无需输出 memory_ops。
{stuck_warning}{reflection_note}

【世界观察】（affordances来自世界真值计算；system_state_hint反映少量可收敛真值）
{world_obs.to_prompt_text()}

【注意竞争】
{attention.to_prompt_text()}

【需求状态】
{needs_text}

【关切系统（深层+当前关切）】
{concern_system.to_prompt_text()}

【活跃目标】（进度更新必须引用此处的goal_id）
{goal_system.to_prompt_text()}

【记忆（事件化摘要）】
{memory.to_prompt_text(max_chars=2000)}

【最近行动】
{recent_text}

【循环状态】
tick={tick_id} boredom={boredom:.2f} repeat_tag={repeat} no_progress={no_prog}
推荐tag: {attention.recommended_tag}

【输出JSON Schema】
{{
  "action": {{
    "summary": "下一步微行动（<=30秒，单一具体）",
    "duration_sec": 30,
    "type": "internal|physical|social|wait",
    "tag": "eat|drink|toilet|rest|walk|tidy|observe|plan|social|meta_replan|context_change|recovery|other"
  }},
  "effects": {{
    "need_updates": [
      {{"need_id":"need_thirst","delta":-0.06,"satisfied":false,"reason":"为什么会变化"}}
    ],
    "boredom_delta": -0.02
  }},
  "world_patch": {{
    "location": "（可选，必须相邻）",
    "posture":  "（可选）"
  }},
  "goal_ops": {{
    "progress": [{{"goal_id":"goal_xxx","delta":0.05,"note":"证据：做了哪步"}}],
    "update":   [{{"goal_id":"goal_xxx","next_action":"下一步...","blocked_reason":""}}],
    "done":     ["goal_xxx"],
    "add":      [{{"current_concern_id":"cc_xxx","deep_concern_id":"con_xxx","title":"...","success_criteria":"...","priority":0.5,"next_action":"...","evidence_requirements":{{"tags_any":["drink"]}}}}]
  }},
  "concern_ops": {{
    "deep_update": [{{"concern_id":"con_xxx","notes":"...","importance":0.7}}],
    "deep_add":    [{{"title":"...","domain":"...","importance":0.5,"description":"...","context_triggers":[]}}],
    "deep_retire": [{{"concern_id":"con_xxx","reason":"..."}}],
    "current_update":   [{{"cc_id":"cc_xxx","tension":0.6,"suppression":0.2,"urgency":0.4,"evidence_notes":"..."}}],
    "current_add":      [{{"deep_concern_id":"con_xxx","title":"...","description":"...","tension":0.4,"urgency":0.2}}],
    "current_suppress": [{{"cc_id":"cc_xxx","amount":0.2}}],
    "current_resolve":  ["cc_xxx"]
  }},
  "meta": {{
    "chosen_focus_ids": ["top_foci中的id，至少1个"],
    "conflict_note":    "一句话说明注意力取舍",
    "why_now":          "一句话说明为什么现在做这个",
    "uncertainty":      "一句话说明当前最大不确定"
  }}
}}
""".strip()

    return [
        {"role": "system", "content": system},
        {"role": "user",   "content": f"现在是 {ts}（tick {tick_id}）。输出下一步微行动JSON。"}
    ]


# ── Need更新校验 ──────────────────────────────────────────────

def _validate_and_cap_need_update(
    *,
    need_id: str,
    delta: float,
    satisfied: bool,
    action_tag: str,
    action_type: str,
    duration_sec: float,
    world_obs: WorldObservation,
    patch_ok: bool,
) -> tuple[float, bool, str]:
    delta = float(delta)
    max_abs = 0.18 * (duration_sec / cfg.TICK_SEC)
    delta = _clamp(delta, -max_abs, +max_abs)

    if action_type in ("internal", "wait") and need_id in ("need_hunger", "need_thirst", "need_bladder"):
        if delta < -0.01:
            return (-0.01, False, "non-physical action cannot relieve core physiological need")

    if patch_ok is False:
        if delta < -0.03:
            delta = -0.03
        satisfied = False

    aff = set((world_obs.affordances or []) if world_obs else [])
    loc = (world_obs.location or "") if world_obs else ""

    plausible: Dict[str, set[str]] = {
        "drink": {"need_thirst", "need_stress"},
        "eat": {"need_hunger", "need_stress"},
        "toilet": {"need_bladder", "need_stress"},
        "rest": {"need_fatigue", "need_stress"},
        "tidy": {"need_order", "need_stress"},
        "walk": {"need_stress", "need_curiosity"},
        "observe": {"need_curiosity", "need_stress"},
        "plan": {"need_order", "need_stress"},
        "social": {"need_social", "need_stress"},
        "recovery": {"need_stress"},
        "context_change": {"need_stress", "need_curiosity"},
        "meta_replan": {"need_order", "need_stress"},
    }
    allowed_needs = plausible.get(action_tag, set())
    if allowed_needs and need_id not in allowed_needs:
        if abs(delta) > 0.01:
            return (0.0, False, f"need_id not plausible for tag={action_tag}")

    if satisfied:
        sat_ok = False
        if action_tag == "drink" and need_id == "need_thirst" and ("drink_water" in aff or "home_kitchen" in loc):
            sat_ok = True
        if action_tag == "eat" and need_id == "need_hunger" and ("check_food" in aff or "home_kitchen" in loc):
            sat_ok = True
        if action_tag == "toilet" and need_id == "need_bladder" and ("use_toilet" in aff or "home_toilet" in loc):
            sat_ok = True
        if action_tag == "rest" and need_id == "need_fatigue":
            sat_ok = True
        if not sat_ok:
            satisfied = False

    per_need_floor = {
        "need_thirst": -0.12,
        "need_hunger": -0.10,
        "need_bladder": -0.18,
        "need_fatigue": -0.12,
        "need_stress": -0.10,
        "need_order": -0.10,
        "need_social": -0.08,
        "need_curiosity": -0.06,
    }
    min_delta = per_need_floor.get(need_id, -0.10) * (duration_sec / cfg.TICK_SEC)
    if delta < min_delta:
        delta = min_delta

    return (delta, satisfied, "ok")


def _count_trailing_same(xs: List[str]) -> int:
    if not xs:
        return 0
    last = xs[-1]
    c = 1
    for x in reversed(xs[:-1]):
        if x == last:
            c += 1
        else:
            break
    return c


# ── 应用模型输出 ──────────────────────────────────────────────

def apply_decision(
    decision: Dict[str, Any],
    ts: str,
    tick_id: int,
    needs: List[Need],
    world_agent: WorldAgent,
    memory: MemorySystem,
    concern_system: ConcernSystem,
    goal_system: GoalSystem,
    loop_guard: Dict[str, Any],
    world_obs: WorldObservation,
    reflection_mode: bool,
) -> Dict[str, Any]:

    action = decision.get("action") or {}
    tag     = str(action.get("tag","other")).strip() or "other"
    summary = str(action.get("summary","")).strip()[:300] or "等待/观察"
    a_type  = str(action.get("type","internal")).strip()
    if a_type not in ("internal","physical","social","wait"):
        a_type = "internal"
    try:
        duration = float(action.get("duration_sec", cfg.TICK_SEC))
        duration = _clamp(duration, 1, cfg.TICK_SEC)
    except Exception:
        duration = cfg.TICK_SEC

    # pre-state snapshots (evidence + realism)
    world_state_before = world_agent.state_snapshot()
    loc_before = world_state_before.get("location", world_agent.current.location)
    needs_before = {n.id: n.level for n in needs}
    boredom_before = float(loop_guard.get("boredom", 0.2))

    boredom   = float(loop_guard.get("boredom", 0.2))
    repeat    = int(loop_guard.get("repeat_last_tag_count", 0))
    no_prog   = int(loop_guard.get("no_progress_ticks", 0))
    must_break = (
        repeat  >= cfg.STUCK_REPEAT_TAG or
        no_prog >= cfg.STUCK_NO_PROGRESS or
        boredom >= cfg.STUCK_BOREDOM
    )

    if must_break and tag not in ("meta_replan","context_change","recovery"):
        tag     = "meta_replan"
        summary = f"[系统强制重规划] 原计划：{summary[:60]}"
        a_type  = "internal"
        # 强制重规划：把外部承诺字段清空，避免“语义撕裂”
        decision["goal_ops"] = {"progress": [], "update": [], "done": [], "add": []}
        decision["effects"] = {"need_updates": [], "boredom_delta": -0.02}
        decision["world_patch"] = {}

    # world patch（只改 location/posture）
    world_patch = decision.get("world_patch") or {}
    patch_ok = world_agent.apply_action_patch(world_patch)

    # 执行动作对世界真值的影响（关键：让 tidy 收敛）
    world_agent.apply_action_effect(tag=tag, duration_sec=duration, patch_ok=bool(patch_ok))
    world_state_after = world_agent.state_snapshot()

    # 用动作后世界作为 need 更新的可供性校验（更合理）
    world_obs_for_validation = world_agent.current

    # needs updates (LLM direct)
    need_by_id = {n.id: n for n in needs}
    updates = (decision.get("effects") or {}).get("need_updates") or []
    applied_any = False

    total_abs_cap = 0.25 * (duration / cfg.TICK_SEC)
    total_abs = 0.0

    if isinstance(updates, list):
        for item in updates[:2]:
            if not isinstance(item, dict):
                continue
            nid = str(item.get("need_id", "")).strip()
            if nid not in need_by_id:
                continue
            try:
                delta = float(item.get("delta", 0.0))
            except Exception:
                continue
            satisfied = bool(item.get("satisfied", False))

            if total_abs >= total_abs_cap:
                continue

            delta2, sat2, _ = _validate_and_cap_need_update(
                need_id=nid,
                delta=delta,
                satisfied=satisfied,
                action_tag=tag,
                action_type=a_type,
                duration_sec=duration,
                world_obs=world_obs_for_validation,
                patch_ok=bool(patch_ok),
            )

            if abs(delta2) > 1e-9:
                remain = max(0.0, total_abs_cap - total_abs)
                if abs(delta2) > remain:
                    delta2 = math.copysign(remain, delta2)

                need_by_id[nid].apply_delta(delta2, satisfied=sat2, ts=ts)
                total_abs += abs(delta2)
                applied_any = True

    # fallback heuristic ONLY if LLM didn't apply any need update
    if not applied_any and tag in getattr(cfg, "TAG_NEED_HEURISTICS", {}):
        for nid, (delta, satisfied) in cfg.TAG_NEED_HEURISTICS[tag].items():
            if nid in need_by_id:
                need_by_id[nid].apply_delta(float(delta) * (duration / cfg.TICK_SEC), satisfied=bool(satisfied), ts=ts)

    # boredom update
    try:
        boredom_delta = float((decision.get("effects") or {}).get("boredom_delta") or 0.0)
    except Exception:
        boredom_delta = 0.0

    last_tags = loop_guard.get("last_tags", []) or []
    if last_tags and last_tags[-1] == tag:
        boredom = _clamp(boredom + 0.025, 0.0, 1.0)
    else:
        boredom = _clamp(boredom - 0.015, 0.0, 1.0)
    boredom = _clamp(boredom + boredom_delta, 0.0, 1.0)

    last_tags.append(tag)
    if len(last_tags) > 10:
        last_tags = last_tags[-10:]
    repeat_new = _count_trailing_same(last_tags)

    # post-state for evidence
    loc_after = world_state_after.get("location", world_agent.current.location)
    needs_after = {n.id: n.level for n in needs}
    boredom_after = boredom

    # chosen focus ids
    chosen_focus_ids = list(((decision.get("meta") or {}).get("chosen_focus_ids")) or [])
    chosen_focus_goal_ids = [x for x in chosen_focus_ids if isinstance(x, str) and x.startswith("goal_")]
    chosen_focus_cc_ids   = [x for x in chosen_focus_ids if isinstance(x, str) and x.startswith("cc_")]

    # goal ops with evidence verification
    goal_ops = decision.get("goal_ops") or {}
    ev = ExecutionEvidence(
        ts=ts,
        tick_id=tick_id,
        action_tag=tag,
        action_summary=summary,
        patch_ok=bool(patch_ok),
        location_before=str(loc_before),
        location_after=str(loc_after),
        needs_before=needs_before,
        needs_after=needs_after,
        boredom_before=boredom_before,
        boredom_after=boredom_after,
        chosen_focus_goal_ids=chosen_focus_goal_ids[:4],
        chosen_focus_cc_ids=chosen_focus_cc_ids[:4],
        world_state_before=world_state_before,
        world_state_after=world_state_after,
    )

    goal_stats = goal_system.apply_ops(goal_ops, ts, evidence=ev)
    progressed = goal_stats.get("progressed", 0) > 0 or goal_stats.get("done", 0) > 0

    goal_system.observe_execution(ts, ev, auto_for_focused=True)

    # no_progress update
    no_prog_new = 0 if progressed else int(loop_guard.get("no_progress_ticks", 0)) + 1
    loop_guard.update({
        "last_tags": last_tags,
        "repeat_last_tag_count": repeat_new,
        "no_progress_ticks": no_prog_new,
        "boredom": boredom,
    })

    # concern ops (LLM reflection)
    concern_ops = decision.get("concern_ops") or {}
    concern_stats = concern_system.apply_ops(concern_ops, ts, reflection_mode=reflection_mode)

    # ✅ 执行证据回灌给 concern：做完就降温（关键刹车）
    concern_system.observe_execution(ts, ev, goal_stats=goal_stats)

    # ✅ 事件化记忆 TickRecord
    active_goal_ids = [g.goal_id for g in goal_system.active_goals(3)]
    active_cc_ids = [cc.cc_id for cc in concern_system.active_current_concerns(3)]

    tick_rec = TickRecord(
        ts=ts,
        tick_id=tick_id,
        location=str(loc_after),
        time_of_day=getattr(world_obs, "time_of_day", "") or "",
        world_events=list(getattr(world_obs, "events", []) or []),
        blocked_by=list(getattr(world_obs, "blocked_by", []) or []),
        uncertainty_notes=list(getattr(world_obs, "uncertainty_notes", []) or []),

        action_tag=tag,
        action_summary=summary,
        action_type=a_type,
        patch_ok=bool(patch_ok),

        chosen_focus_ids=chosen_focus_ids[:6],

        goal_ids=active_goal_ids,
        current_concern_ids=active_cc_ids,

        needs_before=needs_before,
        needs_after=needs_after,
        boredom_before=boredom_before,
        boredom_after=boredom_after,

        goal_progressed=int(goal_stats.get("progressed", 0)),
        goal_done=int(goal_stats.get("done", 0)),
    )

    maybe_event = memory.observe_tick(tick_rec, use_llm_finalize=True)
    encoded_event = maybe_event is not None

    return {
        "tag": tag,
        "summary": summary,
        "type": a_type,
        "duration": duration,
        "patch_ok": patch_ok,
        "loc_before": loc_before,
        "loc_after": loc_after,
        "goal_stats": goal_stats,
        "concern_stats": concern_stats,
        "encoded": encoded_event,
        "progressed": progressed,
        "must_break": must_break,
    }


# ── Fallback ──────────────────────────────────────────────────

def build_fallback_decision(
    needs: List[Need],
    world_obs: WorldObservation,
    ts: str,
) -> Dict[str, Any]:
    needs_sorted = sorted(needs, key=lambda n: n.bid(), reverse=True)
    top = needs_sorted[0] if needs_sorted else None

    tag_map = {
        "need_thirst":  ("drink",   "找杯子喝两口水。", "need_thirst"),
        "need_hunger":  ("eat",     "往厨房方向挪一步，找点吃的。", "need_hunger"),
        "need_bladder": ("toilet",  "起身朝厕所方向走几步。", "need_bladder"),
        "need_fatigue": ("rest",    "坐稳/躺下，做三次缓慢呼吸。", "need_fatigue"),
        "need_order":   ("tidy",    "把眼前最碍事的一件东西归位。", "need_order"),
        "need_stress":  ("recovery","停下来，做三次深呼吸，把注意收回来。", "need_stress"),
    }

    if top and top.id in tag_map:
        tag, summary, nid = tag_map[top.id]
    else:
        tag, summary, nid = "observe", "环顾四周10秒，确认下一步最容易推进的事。", "need_curiosity"

    return {
        "action": {"summary": summary, "duration_sec": 30, "type": "physical", "tag": tag},
        "effects": {
            "need_updates": [{"need_id": nid, "delta": -0.03, "satisfied": False, "reason": "fallback"}],
            "boredom_delta": -0.02
        },
        "world_patch": {},
        "goal_ops": {"progress": [], "update": [], "done": [], "add": []},
        "concern_ops": {},
        "meta": {
            "chosen_focus_ids": [],
            "conflict_note": "LLM不可用，优先处理最高urgency需求",
            "why_now": "系统保活",
            "uncertainty": "LLM输出失败",
        }
    }


# ── 主循环 ────────────────────────────────────────────────────

def main():
    api_key = cfg.API_KEY
    if not api_key:
        raise RuntimeError("请设置环境变量 DEEPSEEK_API_KEY")

    client = OpenAI(api_key=api_key, base_url=cfg.BASE_URL)

    world_agent    = WorldAgent(client, STATE_DIR)
    memory         = MemorySystem(STATE_DIR, client)
    concern_system = ConcernSystem(STATE_DIR)
    goal_system    = GoalSystem(STATE_DIR, client)

    core = load_core_state()
    needs = [Need.from_dict(d) for d in core.get("needs", [])]
    if not needs:
        needs = default_needs()

    loop_guard   = core.get("loop_guard", {})
    recent_log   = core.get("recent_log", [])
    tick_count   = int(core.get("tick_count", 0))

    last_action = core.get("last_action", {}) or {}
    last_loc_before = str(core.get("last_location_before", "") or "")
    last_loc_after  = str(core.get("last_location_after", "") or "")

    print("=== 数字认知主体启动（改造版） ===")
    print(f"状态目录: {STATE_DIR}")
    print(f"当前tick: {tick_count}")
    print(f"deep concerns: {len(concern_system.deep_concerns)} | current concerns: {len(concern_system.current_concerns)}")
    print(f"目标数量: {len(goal_system.goals)}")

    while True:
        now = time.time()
        t_next = math.ceil(now / cfg.TICK_SEC) * cfg.TICK_SEC
        time.sleep(max(0.0, t_next - now))

        ts = datetime.now().astimezone().isoformat(timespec="seconds")
        tick_count += 1

        # 1) internal dynamics
        for n in needs:
            n.tick(cfg.TICK_SEC)

        memory.tick_working_mem(cfg.TICK_SEC)

        boredom  = float(loop_guard.get("boredom", 0.2))
        no_prog  = int(loop_guard.get("no_progress_ticks", 0))
        reflection_mode = (
            tick_count % cfg.MEMORY_CONSOLIDATE_EVERY == 0
            or no_prog >= 25
            or boredom >= 0.85
        )

        # 2) world observe (periodic render)
        do_world_obs = (tick_count % cfg.WORLD_OBSERVE_EVERY == 0)
        if do_world_obs:
            world_obs = world_agent.observe(
                ts=ts,
                tick_id=tick_count,
                core_state={"needs": [n.to_dict() for n in needs]},
                last_action=last_action,
                use_llm=True,
            )
        else:
            world_obs = world_agent.current

        # 2.5) concern tick (with pulse/cooldown cues + world_state hint)
        needs_snapshot = {n.id: n.level for n in needs}

        recent_tags = loop_guard.get("last_tags", []) or []
        last_tag = recent_tags[-1] if recent_tags else ""
        prev_tag = recent_tags[-2] if len(recent_tags) >= 2 else ""
        last_tag_changed = bool(last_tag and prev_tag and last_tag != prev_tag)

        location_changed = bool(last_loc_before and last_loc_after and last_loc_before != last_loc_after)

        ctx = ConcernTickContext(
            ts=ts,
            tick_id=tick_count,
            dt_sec=cfg.TICK_SEC,
            location=world_obs.location,
            prev_location=last_loc_before,
            location_changed=location_changed,
            time_of_day=getattr(world_obs, "time_of_day", ""),
            recent_tags=recent_tags,
            last_action_tag=str(last_action.get("tag", "") or last_tag),
            last_action_tag_changed=last_tag_changed,
            needs=needs_snapshot,
            boredom=float(loop_guard.get("boredom", 0.2)),
            no_progress_ticks=int(loop_guard.get("no_progress_ticks", 0)),
            surprise=0.0,
            patch_ok=last_action.get("patch_ok", None),
            goal_blocked=[],
            goal_progressed=[],
            world_state=world_agent.state_snapshot(),
        )
        concern_system.tick(ctx)

        # 3) goal generation (periodic) from current concerns
        if tick_count % cfg.GOAL_GEN_EVERY == 0:
            current_cc = concern_system.active_current_concerns(4)
            needs_brief = "\n".join(f"  {n.name}: {n.level:.2f}" for n in needs if n.level > 0.35)
            mem_brief = memory.to_prompt_text(max_chars=520)
            deep_map = {dc.concern_id: dc for dc in concern_system.deep_concerns_active()}

            goal_system.generate_from_current_concerns(
                current_concerns=current_cc,
                deep_concerns=deep_map,
                world_obs=world_obs,
                needs_brief=needs_brief,
                memory_brief=mem_brief,
                ts=ts,
                use_llm=True,
            )

        # 4) attention competition
        current_cc = concern_system.active_current_concerns()
        cc_tension_by_id = {cc.cc_id: cc.tension for cc in current_cc}

        attention = run_attention_competition(
            needs=needs,
            current_concerns=current_cc,
            goals=goal_system.active_goals(cc_tension_by_id=cc_tension_by_id),
            working_mem=memory.working_mem,
            world_obs=world_obs,
            loop_guard=loop_guard,
        )

        # 5) memory retrieve
        query_text = " ".join([f["label"] for f in attention.top_foci[:2]] + [world_obs.location])

        cue_goal_ids = [f["id"] for f in attention.top_foci if f.get("layer") == "goal"][:2]
        cue_cc_ids = [f["id"] for f in attention.top_foci if f.get("layer") == "cc"][:2]

        retrieved = memory.retrieve_events(
            query_text=query_text,
            tick_id=tick_count,
            now_ts=ts,
            cue_goal_ids=cue_goal_ids,
            cue_cc_ids=cue_cc_ids,
            cue_location=world_obs.location,
            query_affect=None,
            top_k=5,
        )
        for score, ev in retrieved[:3]:
            memory.push_working(ev.gist, "episodic", ev.event_id, activation=score * 0.9, ts=ts)

        for sem in memory.retrieve_semantic(query_text, top_k=3):
            memory.push_working(sem.proposition, "semantic", sem.sem_id, activation=0.55 * float(sem.confidence), ts=ts)

        for opt in memory.retrieve_options(query_text, top_k=2):
            memory.push_working(f"[选项] {opt.cue} → {opt.action_tag}: {opt.action_template}", "option", opt.opt_id, activation=0.45 * float(opt.reliability), ts=ts)

        # 6) decision
        messages = build_decision_messages(
            ts=ts,
            tick_id=tick_count,
            world_obs=world_obs,
            attention=attention,
            memory=memory,
            concern_system=concern_system,
            goal_system=goal_system,
            needs=needs,
            loop_guard=loop_guard,
            recent_log=recent_log,
            reflection_mode=reflection_mode,
        )

        try:
            resp = client.chat.completions.create(
                model=cfg.MODEL_DECISION,
                messages=messages,
                stream=False,
                temperature=0.55,
            )
            raw = resp.choices[0].message.content or ""
            decision = _safe_extract_json(raw)
        except Exception as e:
            err_str = f"LLM失败: {type(e).__name__}: {str(e)[:120]}"
            recent_log.append(f"{ts} [ERROR] {err_str}")
            decision = build_fallback_decision(needs, world_obs, ts)

        # 7) apply decision
        exec_summary = apply_decision(
            decision=decision,
            ts=ts,
            tick_id=tick_count,
            needs=needs,
            world_agent=world_agent,
            memory=memory,
            concern_system=concern_system,
            goal_system=goal_system,
            loop_guard=loop_guard,
            world_obs=world_obs,
            reflection_mode=reflection_mode,
        )

        # update last_action + last locations for next tick context
        last_action = {
            "ts": ts,
            "tag": exec_summary["tag"],
            "summary": exec_summary["summary"],
            "duration_sec": exec_summary["duration"],
            "patch_ok": bool(exec_summary["patch_ok"]),
        }
        last_loc_before = str(exec_summary.get("loc_before", "") or "")
        last_loc_after  = str(exec_summary.get("loc_after", "") or "")

        # goal forgetting tick
        current_cc2 = concern_system.active_current_concerns()
        cc_ids2 = [cc.cc_id for cc in current_cc2]
        cc_ten2 = {cc.cc_id: cc.tension for cc in current_cc2}
        goal_system.tick(ts, active_current_concern_ids=cc_ids2, cc_tension_by_id=cc_ten2)

        # 8) consolidate (blocking LLM extract)
        if tick_count % cfg.MEMORY_CONSOLIDATE_EVERY == 0:
            memory.consolidate(ts)

        # 9) recent log
        log_entry = (
            f"{ts} [{exec_summary['tag']}] {exec_summary['summary'][:80]} "
            f"| prog={exec_summary['progressed']} ev_enc={exec_summary['encoded']}"
        )
        recent_log.append(log_entry)
        if len(recent_log) > cfg.RECENT_KEEP:
            recent_log = recent_log[-cfg.RECENT_KEEP:]

        # 10) persist
        core_state_out = {
            "tick_count": tick_count,
            "needs": [n.to_dict() for n in needs],
            "loop_guard": loop_guard,
            "last_action": last_action,
            "last_location_before": last_loc_before,
            "last_location_after": last_loc_after,
            "recent_log": recent_log,
        }
        save_core_state(core_state_out)
        memory.save()
        concern_system.save()
        goal_system.save()

        # 11) console
        guard = loop_guard
        loc = world_agent.current.location
        print(
            f"{ts} | tick={tick_count} loc={loc} | "
            f"tag={exec_summary['tag']} "
            f"rep={guard.get('repeat_last_tag_count',0)} "
            f"np={guard.get('no_progress_ticks',0)} "
            f"bor={float(guard.get('boredom',0.2)):.2f}"
            f"{' [STUCK→REPLAN]' if exec_summary['must_break'] else ''}"
            f" | {exec_summary['summary'][:60]}"
        )


# ── 工具函数 ──────────────────────────────────────────────────

def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def _safe_extract_json(text: str) -> Dict[str, Any]:
    import json as _json
    text = (text or "").strip()
    try:
        return _json.loads(text)
    except Exception:
        pass
    s = text.find("{")
    e = text.rfind("}")
    if s >= 0 and e > s:
        return _json.loads(text[s:e+1])
    raise ValueError("No valid JSON found in LLM output")


def run_controlled_loop(stop_flag, state_callback=None):
    """
    可控的主循环版本（同步改造版逻辑）
    """
    api_key = cfg.API_KEY
    if not api_key:
        raise RuntimeError("请设置环境变量 DEEPSEEK_API_KEY")

    client = OpenAI(api_key=api_key, base_url=cfg.BASE_URL)

    world_agent    = WorldAgent(client, STATE_DIR)
    memory         = MemorySystem(STATE_DIR, client)
    concern_system = ConcernSystem(STATE_DIR)
    goal_system    = GoalSystem(STATE_DIR, client)

    core = load_core_state()
    needs = [Need.from_dict(d) for d in core.get("needs", [])]
    if not needs:
        needs = default_needs()
    loop_guard   = core.get("loop_guard", {})
    recent_log   = core.get("recent_log", [])
    tick_count   = int(core.get("tick_count", 0))

    last_action = core.get("last_action", {}) or {}
    last_loc_before = str(core.get("last_location_before", "") or "")
    last_loc_after  = str(core.get("last_location_after", "") or "")

    print("=== 数字认知主体启动（可控模式/改造版）===")

    while not stop_flag.is_set():
        now = time.time()
        t_next = math.ceil(now / cfg.TICK_SEC) * cfg.TICK_SEC
        time.sleep(max(0.0, t_next - now))

        ts = datetime.now().astimezone().isoformat(timespec="seconds")
        tick_count += 1

        for n in needs:
            n.tick(cfg.TICK_SEC)
        memory.tick_working_mem(cfg.TICK_SEC)

        boredom  = float(loop_guard.get("boredom", 0.2))
        no_prog  = int(loop_guard.get("no_progress_ticks", 0))
        reflection_mode = (
            tick_count % cfg.MEMORY_CONSOLIDATE_EVERY == 0
            or no_prog >= 25
            or boredom >= 0.85
        )

        do_world_obs = (tick_count % cfg.WORLD_OBSERVE_EVERY == 0)
        if do_world_obs:
            world_obs = world_agent.observe(
                ts=ts,
                tick_id=tick_count,
                core_state={"needs": [n.to_dict() for n in needs]},
                last_action=last_action,
                use_llm=True,
            )
        else:
            world_obs = world_agent.current

        # concern tick
        needs_snapshot = {n.id: n.level for n in needs}
        recent_tags = loop_guard.get("last_tags", []) or []
        last_tag = recent_tags[-1] if recent_tags else ""
        prev_tag = recent_tags[-2] if len(recent_tags) >= 2 else ""
        last_tag_changed = bool(last_tag and prev_tag and last_tag != prev_tag)

        location_changed = bool(last_loc_before and last_loc_after and last_loc_before != last_loc_after)

        ctx = ConcernTickContext(
            ts=ts,
            tick_id=tick_count,
            dt_sec=cfg.TICK_SEC,
            location=world_obs.location,
            prev_location=last_loc_before,
            location_changed=location_changed,
            time_of_day=getattr(world_obs, "time_of_day", ""),
            recent_tags=recent_tags,
            last_action_tag=str(last_action.get("tag", "") or last_tag),
            last_action_tag_changed=last_tag_changed,
            needs=needs_snapshot,
            boredom=float(loop_guard.get("boredom", 0.2)),
            no_progress_ticks=int(loop_guard.get("no_progress_ticks", 0)),
            surprise=0.0,
            patch_ok=last_action.get("patch_ok", None),
            goal_blocked=[],
            goal_progressed=[],
            world_state=world_agent.state_snapshot(),
        )
        concern_system.tick(ctx)

        # goal gen
        if tick_count % cfg.GOAL_GEN_EVERY == 0:
            current_cc = concern_system.active_current_concerns(4)
            needs_brief = "\n".join(f"  {n.name}: {n.level:.2f}" for n in needs if n.level > 0.35)
            mem_brief = memory.to_prompt_text(max_chars=520)
            deep_map = {dc.concern_id: dc for dc in concern_system.deep_concerns_active()}
            goal_system.generate_from_current_concerns(
                current_concerns=current_cc,
                deep_concerns=deep_map,
                world_obs=world_obs,
                needs_brief=needs_brief,
                memory_brief=mem_brief,
                ts=ts,
                use_llm=True,
            )

        # attention
        current_cc = concern_system.active_current_concerns()
        cc_tension_by_id = {cc.cc_id: cc.tension for cc in current_cc}
        attention = run_attention_competition(
            needs=needs,
            current_concerns=current_cc,
            goals=goal_system.active_goals(cc_tension_by_id=cc_tension_by_id),
            working_mem=memory.working_mem,
            world_obs=world_obs,
            loop_guard=loop_guard,
        )

        # decision
        messages = build_decision_messages(
            ts=ts,
            tick_id=tick_count,
            world_obs=world_obs,
            attention=attention,
            memory=memory,
            concern_system=concern_system,
            goal_system=goal_system,
            needs=needs,
            loop_guard=loop_guard,
            recent_log=recent_log,
            reflection_mode=reflection_mode,
        )

        try:
            resp = client.chat.completions.create(
                model=cfg.MODEL_DECISION,
                messages=messages,
                stream=False,
                temperature=0.55,
            )
            raw = resp.choices[0].message.content or ""
            decision = _safe_extract_json(raw)
        except Exception as e:
            err_str = f"LLM失败: {type(e).__name__}: {str(e)[:120]}"
            recent_log.append(f"{ts} [ERROR] {err_str}")
            decision = build_fallback_decision(needs, world_obs, ts)

        exec_summary = apply_decision(
            decision=decision,
            ts=ts,
            tick_id=tick_count,
            needs=needs,
            world_agent=world_agent,
            memory=memory,
            concern_system=concern_system,
            goal_system=goal_system,
            loop_guard=loop_guard,
            world_obs=world_obs,
            reflection_mode=reflection_mode,
        )

        last_action = {
            "ts": ts,
            "tag": exec_summary["tag"],
            "summary": exec_summary["summary"],
            "duration_sec": exec_summary["duration"],
            "patch_ok": bool(exec_summary["patch_ok"]),
        }
        last_loc_before = str(exec_summary.get("loc_before", "") or "")
        last_loc_after  = str(exec_summary.get("loc_after", "") or "")

        # goal forgetting
        current_cc2 = concern_system.active_current_concerns()
        cc_ids2 = [cc.cc_id for cc in current_cc2]
        cc_ten2 = {cc.cc_id: cc.tension for cc in current_cc2}
        goal_system.tick(ts, active_current_concern_ids=cc_ids2, cc_tension_by_id=cc_ten2)

        if tick_count % cfg.MEMORY_CONSOLIDATE_EVERY == 0:
            memory.consolidate(ts)

        log_entry = (
            f"{ts} [{exec_summary['tag']}] {exec_summary['summary'][:80]} "
            f"| prog={exec_summary['progressed']} ev_enc={exec_summary['encoded']}"
        )
        print(log_entry)
        recent_log.append(log_entry)
        if len(recent_log) > cfg.RECENT_KEEP:
            recent_log = recent_log[-cfg.RECENT_KEEP:]

        core_state_out = {
            "tick_count": tick_count,
            "needs": [n.to_dict() for n in needs],
            "loop_guard": loop_guard,
            "last_action": last_action,
            "last_location_before": last_loc_before,
            "last_location_after": last_loc_after,
            "recent_log": recent_log,
        }
        save_core_state(core_state_out)
        memory.save()
        concern_system.save()
        goal_system.save()

        if state_callback:
            state_callback({
                "tick_count": tick_count,
                "location": world_agent.current.location,
                "needs": [n.to_dict() for n in needs],
                "recent_actions": recent_log[-5:] if recent_log else [],
            })

    print("=== 主体已停止 ===")


if __name__ == "__main__":
    main()