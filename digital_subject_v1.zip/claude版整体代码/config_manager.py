# config_manager.py
"""
配置文件读写管理（改造版）
- 支持动态加载 config.py 参数
- 支持读取/写入人格相关 JSON（identity / concerns / needs / semantic）
- 与改造版 ConcernSystem / GoalSystem / WorldAgent 保持结构一致
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List

STATE_DIR = "./agent_state"


class ConfigManager:

    # -------------------------
    # system config (config.py)
    # -------------------------

    @staticmethod
    def load_system_config() -> Dict[str, Any]:
        """读取系统配置（config.py中的参数）"""
        try:
            import config as cfg

            def g(name: str, default: Any) -> Any:
                return getattr(cfg, name, default)

            return {
                # time
                "tick_sec": g("TICK_SEC", 30),
                "world_observe_every": g("WORLD_OBSERVE_EVERY", 3),
                "goal_gen_every": g("GOAL_GEN_EVERY", 20),
                "memory_consolidate_every": g("MEMORY_CONSOLIDATE_EVERY", 60),

                # memory capacity
                "working_mem_capacity": g("WORKING_MEM_CAPACITY", 7),
                "episodic_hot_keep": g("EPISODIC_HOT_KEEP", 200),
                "semantic_keep": g("SEMANTIC_KEEP", 300),
                "recent_keep": g("RECENT_KEEP", 60),

                # attention / limits
                "attention_top_k": g("ATTENTION_TOP_K", 3),
                "concern_max_active": g("CONCERN_MAX_ACTIVE", 6),
                "goal_max_active": g("GOAL_MAX_ACTIVE", 10),

                # anti-stuck
                "stuck_repeat_tag": g("STUCK_REPEAT_TAG", 5),
                "stuck_no_progress": g("STUCK_NO_PROGRESS", 100),
                "stuck_boredom": g("STUCK_BOREDOM", 0.9),

                # new: world convergence
                "world_clean_threshold": g("WORLD_CLEAN_THRESHOLD", 0.12),

                # new: concern cue pulse/cooldown
                "concern_cue_cooldown_ticks": g("CONCERN_CUE_COOLDOWN_TICKS", 4),
                "current_concern_keep": g("CURRENT_CONCERN_KEEP", 24),

                # new: goal evidence stricter
                "goal_match_threshold": g("GOAL_MATCH_THRESHOLD", 0.55),
                "goal_max_delta_per_tick": g("GOAL_MAX_DELTA_PER_TICK", 0.12),
                "goal_evidence_keep": g("GOAL_EVIDENCE_KEEP", 120),
                "goal_keep_total": g("GOAL_KEEP_TOTAL", 80),
            }

        except Exception as e:
            print(f"加载配置失败: {e}")
            return ConfigManager._default_system_config()

    @staticmethod
    def save_system_config(data: Dict[str, Any]) -> bool:
        """
        保存系统配置到 config.py（会改写 config.py 里的对应变量行）
        改造点：
        - 支持更多新增键
        - 若 config.py 中不存在该键，会追加到文件末尾
        """
        try:
            config_path = "config.py"
            if not os.path.exists(config_path):
                raise FileNotFoundError("config.py 不存在")

            with open(config_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            # 统一映射：外部字段名 -> config.py 变量名
            mapping = {
                "tick_sec": "TICK_SEC",
                "world_observe_every": "WORLD_OBSERVE_EVERY",
                "goal_gen_every": "GOAL_GEN_EVERY",
                "memory_consolidate_every": "MEMORY_CONSOLIDATE_EVERY",

                "working_mem_capacity": "WORKING_MEM_CAPACITY",
                "episodic_hot_keep": "EPISODIC_HOT_KEEP",
                "semantic_keep": "SEMANTIC_KEEP",
                "recent_keep": "RECENT_KEEP",

                "attention_top_k": "ATTENTION_TOP_K",
                "concern_max_active": "CONCERN_MAX_ACTIVE",
                "goal_max_active": "GOAL_MAX_ACTIVE",

                "stuck_repeat_tag": "STUCK_REPEAT_TAG",
                "stuck_no_progress": "STUCK_NO_PROGRESS",
                "stuck_boredom": "STUCK_BOREDOM",

                # new
                "world_clean_threshold": "WORLD_CLEAN_THRESHOLD",
                "concern_cue_cooldown_ticks": "CONCERN_CUE_COOLDOWN_TICKS",
                "current_concern_keep": "CURRENT_CONCERN_KEEP",

                "goal_match_threshold": "GOAL_MATCH_THRESHOLD",
                "goal_max_delta_per_tick": "GOAL_MAX_DELTA_PER_TICK",
                "goal_evidence_keep": "GOAL_EVIDENCE_KEEP",
                "goal_keep_total": "GOAL_KEEP_TOTAL",
            }

            # 构建 replacements: config_var -> value
            replacements: Dict[str, Any] = {}
            for ext_key, cfg_key in mapping.items():
                if ext_key in data:
                    replacements[cfg_key] = data[ext_key]

            # 用正则替换赋值行：^KEY\s*=
            pattern_tpl = r"^\s*{key}\s*="

            new_lines: List[str] = []
            replaced_keys = set()

            for line in lines:
                updated = False
                for key, value in replacements.items():
                    if re.match(pattern_tpl.format(key=re.escape(key)), line):
                        new_lines.append(f"{key} = {repr(value)}\n")
                        replaced_keys.add(key)
                        updated = True
                        break
                if not updated:
                    new_lines.append(line)

            # 追加缺失键
            missing = [k for k in replacements.keys() if k not in replaced_keys]
            if missing:
                new_lines.append("\n# --- auto-added by ConfigManager (for convergence/evidence tuning) ---\n")
                for k in missing:
                    new_lines.append(f"{k} = {repr(replacements[k])}\n")

            with open(config_path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)

            return True

        except Exception as e:
            print(f"保存配置失败: {e}")
            return False

    # -------------------------
    # personality config (state jsons)
    # -------------------------

    @staticmethod
    def load_personality() -> Dict[str, Any]:
        """
        读取人格配置：
        - identity: agent_state/identity.json 由 config.load_identity() 读取，但这里也返回 cfg.DEFAULT_IDENTITY
        - needs: core_state.json 中 needs level
        - concerns: deep_concerns（兼容旧 concerns.json list 格式）
        - semantic: memory/semantic.json 中 source=user_input 的条目（兼容 proposition/claim）
        """
        result = {
            "identity": "",
            "needs": {},
            "concerns": [],   # deep concerns
            "semantic": []
        }

        # identity
        try:
            import config as cfg
            result["identity"] = getattr(cfg, "DEFAULT_IDENTITY", "") or ""
        except Exception:
            pass

        # concerns (deep)
        concerns_path = f"{STATE_DIR}/concerns.json"
        if os.path.exists(concerns_path):
            try:
                with open(concerns_path, "r", encoding="utf-8") as f:
                    concerns_data = json.load(f)

                deep_list = []
                if isinstance(concerns_data, dict):
                    deep_list = concerns_data.get("deep_concerns") or []
                elif isinstance(concerns_data, list):
                    # old format: list of deep concerns only
                    deep_list = concerns_data
                else:
                    deep_list = []

                out = []
                for c in deep_list:
                    if not isinstance(c, dict):
                        continue
                    out.append({
                        "concern_id": c.get("concern_id", ""),
                        "title": c.get("title", ""),
                        "description": c.get("description", ""),
                        "domain": c.get("domain", "general"),
                        "importance": float(c.get("importance", 0.5) or 0.5),
                        "is_core": bool(c.get("is_core", False)),
                        "context_triggers": list(c.get("context_triggers") or []),
                        "status": c.get("status", "active"),
                        "source": c.get("source", ""),
                        "notes": c.get("notes", ""),
                    })
                result["concerns"] = out

            except Exception as e:
                print(f"读取concerns失败: {e}")

        # needs levels
        core_state_path = f"{STATE_DIR}/core_state.json"
        if os.path.exists(core_state_path):
            try:
                with open(core_state_path, "r", encoding="utf-8") as f:
                    core_state = json.load(f)
                for need in core_state.get("needs", []):
                    if isinstance(need, dict) and "id" in need:
                        result["needs"][need["id"]] = float(need.get("level", 0.3) or 0.3)
            except Exception as e:
                print(f"读取needs失败: {e}")

        # semantic (user_input only)
        semantic_path = f"{STATE_DIR}/memory/semantic.json"
        if os.path.exists(semantic_path):
            try:
                with open(semantic_path, "r", encoding="utf-8") as f:
                    semantic_data = json.load(f)

                out = []
                if isinstance(semantic_data, list):
                    for s in semantic_data:
                        if not isinstance(s, dict):
                            continue
                        if s.get("source") != "user_input":
                            continue
                        claim = s.get("proposition") or s.get("claim") or ""
                        if not str(claim).strip():
                            continue
                        out.append({
                            "claim": claim,
                            "confidence": float(s.get("confidence", 0.6) or 0.6),
                            "domain": s.get("domain", "general"),
                        })
                result["semantic"] = out
            except Exception as e:
                print(f"读取semantic失败: {e}")

        return result

    @staticmethod
    def save_personality(data: Dict[str, Any]) -> bool:
        """
        保存人格配置：
        - identity -> agent_state/identity.json
        - concerns -> agent_state/concerns.json（deep_concerns结构；current_concerns留空给系统自建）
        - needs -> core_state.json 的 needs.level
        - semantic -> memory/semantic.json（写 proposition + claim 双字段以兼容）
        """
        try:
            os.makedirs(STATE_DIR, exist_ok=True)
            os.makedirs(f"{STATE_DIR}/memory", exist_ok=True)

            # identity
            if "identity" in data:
                ConfigManager._update_identity_in_config(str(data["identity"] or ""))

            # concerns (deep concerns only)
            if "concerns" in data:
                deep_concerns = []
                for i, c in enumerate(data["concerns"] or []):
                    if not isinstance(c, dict):
                        continue
                    title = str(c.get("title", "") or "").strip()
                    if not title:
                        continue
                    deep_concerns.append({
                        "concern_id": c.get("concern_id") or f"con_user_{i:03d}",
                        "title": title,
                        "description": str(c.get("description", "") or ""),
                        "domain": str(c.get("domain", "general") or "general"),
                        "importance": float(c.get("importance", 0.5) or 0.5),
                        "is_core": bool(c.get("is_core", False)),
                        "context_triggers": list(c.get("context_triggers") or []),
                        "created_ts": str(c.get("created_ts", "") or ""),
                        "status": str(c.get("status", "active") or "active"),
                        "notes": str(c.get("notes", "") or ""),
                        "source": str(c.get("source", "user_input") or "user_input"),
                    })

                # current 留空，让 ConcernSystem 在启动时根据 deep 自动生成默认 current
                out = {
                    "deep_concerns": deep_concerns,
                    "current_concerns": []
                }
                with open(f"{STATE_DIR}/concerns.json", "w", encoding="utf-8") as f:
                    json.dump(out, f, ensure_ascii=False, indent=2)

            # needs
            if "needs" in data:
                if isinstance(data["needs"], dict):
                    ConfigManager._update_needs_in_core_state(data["needs"])

            # semantic
            if "semantic" in data:
                semantic_out = []
                for i, s in enumerate(data["semantic"] or []):
                    if not isinstance(s, dict):
                        continue
                    claim = str(s.get("claim", "") or "").strip()
                    if not claim:
                        continue
                    semantic_out.append({
                        "sem_id": f"sem_user_{i:03d}",
                        "ts": "",
                        # 双字段兼容：memory_system 用 proposition 更常见；旧代码可能读 claim
                        "proposition": claim,
                        "claim": claim,
                        "confidence": float(s.get("confidence", 0.6) or 0.6),
                        "source": "user_input",
                        "domain": s.get("domain", "general"),
                        "reinforcement_count": 1,
                        "last_reinforced_ts": "",
                        "contradicted_by": []
                    })

                with open(f"{STATE_DIR}/memory/semantic.json", "w", encoding="utf-8") as f:
                    json.dump(semantic_out, f, ensure_ascii=False, indent=2)

            return True

        except Exception as e:
            print(f"保存人格配置失败: {e}")
            return False

    # -------------------------
    # internal helpers
    # -------------------------

    @staticmethod
    def _update_identity_in_config(identity: str):
        """更新 identity：写入 agent_state/identity.json（config.py 的 load_identity() 会读取它）"""
        try:
            os.makedirs(STATE_DIR, exist_ok=True)
            json_path = os.path.join(STATE_DIR, "identity.json")
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump({"identity": identity}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"更新identity失败: {e}")

    @staticmethod
    def _update_needs_in_core_state(needs: Dict[str, float]):
        """更新 core_state.json 中 needs 的 level"""
        try:
            core_state_path = f"{STATE_DIR}/core_state.json"

            if os.path.exists(core_state_path):
                with open(core_state_path, "r", encoding="utf-8") as f:
                    core_state = json.load(f)
            else:
                core_state = ConfigManager._default_core_state()

            for need in core_state.get("needs", []):
                if not isinstance(need, dict):
                    continue
                need_id = need.get("id")
                if need_id in needs:
                    need["level"] = float(needs[need_id])

            with open(core_state_path, "w", encoding="utf-8") as f:
                json.dump(core_state, f, ensure_ascii=False, indent=2)

        except Exception as e:
            print(f"更新needs失败: {e}")

    # -------------------------
    # defaults
    # -------------------------

    @staticmethod
    def _default_system_config() -> Dict[str, Any]:
        return {
            "tick_sec": 30,
            "world_observe_every": 3,
            "goal_gen_every": 20,
            "memory_consolidate_every": 60,
            "working_mem_capacity": 7,
            "episodic_hot_keep": 200,
            "semantic_keep": 300,
            "recent_keep": 60,

            "attention_top_k": 3,
            "concern_max_active": 6,
            "goal_max_active": 10,

            "stuck_repeat_tag": 5,
            "stuck_no_progress": 100,
            "stuck_boredom": 0.9,

            # new
            "world_clean_threshold": 0.12,
            "concern_cue_cooldown_ticks": 4,
            "current_concern_keep": 24,

            "goal_match_threshold": 0.55,
            "goal_max_delta_per_tick": 0.12,
            "goal_evidence_keep": 120,
            "goal_keep_total": 80,
        }

    @staticmethod
    def _default_core_state() -> Dict[str, Any]:
        return {
            "tick_count": 0,
            "needs": [
                {"id": "need_hunger", "name": "饥饿", "level": 0.35, "rise_per_min": 0.01, "weight": 1.0, "satisfied_drop": 0.35},
                {"id": "need_thirst", "name": "口渴", "level": 0.25, "rise_per_min": 0.008, "weight": 0.85, "satisfied_drop": 0.30},
                {"id": "need_bladder", "name": "尿意", "level": 0.15, "rise_per_min": 0.006, "weight": 0.90, "satisfied_drop": 0.50},
                {"id": "need_fatigue", "name": "疲劳", "level": 0.30, "rise_per_min": 0.007, "weight": 0.95, "satisfied_drop": 0.25},
                {"id": "need_stress", "name": "压力", "level": 0.20, "rise_per_min": 0.004, "weight": 0.80, "satisfied_drop": 0.20},
                {"id": "need_social", "name": "陪伴", "level": 0.25, "rise_per_min": 0.003, "weight": 0.55, "satisfied_drop": 0.20},
                {"id": "need_order", "name": "秩序", "level": 0.22, "rise_per_min": 0.0035, "weight": 0.60, "satisfied_drop": 0.15},
                {"id": "need_curiosity", "name": "好奇", "level": 0.25, "rise_per_min": 0.0025, "weight": 0.45, "satisfied_drop": 0.10},
            ],
            "loop_guard": {"last_tags": [], "repeat_last_tag_count": 0, "no_progress_ticks": 0, "boredom": 0.20},
            "last_action": {},
            "last_location_before": "",
            "last_location_after": "",
            "recent_log": []
        }