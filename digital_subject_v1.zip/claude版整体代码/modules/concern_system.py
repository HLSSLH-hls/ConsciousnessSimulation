# modules/concern_system.py
"""
Concern System（改造版）
- DeepConcern: 深层长期价值/关切（相对稳定）
- CurrentConcern: Klinger式“当前关切/未竟承诺”介观层
  * tension: 未竟张力（推动注意捕获、检索偏置、目标生成）
  * suppression/rebound: 压抑与回弹
  * cues: 线索触发：改为“脉冲 + 冷却”，避免每tick持续加油造成自激
- 新增：observe_execution(evidence) 把执行结果（need relief / world_state变化）回灌为“完成刹车”

与改造版 world_agent / goal_system 保持一致：
- ctx.world_state 可包含 kitchen_counter_wet/dirty 等真值提示
- evidence.world_state_before/after 用于计算世界变量下降量
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, asdict, fields
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import config as cfg


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _jaccard_char(a: str, b: str) -> float:
    a = (a or "").replace(" ", "")[:200]
    b = (b or "").replace(" ", "")[:200]
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


# -------------------------
# Data Structures
# -------------------------

@dataclass
class DeepConcern:
    concern_id: str = ""
    title: str = ""
    description: str = ""
    domain: str = "general"                # wellbeing|order|social|meaning|safety|growth|general
    importance: float = 0.7                # 稳定权重
    is_core: bool = False

    context_triggers: List[str] = field(default_factory=list)

    created_ts: str = ""
    status: str = "active"                 # active|retired
    notes: str = ""
    source: str = "seed"                   # seed|reflection|event

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DeepConcern":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class CurrentConcern:
    cc_id: str = ""
    deep_concern_id: str = ""

    title: str = ""
    description: str = ""

    tension: float = 0.2                   # 0..1 未竟张力
    suppression: float = 0.0               # 0..1 被压抑程度
    rebound_potential: float = 0.0         # 0..1 回弹势能（由 suppression 累积）

    urgency: float = 0.2                   # 0..1 时间压力/风险
    status: str = "active"                 # active|suppressed|resolved|retired

    context_triggers: List[str] = field(default_factory=list)
    tag_triggers: List[str] = field(default_factory=list)
    semantic_triggers: List[str] = field(default_factory=list)

    linked_goal_ids: List[str] = field(default_factory=list)

    created_ts: str = ""
    last_updated_ts: str = ""
    last_intruded_ts: str = ""
    last_progress_ts: str = ""
    last_suppressed_ts: str = ""
    evidence_notes: str = ""

    # 新增：线索脉冲冷却（避免每tick持续加油）
    last_cue_tick: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "CurrentConcern":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})

    def bid(self, deep_importance: float) -> float:
        if self.status not in ("active", "suppressed"):
            return 0.0
        suppression_discount = 1.0 - 0.6 * _clamp(self.suppression, 0, 1)
        return deep_importance * _clamp(self.tension) * suppression_discount * (1.0 + 0.5 * _clamp(self.urgency))


@dataclass
class ConcernTickContext:
    ts: str = ""
    tick_id: int = 0
    dt_sec: float = 30.0

    location: str = ""
    prev_location: str = ""
    location_changed: bool = False

    time_of_day: str = ""
    recent_tags: List[str] = field(default_factory=list)

    last_action_tag: str = ""
    last_action_tag_changed: bool = False

    needs: Dict[str, float] = field(default_factory=dict)  # {need_id: level}

    boredom: float = 0.2
    no_progress_ticks: int = 0
    surprise: float = 0.0
    patch_ok: Optional[bool] = None

    goal_blocked: List[str] = field(default_factory=list)
    goal_progressed: List[str] = field(default_factory=list)

    # 新增：世界真值提示（来自 world_agent.state_snapshot()）
    world_state: Dict[str, Any] = field(default_factory=dict)


# -------------------------
# ConcernSystem
# -------------------------

class ConcernSystem:
    def __init__(self, state_dir: str):
        self._path = f"{state_dir}/concerns.json"
        self.deep_concerns: List[DeepConcern] = []
        self.current_concerns: List[CurrentConcern] = []
        self._load()
        if not self.deep_concerns:
            self._init_default_deep_concerns()
        if not self.current_concerns:
            self._init_default_current_from_deep()

    # -------------------------
    # persistence
    # -------------------------

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data = json.load(f)

            if isinstance(data, dict) and ("deep_concerns" in data or "current_concerns" in data):
                self.deep_concerns = [DeepConcern.from_dict(d) for d in (data.get("deep_concerns") or [])]
                self.current_concerns = [CurrentConcern.from_dict(d) for d in (data.get("current_concerns") or [])]
                return

            # migration from old list-of-Concern
            if isinstance(data, list):
                self.deep_concerns = []
                for d in data:
                    if not isinstance(d, dict):
                        continue
                    dc = DeepConcern(
                        concern_id=str(d.get("concern_id", "")) or f"con_{int(time.time()*1000)}",
                        title=str(d.get("title", "")),
                        description=str(d.get("description", "")),
                        domain=str(d.get("domain", "general")),
                        importance=_safe_float(d.get("importance", 0.7), 0.7),
                        is_core=bool(d.get("is_core", False)),
                        context_triggers=list(d.get("context_triggers") or []),
                        created_ts=str(d.get("created_ts", "")) or _now_iso(),
                        status=str(d.get("status", "active")),
                        notes=str(d.get("notes", "")),
                        source=str(d.get("source", "seed")),
                    )
                    self.deep_concerns.append(dc)

                self.current_concerns = []
                self._init_default_current_from_deep()
                return

        except Exception:
            self.deep_concerns = []
            self.current_concerns = []

    def save(self):
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        out = {
            "deep_concerns": [c.to_dict() for c in self.deep_concerns],
            "current_concerns": [cc.to_dict() for cc in self.current_concerns],
        }
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)

    # -------------------------
    # CRUD deep
    # -------------------------

    def add_deep(self, c: DeepConcern) -> bool:
        for existing in self.deep_concerns:
            if _jaccard_char(c.title, existing.title) > 0.7:
                return False
        c.concern_id = c.concern_id or f"con_{int(time.time()*1000)}"
        c.created_ts = c.created_ts or _now_iso()
        self.deep_concerns.append(c)
        return True

    def get_deep(self, concern_id: str) -> Optional[DeepConcern]:
        for c in self.deep_concerns:
            if c.concern_id == concern_id:
                return c
        return None

    def update_deep(self, concern_id: str, patch: Dict[str, Any]) -> bool:
        c = self.get_deep(concern_id)
        if not c:
            return False
        allowed = {"title", "description", "importance", "context_triggers", "notes", "status", "domain"}
        if c.is_core and patch.get("status") in ("retired",):
            patch.pop("status", None)
        for k, v in patch.items():
            if k in allowed and hasattr(c, k):
                setattr(c, k, v)
        return True

    def retire_deep(self, concern_id: str, reason: str = "") -> bool:
        c = self.get_deep(concern_id)
        if not c or c.is_core:
            return False
        c.status = "retired"
        c.notes = (c.notes + f" | 退役原因: {reason}").strip()
        return True

    # -------------------------
    # CRUD current
    # -------------------------

    def add_current(self, cc: CurrentConcern) -> bool:
        for existing in self.current_concerns:
            if existing.deep_concern_id == cc.deep_concern_id and _jaccard_char(existing.title, cc.title) > 0.75:
                return False
        cc.cc_id = cc.cc_id or f"cc_{int(time.time()*1000)}"
        cc.created_ts = cc.created_ts or _now_iso()
        cc.last_updated_ts = cc.last_updated_ts or cc.created_ts
        self.current_concerns.append(cc)
        return True

    def get_current(self, cc_id: str) -> Optional[CurrentConcern]:
        for cc in self.current_concerns:
            if cc.cc_id == cc_id:
                return cc
        return None

    def update_current(self, cc_id: str, patch: Dict[str, Any]) -> bool:
        cc = self.get_current(cc_id)
        if not cc:
            return False
        allowed = {
            "title", "description", "tension", "suppression", "rebound_potential",
            "urgency", "status",
            "context_triggers", "tag_triggers", "semantic_triggers",
            "linked_goal_ids", "evidence_notes",
            "last_intruded_ts", "last_progress_ts", "last_suppressed_ts",
            "last_cue_tick",
        }
        for k, v in patch.items():
            if k in allowed and hasattr(cc, k):
                setattr(cc, k, v)
        cc.last_updated_ts = _now_iso()
        return True

    def suppress_current(self, cc_id: str, amount: float = 0.2, ts: Optional[str] = None) -> bool:
        cc = self.get_current(cc_id)
        if not cc or cc.status not in ("active", "suppressed"):
            return False
        cc.suppression = _clamp(cc.suppression + amount)
        cc.status = "suppressed"
        cc.last_suppressed_ts = ts or _now_iso()
        cc.last_updated_ts = ts or _now_iso()
        return True

    def resolve_current(self, cc_id: str, ts: Optional[str] = None) -> bool:
        cc = self.get_current(cc_id)
        if not cc:
            return False
        cc.status = "resolved"
        cc.tension = _clamp(cc.tension * 0.2)
        cc.suppression = _clamp(cc.suppression * 0.2)
        cc.rebound_potential = 0.0
        cc.last_updated_ts = ts or _now_iso()
        return True

    # -------------------------
    # Ops API
    # -------------------------

    def apply_ops(self, ops: Dict[str, Any], ts: str, reflection_mode: bool = False) -> Dict[str, int]:
        """
        新版 keys：
          deep_update/deep_add/deep_retire
          current_update/current_add/current_resolve/current_suppress

        兼容旧版 keys：
          update/add/retire  → 视作 deep_update/deep_add/deep_retire
        """
        ops = ops or {}

        # compat remap
        if "deep_update" not in ops and "update" in ops:
            ops["deep_update"] = ops.get("update")
        if "deep_add" not in ops and "add" in ops:
            ops["deep_add"] = ops.get("add")
        if "deep_retire" not in ops and "retire" in ops:
            ops["deep_retire"] = ops.get("retire")

        stats = {"deep_added": 0, "deep_updated": 0, "deep_retired": 0,
                 "current_added": 0, "current_updated": 0, "current_resolved": 0, "current_suppressed": 0,
                 "rejected": 0}

        # deep_update
        for item in (ops.get("deep_update") or [])[:5]:
            if not isinstance(item, dict):
                continue
            cid = str(item.get("concern_id", "")).strip()
            patch = {k: v for k, v in item.items() if k != "concern_id"}
            if self.update_deep(cid, patch):
                stats["deep_updated"] += 1
            else:
                stats["rejected"] += 1

        # current_update
        for item in (ops.get("current_update") or [])[:8]:
            if not isinstance(item, dict):
                continue
            ccid = str(item.get("cc_id", "")).strip()
            patch = {k: v for k, v in item.items() if k != "cc_id"}
            if self.update_current(ccid, patch):
                stats["current_updated"] += 1
            else:
                stats["rejected"] += 1

        # current_suppress
        for item in (ops.get("current_suppress") or [])[:5]:
            if not isinstance(item, dict):
                continue
            ccid = str(item.get("cc_id", "")).strip()
            amt = _safe_float(item.get("amount", 0.2), 0.2)
            if self.suppress_current(ccid, amt, ts=ts):
                stats["current_suppressed"] += 1
            else:
                stats["rejected"] += 1

        # current_resolve
        for ccid_raw in (ops.get("current_resolve") or [])[:5]:
            ccid = str(ccid_raw).strip()
            if self.resolve_current(ccid, ts=ts):
                stats["current_resolved"] += 1
            else:
                stats["rejected"] += 1

        if not reflection_mode:
            return stats

        # deep_add
        for item in (ops.get("deep_add") or [])[:2]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "")).strip()[:80]
            if not title:
                continue
            dc = DeepConcern(
                title=title,
                description=str(item.get("description", ""))[:240],
                domain=str(item.get("domain", "general")),
                importance=_safe_float(item.get("importance", 0.6), 0.6),
                is_core=bool(item.get("is_core", False)),
                context_triggers=list(item.get("context_triggers") or []),
                source="reflection",
                created_ts=ts,
                status="active",
            )
            if self.add_deep(dc):
                stats["deep_added"] += 1
            else:
                stats["rejected"] += 1

        # deep_retire
        for item in (ops.get("deep_retire") or [])[:2]:
            if not isinstance(item, dict):
                continue
            cid = str(item.get("concern_id", "")).strip()
            reason = str(item.get("reason", "")).strip()
            if self.retire_deep(cid, reason):
                stats["deep_retired"] += 1
            else:
                stats["rejected"] += 1

        # current_add
        for item in (ops.get("current_add") or [])[:3]:
            if not isinstance(item, dict):
                continue
            deep_id = str(item.get("deep_concern_id", "")).strip()
            if not deep_id or not self.get_deep(deep_id):
                stats["rejected"] += 1
                continue
            title = str(item.get("title", "")).strip()[:90]
            if not title:
                continue
            cc = CurrentConcern(
                deep_concern_id=deep_id,
                title=title,
                description=str(item.get("description", ""))[:240],
                tension=_safe_float(item.get("tension", 0.35), 0.35),
                urgency=_safe_float(item.get("urgency", 0.2), 0.2),
                context_triggers=list(item.get("context_triggers") or []),
                tag_triggers=list(item.get("tag_triggers") or []),
                semantic_triggers=list(item.get("semantic_triggers") or []),
                created_ts=ts,
                last_updated_ts=ts,
                status="active",
            )
            if self.add_current(cc):
                stats["current_added"] += 1
            else:
                stats["rejected"] += 1

        return stats

    # -------------------------
    # New: observe execution (刹车闭环)
    # -------------------------

    def observe_execution(self, ts: str, evidence: Any, goal_stats: Optional[Dict[str, Any]] = None):
        """
        evidence: 通常为 goal_system.ExecutionEvidence（避免循环import，这里用 Any）
        作用：把“完成证据”回灌给 current concerns，形成张力下降/抑制调节。
        """
        if evidence is None:
            return

        action_tag = str(getattr(evidence, "action_tag", "") or "other")
        needs_before = getattr(evidence, "needs_before", {}) or {}
        needs_after = getattr(evidence, "needs_after", {}) or {}

        # need relief
        relief: Dict[str, float] = {}
        for nid, b in needs_before.items():
            a = needs_after.get(nid, b)
            try:
                d = float(b) - float(a)
            except Exception:
                continue
            if d > 1e-9:
                relief[nid] = d

        # world decrease
        wsb = getattr(evidence, "world_state_before", {}) or {}
        wsa = getattr(evidence, "world_state_after", {}) or {}
        world_dec: Dict[str, float] = {}
        if wsb and wsa:
            for k, vb in wsb.items():
                if k not in wsa:
                    continue
                try:
                    d = float(vb) - float(wsa.get(k))
                except Exception:
                    continue
                if d > 1e-9:
                    world_dec[k] = d

        # 对每个 concern：如果 tag命中 + 有可验的改善，就显著降温
        for cc in self.current_concerns:
            if cc.status not in ("active", "suppressed"):
                continue
            dc = self.get_deep(cc.deep_concern_id)
            if not dc or dc.status != "active":
                continue

            # tag 是否命中
            trig = set(t.lower() for t in (cc.tag_triggers or []))
            tag_hit = (action_tag.lower() in trig) if trig else False

            # domain-specific improvement strength
            improve = 0.0

            if dc.domain == "order":
                # tidy 的世界真值下降是硬证据
                improve += world_dec.get("kitchen_counter_wet", 0.0) * 2.2
                improve += world_dec.get("kitchen_counter_dirty", 0.0) * 1.8

                # 若已很干净，继续 tidy 属于“检查行为” -> 降温并略增 suppression（抑制其竞价）
                clean_thr = float(getattr(cfg, "WORLD_CLEAN_THRESHOLD", 0.12))
                try:
                    wet_now = float(wsa.get("kitchen_counter_wet", 1.0))
                    dirty_now = float(wsa.get("kitchen_counter_dirty", 1.0))
                except Exception:
                    wet_now, dirty_now = 1.0, 1.0

                if action_tag == "tidy" and wet_now < clean_thr and dirty_now < clean_thr:
                    # 已完成：强降温
                    improve += 0.45

            elif dc.domain == "wellbeing":
                # 生理改善：relief 是硬证据
                improve += relief.get("need_thirst", 0.0) * 3.0
                improve += relief.get("need_hunger", 0.0) * 2.4
                improve += relief.get("need_bladder", 0.0) * 2.4
                improve += relief.get("need_fatigue", 0.0) * 2.2
                improve += relief.get("need_stress", 0.0) * 1.8

            elif dc.domain == "social":
                improve += 0.35 if action_tag == "social" else 0.0
                improve += relief.get("need_social", 0.0) * 2.0

            elif dc.domain in ("meaning", "growth"):
                # 这些域缺少硬世界变量时，只能弱一些：靠 stress/order relief 代理
                improve += relief.get("need_order", 0.0) * 1.2
                improve += relief.get("need_stress", 0.0) * 0.8

            improve = _clamp(improve, 0.0, 1.0)

            # 只有 tag 命中或明确改善显著才做“完成降温”
            if tag_hit or improve >= 0.25:
                deep_imp = _clamp(dc.importance)
                baseline = 0.08 + 0.22 * deep_imp

                # 降温幅度：必须明显大于 cues 的 +0.02，否则刹不住
                cool = (0.04 + 0.14 * improve) * (0.85 + 0.25 * deep_imp)

                cc.tension = _clamp(max(baseline, cc.tension - cool))
                cc.last_progress_ts = ts

                # 做成了事 -> suppression 下降一点（更“释然”）
                cc.suppression = _clamp(cc.suppression - 0.04 * improve)

                cc.evidence_notes = (cc.evidence_notes + f" | exec_cool-{cool:.2f} imp={improve:.2f} tag={action_tag}").strip()
                cc.last_updated_ts = ts

    # -------------------------
    # Dynamics tick
    # -------------------------

    def tick(self, ctx: ConcernTickContext):
        ts = ctx.ts or _now_iso()
        dt = ctx.dt_sec or 30.0

        self._ensure_min_current(ts)
        self._appraise_from_needs(ctx, ts)
        self._appraise_from_cues(ctx, ts)
        self._appraise_from_failures(ctx, ts)

        for cc in self.current_concerns:
            if cc.status in ("resolved", "retired"):
                continue

            deep = self.get_deep(cc.deep_concern_id)
            deep_imp = deep.importance if deep else 0.5
            baseline = 0.08 + 0.22 * deep_imp

            # tension relaxation towards baseline（轻微回归）
            drag = 1.0 + 0.4 * _clamp(ctx.no_progress_ticks / 30.0)
            decay_rate = (0.010 / drag) * (dt / 30.0)
            if cc.tension > baseline:
                cc.tension = max(baseline, cc.tension - decay_rate)
            else:
                cc.tension = min(baseline, cc.tension + 0.003 * (dt / 30.0))

            # suppression/rebound（反刍风险）
            if cc.tension > 0.65 and ctx.no_progress_ticks >= 10:
                cc.suppression = _clamp(cc.suppression + 0.01 * (dt / 30.0))
            else:
                cc.suppression = _clamp(cc.suppression - 0.006 * (dt / 30.0))

            cc.rebound_potential = _clamp(cc.rebound_potential * 0.95 + 0.10 * cc.suppression)

            stress = _safe_float(ctx.needs.get("need_stress", 0.0), 0.0)
            fatigue = _safe_float(ctx.needs.get("need_fatigue", 0.0), 0.0)
            arousal_proxy = _clamp(0.6 * stress + 0.4 * fatigue + 0.3 * _clamp(ctx.surprise))

            if cc.status == "suppressed":
                intrusion_prob = _clamp(0.25 * cc.rebound_potential + 0.35 * arousal_proxy)
                if intrusion_prob > 0.45:
                    cc.status = "active"
                    cc.tension = _clamp(cc.tension + 0.08 + 0.10 * cc.rebound_potential)
                    cc.last_intruded_ts = ts

            cc.last_updated_ts = ts

        self._prune_current(ts)

    # -------------------------
    # Appraisals
    # -------------------------

    def _ensure_min_current(self, ts: str):
        existing_by_deep: Dict[str, int] = {}
        for cc in self.current_concerns:
            if cc.status in ("retired",):
                continue
            existing_by_deep[cc.deep_concern_id] = existing_by_deep.get(cc.deep_concern_id, 0) + 1

        for dc in self.deep_concerns:
            if dc.status != "active":
                continue
            if existing_by_deep.get(dc.concern_id, 0) == 0:
                self.add_current(CurrentConcern(
                    deep_concern_id=dc.concern_id,
                    title=f"（当前）{dc.title}",
                    description=dc.description[:220],
                    tension=0.25 + 0.25 * dc.importance,
                    urgency=0.15,
                    context_triggers=list(dc.context_triggers),
                    tag_triggers=self._default_tag_triggers_for_domain(dc.domain),
                    created_ts=ts,
                    last_updated_ts=ts,
                    status="active",
                ))

    def _default_tag_triggers_for_domain(self, domain: str) -> List[str]:
        return {
            "wellbeing": ["eat", "drink", "toilet", "rest", "recovery"],
            "order": ["tidy", "plan"],                 # 改造：去掉 meta_replan 作为触发源，避免自激
            "social": ["social"],
            "meaning": ["plan", "observe"],
            "growth": ["observe", "plan"],
            "safety": ["observe", "recovery"],
        }.get(domain, ["observe"])

    def _appraise_from_needs(self, ctx: ConcernTickContext, ts: str):
        domain_need_map = {
            "wellbeing": {
                "need_hunger": 1.0,
                "need_thirst": 1.0,
                "need_bladder": 0.7,
                "need_fatigue": 0.9,
                "need_stress": 0.8,
            },
            "order": {"need_order": 1.0, "need_stress": 0.3},
            "social": {"need_social": 1.0, "need_stress": 0.2},
            "meaning": {"need_curiosity": 0.5, "need_stress": 0.4},
            "growth": {"need_curiosity": 0.8},
            "safety": {"need_stress": 0.7},
        }

        for cc in self.current_concerns:
            if cc.status in ("resolved", "retired"):
                continue
            dc = self.get_deep(cc.deep_concern_id)
            if not dc or dc.status != "active":
                continue
            weights = domain_need_map.get(dc.domain, {})
            if not weights:
                continue

            pressure = 0.0
            for need_id, w in weights.items():
                lvl = _safe_float(ctx.needs.get(need_id, 0.0), 0.0)
                pressure += w * (lvl ** 2)

            inc = 0.030 * _clamp(pressure)
            cc.tension = _clamp(cc.tension + inc)
            if inc > 0.02:
                cc.evidence_notes = (cc.evidence_notes + f" | needs_pressure+{inc:.2f}").strip()
            cc.last_updated_ts = ts

    def _appraise_from_cues(self, ctx: ConcernTickContext, ts: str):
        """
        改造点：
        - 线索刺激只在“进入地点”或“tag发生变化且命中触发”时给予脉冲
        - 每个cc有 cue cooldown，避免每tick持续加油
        - 对 order：只有在世界真值提示表明“确实不干净”时才刺激
        """
        now_tick = int(ctx.tick_id or 0)
        cooldown = int(getattr(cfg, "CONCERN_CUE_COOLDOWN_TICKS", 4))

        loc = (ctx.location or "").lower()
        tags = [t.lower() for t in (ctx.recent_tags or [])]
        last_tag = (ctx.last_action_tag or (tags[-1] if tags else "")).lower()

        world = ctx.world_state or {}
        clean_thr = float(getattr(cfg, "WORLD_CLEAN_THRESHOLD", 0.12))
        wet = _safe_float(world.get("kitchen_counter_wet", 1.0), 1.0)
        dirty = _safe_float(world.get("kitchen_counter_dirty", 1.0), 1.0)

        for cc in self.current_concerns:
            if cc.status in ("resolved", "retired"):
                continue

            # cue cooldown
            if now_tick > 0 and cc.last_cue_tick > 0 and (now_tick - cc.last_cue_tick) < cooldown:
                continue

            stimulated = False

            # location-enter pulse
            if bool(ctx.location_changed):
                for trig in cc.context_triggers:
                    t = (trig or "").lower()
                    if t and (t in loc):
                        stimulated = True
                        break

            # tag-change pulse
            if not stimulated and bool(ctx.last_action_tag_changed):
                trig_tags = set(x.lower() for x in (cc.tag_triggers or []))
                if last_tag and last_tag in trig_tags:
                    stimulated = True

            # order domain: only stimulate if truly not clean (prevents infinite “检查”)
            dc = self.get_deep(cc.deep_concern_id)
            if stimulated and dc and dc.domain == "order":
                if (wet < clean_thr) and (dirty < clean_thr):
                    stimulated = False

            if stimulated:
                cc.tension = _clamp(cc.tension + 0.02)
                cc.last_cue_tick = now_tick
                cc.last_updated_ts = ts

    def _appraise_from_failures(self, ctx: ConcernTickContext, ts: str):
        no_prog = ctx.no_progress_ticks
        surprise = _clamp(ctx.surprise)
        patch_ok = ctx.patch_ok

        for cc in self.current_concerns:
            if cc.status in ("resolved", "retired"):
                continue
            dc = self.get_deep(cc.deep_concern_id)
            domain = dc.domain if dc else "general"

            inc = 0.0
            if no_prog >= 10 and domain in ("meaning", "growth", "order"):
                inc += 0.01 + 0.01 * _clamp((no_prog - 10) / 25.0)

            if surprise > 0.35 and domain in ("safety", "meaning", "wellbeing"):
                inc += 0.02 * surprise

            if patch_ok is False and domain in ("safety", "wellbeing"):
                inc += 0.03

            if ctx.goal_blocked and domain in ("meaning", "order", "wellbeing", "social"):
                inc += 0.01
            if ctx.goal_progressed and domain in ("wellbeing", "order", "social", "growth"):
                cc.tension = _clamp(cc.tension - 0.03)

            if inc > 0:
                cc.tension = _clamp(cc.tension + inc)
                cc.last_updated_ts = ts

    # -------------------------
    # pruning
    # -------------------------

    def _prune_current(self, ts: str):
        keep: List[CurrentConcern] = []
        for cc in self.current_concerns:
            dc = self.get_deep(cc.deep_concern_id)
            is_core = bool(dc.is_core) if dc else False

            if cc.status in ("retired",):
                continue

            if is_core:
                keep.append(cc)
                continue

            if cc.tension < 0.12 and not cc.linked_goal_ids:
                continue

            keep.append(cc)

        self.current_concerns = keep

        max_cc = getattr(cfg, "CURRENT_CONCERN_KEEP", 24)
        if len(self.current_concerns) > max_cc:
            scored = []
            for cc in self.current_concerns:
                dc = self.get_deep(cc.deep_concern_id)
                imp = dc.importance if dc else 0.5
                scored.append((cc.bid(imp), cc))
            scored.sort(key=lambda x: x[0], reverse=True)
            self.current_concerns = [cc for _, cc in scored[:max_cc]]

    # -------------------------
    # Query
    # -------------------------

    def active_current_concerns(self, top_k: int = None) -> List[CurrentConcern]:
        if top_k is None:
            top_k = getattr(cfg, "CONCERN_MAX_ACTIVE", 6)
        scored: List[Tuple[float, CurrentConcern]] = []
        for cc in self.current_concerns:
            if cc.status not in ("active", "suppressed"):
                continue
            dc = self.get_deep(cc.deep_concern_id)
            if not dc or dc.status != "active":
                continue
            scored.append((cc.bid(dc.importance), cc))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [cc for _, cc in scored[:top_k]]

    def deep_concerns_active(self) -> List[DeepConcern]:
        active = [c for c in self.deep_concerns if c.status == "active"]
        active.sort(key=lambda c: c.importance, reverse=True)
        return active

    def to_prompt_text(self) -> str:
        lines: List[str] = []
        lines.append("[深层关切 DeepConcerns]")
        for dc in self.deep_concerns_active()[:8]:
            core = " core" if dc.is_core else ""
            lines.append(f"  {dc.concern_id} [{dc.domain}] imp={dc.importance:.2f}{core} | {dc.title}")

        lines.append("[当前关切 CurrentConcerns]")
        for cc in self.active_current_concerns(top_k=getattr(cfg, "CONCERN_MAX_ACTIVE", 6)):
            dc = self.get_deep(cc.deep_concern_id)
            imp = dc.importance if dc else 0.5
            lines.append(
                f"  {cc.cc_id} ←{cc.deep_concern_id} "
                f"bid={cc.bid(imp):.2f} ten={cc.tension:.2f} sup={cc.suppression:.2f} urg={cc.urgency:.2f} "
                f"st={cc.status} | {cc.title}"
            )
            if cc.linked_goal_ids:
                lines.append(f"    goals: {', '.join(cc.linked_goal_ids[:4])}")
        return "\n".join(lines)

    # -------------------------
    # seeds
    # -------------------------

    def _init_default_deep_concerns(self):
        ts = _now_iso()
        seeds = [
            DeepConcern(
                concern_id="con_wellbeing",
                title="保持身体不难受、能撑得住",
                description="吃饱、喝够、厕所、休息——基本生理不拖欠",
                domain="wellbeing",
                importance=0.85,
                is_core=True,
                context_triggers=["home_", "kitchen", "toilet", "bedroom"],
                source="seed",
                created_ts=ts,
                status="active",
            ),
            DeepConcern(
                concern_id="con_order",
                title="屋里屋外有个体面秩序",
                description="东西归位、不乱、能找到——心里才踏实",
                domain="order",
                importance=0.65,
                is_core=True,
                context_triggers=["home_living", "home_kitchen", "home_yard"],
                source="seed",
                created_ts=ts,
                status="active",
            ),
            DeepConcern(
                concern_id="con_meaning",
                title="脑子里的事别一直搅，理清一点是一点",
                description="反复冒出来的念头、挂念——要么记下来要么想清楚，别让它空转",
                domain="meaning",
                importance=0.60,
                is_core=False,
                context_triggers=["home_bedroom", "home_living"],
                source="seed",
                created_ts=ts,
                status="active",
            ),
            DeepConcern(
                concern_id="con_social",
                title="跟人的关系别断了、别生分",
                description="家人、邻居——不用天天联系，但别让关系冷掉",
                domain="social",
                importance=0.50,
                is_core=False,
                context_triggers=["outside_", "home_yard"],
                source="seed",
                created_ts=ts,
                status="active",
            ),
        ]
        self.deep_concerns.extend(seeds)
        self.save()

    def _init_default_current_from_deep(self):
        ts = _now_iso()
        self.current_concerns = []
        for dc in self.deep_concerns_active():
            self.add_current(CurrentConcern(
                deep_concern_id=dc.concern_id,
                title=f"（当前）{dc.title}",
                description=dc.description[:220],
                tension=0.25 + 0.25 * dc.importance,
                urgency=0.15,
                context_triggers=list(dc.context_triggers),
                tag_triggers=self._default_tag_triggers_for_domain(dc.domain),
                created_ts=ts,
                last_updated_ts=ts,
                status="active",
            ))
        self.save()