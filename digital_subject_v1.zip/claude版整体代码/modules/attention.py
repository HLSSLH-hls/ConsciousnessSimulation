# modules/attention.py
"""
注意竞争模块（Attention Competition, 重构版）

候选层：Need / CurrentConcern / Goal / WorldSalience
机制：
- Need阈值 interrupt（强制打断）
- 情绪/唤醒调制（stress/fatigue 代理：高唤醒→更分散、更易被world打断）
- 合理重复不惩罚（eat/drink/rest等序列任务）
- working memory priming：内容相似度而非ID匹配
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import config as cfg


@dataclass
class AttentionResult:
    top_foci: List[Dict[str, Any]] = field(default_factory=list)
    conflict_description: str = ""
    working_memory_snapshot: List[str] = field(default_factory=list)

    dominant_layer: str = "need"      # need|cc|goal|world
    urgency_level: float = 0.5
    recommended_tag: str = "observe"

    interrupt: bool = False
    affect_arousal: float = 0.3
    focus_sharpness: float = 0.6

    def to_prompt_text(self) -> str:
        lines = [
            "[注意竞争结果]",
            f"优势层: {self.dominant_layer} | 紧迫度: {self.urgency_level:.2f} | "
            f"interrupt={self.interrupt} | arousal={self.affect_arousal:.2f} sharp={self.focus_sharpness:.2f}",
            f"冲突: {self.conflict_description}",
        ]
        for f in self.top_foci[:4]:
            lines.append(f"  [{f['layer']}] {f['label']} score={f['score']:.6f} share={f['share']:.2f} tag={f.get('tag_hint','')}")
        lines.append(f"推荐tag: {self.recommended_tag}")
        lines.append(f"工作记忆: {' | '.join(self.working_memory_snapshot[:5])}")
        return "\n".join(lines)


def run_attention_competition(
    needs: List[Any],
    current_concerns: List[Any],
    goals: List[Any],
    working_mem: List[Any],
    world_obs: Any,
    loop_guard: Dict[str, Any],
) -> AttentionResult:

    needs_by_id = {getattr(n, "id", ""): n for n in needs}
    level_by_need = {getattr(n, "id", ""): float(getattr(n, "level", 0.0)) for n in needs}

    boredom = float(loop_guard.get("boredom", 0.2))
    no_progress = int(loop_guard.get("no_progress_ticks", 0))
    last_tags = (loop_guard.get("last_tags", []) or [])
    last_tag = last_tags[-1] if last_tags else ""

    stress = float(level_by_need.get("need_stress", 0.0))
    fatigue = float(level_by_need.get("need_fatigue", 0.0))
    arousal = _clamp(0.75 * stress + 0.25 * fatigue)

    focus_sharpness = _clamp(0.85 - 0.55 * arousal)
    temperature = 0.55 + 1.05 * (1.0 - focus_sharpness)

    world_events = list(getattr(world_obs, "events", []) or [])
    world_blocked = list(getattr(world_obs, "blocked_by", []) or [])
    world_uncert = list(getattr(world_obs, "uncertainty_notes", []) or [])
    world_sal = _clamp(0.08 * len(world_events) + 0.10 * len(world_blocked) + 0.05 * len(world_uncert))

    cc_tension_by_id: Dict[str, float] = {}
    for cc in current_concerns:
        ccid = getattr(cc, "cc_id", "") or getattr(cc, "id", "")
        if ccid:
            cc_tension_by_id[ccid] = float(getattr(cc, "tension", 0.0))

    # interrupt
    interrupt = False
    interrupt_need_id = None
    interrupt_tag = None

    NEED_INTERRUPT_LEVEL = float(getattr(cfg, "NEED_INTERRUPT_LEVEL", 0.85))
    NEED_INTERRUPT_SOFT = float(getattr(cfg, "NEED_INTERRUPT_SOFT", 0.75))

    top_need_id = None
    top_need_level = 0.0
    for nid, lvl in level_by_need.items():
        if lvl > top_need_level:
            top_need_level = lvl
            top_need_id = nid

    if top_need_id and top_need_level >= NEED_INTERRUPT_LEVEL:
        interrupt = True
        interrupt_need_id = top_need_id
        interrupt_tag = _need_to_tag(top_need_id)

    if not interrupt:
        bladder = level_by_need.get("need_bladder", 0.0)
        thirst = level_by_need.get("need_thirst", 0.0)
        if bladder >= 0.82 or (thirst >= NEED_INTERRUPT_SOFT and stress >= 0.75):
            interrupt = True
            interrupt_need_id = "need_bladder" if bladder >= 0.82 else "need_thirst"
            interrupt_tag = _need_to_tag(interrupt_need_id)

    candidates: List[Dict[str, Any]] = []

    # need
    for n in needs:
        nid = getattr(n, "id", "")
        lvl = float(getattr(n, "level", 0.0))
        raw = float(n.bid()) if hasattr(n, "bid") else (lvl * lvl)
        if raw <= 0.002:
            continue
        candidates.append({
            "layer": "need",
            "id": nid,
            "label": f"{getattr(n,'name',nid)}({lvl:.2f})",
            "raw": raw,
            "tag_hint": _need_to_tag(nid),
        })

    # current concern
    for cc in current_concerns:
        ccid = getattr(cc, "cc_id", "") or getattr(cc, "id", "")
        if not ccid:
            continue
        status = str(getattr(cc, "status", "active"))
        if status not in ("active", "suppressed"):
            continue
        ten = float(getattr(cc, "tension", 0.0))
        sup = float(getattr(cc, "suppression", 0.0))
        urg = float(getattr(cc, "urgency", 0.0))
        raw = _clamp(ten) * (1.0 - 0.6 * _clamp(sup)) * (1.0 + 0.5 * _clamp(urg))
        if raw <= 0.02:
            continue
        candidates.append({
            "layer": "cc",
            "id": ccid,
            "label": str(getattr(cc, "title", ccid))[:40],
            "raw": raw,
            "tag_hint": "plan",
        })

    # goal
    for g in goals:
        gid = getattr(g, "goal_id", "") or getattr(g, "id", "")
        if not gid:
            continue
        status = str(getattr(g, "status", "active"))
        if status != "active":
            continue
        pr = float(getattr(g, "priority", 0.5))
        prog = float(getattr(g, "progress", 0.0))
        unfinished = 1.0 - _clamp(prog)
        ccid = str(getattr(g, "current_concern_id", "") or "")
        cc_ten = float(cc_tension_by_id.get(ccid, 0.45))
        blocked_reason = str(getattr(g, "blocked_reason", "") or "")
        blocked_pen = 0.75 if blocked_reason else 1.0

        raw = _clamp(pr) * (0.35 + 0.65 * unfinished) * (0.4 + 0.6 * _clamp(cc_ten)) * blocked_pen
        if raw <= 0.02:
            continue

        candidates.append({
            "layer": "goal",
            "id": gid,
            "label": str(getattr(g, "title", gid))[:42],
            "raw": raw,
            "tag_hint": _tag_hint_from_goal(g),
            "cc_id": ccid,
        })

    # world salience
    if world_events:
        candidates.append({
            "layer": "world",
            "id": "world_events",
            "label": f"环境事件({len(world_events)})",
            "raw": _clamp(0.25 + 0.10 * len(world_events)),
            "tag_hint": "observe",
        })
    if world_blocked:
        candidates.append({
            "layer": "world",
            "id": "world_blocked",
            "label": f"受阻({len(world_blocked)})",
            "raw": _clamp(0.30 + 0.12 * len(world_blocked)),
            "tag_hint": "context_change",
        })
    if world_uncert and arousal > 0.55:
        candidates.append({
            "layer": "world",
            "id": "world_uncertainty",
            "label": f"不确定({len(world_uncert)})",
            "raw": _clamp(0.15 + 0.08 * len(world_uncert)),
            "tag_hint": "observe",
        })

    if not candidates:
        return AttentionResult(
            top_foci=[],
            conflict_description="无候选，默认观察。",
            working_memory_snapshot=_wm_snapshot(working_mem),
            dominant_layer="need",
            urgency_level=0.3,
            recommended_tag="observe",
            interrupt=False,
            affect_arousal=arousal,
            focus_sharpness=focus_sharpness,
        )

    need_pressure = _clamp(top_need_level)
    cc_pressure = _clamp(max((float(getattr(cc, "tension", 0.0)) for cc in current_concerns), default=0.0))

    w_need = 0.22 + 0.55 * (need_pressure ** 2.1)
    w_world = 0.08 + 0.22 * _clamp(world_sal + 0.6 * arousal)
    w_cc = 0.18 + 0.30 * (cc_pressure ** 1.2) * (1.0 - 0.5 * need_pressure)
    w_goal = max(0.10, 1.0 - (w_need + w_world + w_cc))

    s = w_need + w_world + w_cc + w_goal
    w_need, w_world, w_cc, w_goal = (w_need / s, w_world / s, w_cc / s, w_goal / s)

    if interrupt:
        w_need = max(w_need, 0.72)
        rem = 1.0 - w_need
        other = w_world + w_cc + w_goal
        if other > 1e-9:
            w_world = rem * (w_world / other)
            w_cc = rem * (w_cc / other)
            w_goal = rem * (w_goal / other)

    layer_weight = {"need": w_need, "world": w_world, "cc": w_cc, "goal": w_goal}

    # within-layer norm
    layer_sums: Dict[str, float] = {"need": 0.0, "cc": 0.0, "goal": 0.0, "world": 0.0}
    for c in candidates:
        layer_sums[c["layer"]] += max(1e-9, float(c["raw"]))

    for c in candidates:
        lw = layer_weight.get(c["layer"], 0.25)
        norm = float(c["raw"]) / (layer_sums.get(c["layer"], 1.0) or 1.0)
        c["score"] = norm * lw

    # WM priming (content sim)
    wm_items = [(str(getattr(s, "content", ""))[:160], float(getattr(s, "activation", 0.0))) for s in working_mem]
    for c in candidates:
        sim = _wm_prime_similarity(c["label"], wm_items)
        if sim > 0:
            c["score"] *= (1.0 + 0.25 * sim)

    # repeat penalty (reasonable repeats allowed)
    stuckish = (no_progress >= max(10, int(getattr(cfg, "STUCK_NO_PROGRESS", 35) * 0.45)) or boredom >= 0.70)
    repeat_tag = last_tag or ""

    REASONABLE_REPEAT_TAGS = {"eat", "drink", "toilet", "rest", "tidy", "walk"}
    LOW_VALUE_REPEAT_TAGS = {"observe", "plan", "meta_replan"}

    tag_need_map = {
        "eat": "need_hunger",
        "drink": "need_thirst",
        "toilet": "need_bladder",
        "rest": "need_fatigue",
        "tidy": "need_order",
        "recovery": "need_stress",
        "social": "need_social",
    }

    for c in candidates:
        tag = c.get("tag_hint", "")
        if not repeat_tag or tag != repeat_tag:
            continue

        if tag in REASONABLE_REPEAT_TAGS:
            need_id = tag_need_map.get(tag, "")
            if need_id and float(level_by_need.get(need_id, 0.0)) >= 0.55:
                continue
            if interrupt and interrupt_tag == tag:
                continue

        if stuckish:
            if tag in LOW_VALUE_REPEAT_TAGS:
                c["score"] *= 0.55
            else:
                c["score"] *= 0.80

    if repeat_tag and not stuckish and boredom < 0.55:
        for c in candidates:
            if c.get("tag_hint") == repeat_tag:
                c["score"] *= 1.07

    if interrupt and interrupt_need_id:
        for c in candidates:
            if c["layer"] == "need" and c["id"] == interrupt_need_id:
                c["score"] *= 3.5
            elif c["layer"] != "need":
                c["score"] *= 0.45

    candidates.sort(key=lambda x: x["score"], reverse=True)
    top_k = int(getattr(cfg, "ATTENTION_TOP_K", 6))
    top = candidates[:max(1, top_k)]

    shares = _softmax([float(c["score"]) for c in top], temperature=max(0.25, temperature))
    for c, sh in zip(top, shares):
        c["share"] = round(float(sh), 4)
        c["score"] = round(float(c["score"]), 6)

    conflict = _describe_conflict(top)
    dominant_layer = top[0]["layer"] if top else "need"

    urgency = _clamp(0.55 * need_pressure + 0.25 * cc_pressure + 0.20 * _clamp(top[0]["score"] * 8.0))
    if interrupt:
        urgency = max(urgency, 0.92)

    recommended_tag = _recommend_tag(top, loop_guard, interrupt_tag=interrupt_tag)

    return AttentionResult(
        top_foci=top,
        conflict_description=conflict,
        working_memory_snapshot=_wm_snapshot(working_mem),
        dominant_layer=dominant_layer,
        urgency_level=urgency,
        recommended_tag=recommended_tag,
        interrupt=interrupt,
        affect_arousal=arousal,
        focus_sharpness=focus_sharpness,
    )


def _need_to_tag(need_id: str) -> str:
    mapping = {
        "need_hunger":   "eat",
        "need_thirst":   "drink",
        "need_bladder":  "toilet",
        "need_fatigue":  "rest",
        "need_stress":   "recovery",
        "need_order":    "tidy",
        "need_curiosity":"observe",
        "need_social":   "social",
    }
    return mapping.get(need_id, "observe")


def _tag_hint_from_goal(goal: Any) -> str:
    req = getattr(goal, "evidence_requirements", None)
    if isinstance(req, dict):
        tags_any = req.get("tags_any") or []
        if tags_any and isinstance(tags_any, list):
            t0 = str(tags_any[0]).strip()
            if t0:
                return t0

    title = (str(getattr(goal, "title", "")) + " " + str(getattr(goal, "next_action", ""))).lower()
    if any(w in title for w in ["吃", "饭", "食"]):      return "eat"
    if any(w in title for w in ["喝", "水", "饮"]):      return "drink"
    if any(w in title for w in ["厕", "如厕", "排"]):    return "toilet"
    if any(w in title for w in ["休", "躺", "睡"]):      return "rest"
    if any(w in title for w in ["走", "步", "移动"]):    return "walk"
    if any(w in title for w in ["整", "归位", "收"]):    return "tidy"
    if any(w in title for w in ["看", "观察", "注意"]):  return "observe"
    if any(w in title for w in ["计划", "规划", "想"]):  return "plan"
    return "other"


def _wm_snapshot(working_mem: List[Any]) -> List[str]:
    slots = sorted(working_mem, key=lambda s: float(getattr(s, "activation", 0.0)), reverse=True)[:5]
    return [str(getattr(s, "content", ""))[:120] for s in slots]


def _wm_prime_similarity(label: str, wm_items: List[Tuple[str, float]]) -> float:
    label = (label or "").strip()
    if not label or not wm_items:
        return 0.0

    best = 0.0
    for content, act in wm_items:
        act = float(act)
        if act < 0.30:
            continue
        sim = _jaccard_char(label, content)
        best = max(best, sim * _clamp(act))
    return _clamp(best)


def _jaccard_char(a: str, b: str) -> float:
    a = "".join((a or "").split())[:180]
    b = "".join((b or "").split())[:180]
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _softmax(xs: List[float], temperature: float = 1.0) -> List[float]:
    if not xs:
        return []
    t = max(1e-6, float(temperature))
    m = max(xs)
    exps = [math.exp((x - m) / t) for x in xs]
    s = sum(exps) or 1.0
    return [e / s for e in exps]


def _describe_conflict(top: List[Dict[str, Any]]) -> str:
    if len(top) < 2:
        return "注意力集中，无明显冲突。"
    a, b = top[0], top[1]
    ratio = float(b["share"]) / max(1e-9, float(a["share"]))
    if ratio >= 0.85:
        return f"强冲突：{a['label']}({a['layer']}) 与 {b['label']}({b['layer']}) 接近势均力敌。"
    elif ratio >= 0.65:
        return f"温和拉扯：优先'{a['label']}'，同时留意'{b['label']}'。"
    else:
        return f"清晰焦点：'{a['label']}'主导，其余暂时压后。"


def _recommend_tag(top: List[Dict[str, Any]], loop_guard: Dict[str, Any], interrupt_tag: Optional[str] = None) -> str:
    boredom = float(loop_guard.get("boredom", 0.2))
    no_progress = int(loop_guard.get("no_progress_ticks", 0))

    if interrupt_tag:
        return interrupt_tag

    if boredom >= float(getattr(cfg, "STUCK_BOREDOM", 0.88)) or no_progress >= int(getattr(cfg, "STUCK_NO_PROGRESS", 40)):
        return "meta_replan"

    if not top:
        return "observe"
    return top[0].get("tag_hint", "observe")


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))