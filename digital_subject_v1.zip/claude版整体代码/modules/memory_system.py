# modules/memory_system.py
"""
Memory System (重构版)：事件化编码 + 可检索 + 巩固抽取

核心目标：
1) 情节记忆不再是“每tick流水账”，而是 Event（事件）为单位：
   - tick记录先进入 event_buffer
   - 检测边界（location/focus/tag/surprise/need relief/超长）触发 finalize
   - finalize 时调用 LLM 做事件压缩（gist/detail/tags/affect/salience + 语义抽取候选）
2) 检索不再使用 jaccard：使用无依赖的 n-gram hashing 向量相似度（近似embedding），再融合：
   - recency（时近性）
   - affect congruence（情绪一致性）
   - cue match（goal_id / current_concern_id / location）
3) 巩固 consolidate：对高显著/高检索事件做 LLM 抽取：
   - semantic claims（带证据 event_id）
   - option/policy（情境->行动->结果的策略片段）
   并对低价值事件做压缩/遗忘。

注意：
- 此实现默认不依赖 embeddings API（适配 deepseek/base_url 不一定支持 embeddings）。
- 若你未来要接 embeddings API，可以在 _vectorize() 处替换为真实 embedding。
"""

from __future__ import annotations

import json
import math
import os
import re
import time
import hashlib
from dataclasses import dataclass, field, asdict, fields
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import config as cfg
from openai import OpenAI


# -----------------------------
# Utils
# -----------------------------

def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")

def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default

def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return default

def _l2norm(vec: List[float]) -> List[float]:
    s = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v / s for v in vec]

def _dot(a: List[float], b: List[float]) -> float:
    # assume equal length
    return sum(x*y for x, y in zip(a, b))

def _strip_ws(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "")).strip()

def _safe_extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    s, e = text.find("{"), text.rfind("}")
    if s >= 0 and e > s:
        try:
            return json.loads(text[s:e+1])
        except Exception:
            return {}
    return {}


# -----------------------------
# Data Models
# -----------------------------

@dataclass
class TickRecord:
    ts: str = ""
    tick_id: int = 0
    location: str = ""
    time_of_day: str = ""
    world_events: List[str] = field(default_factory=list)
    blocked_by: List[str] = field(default_factory=list)
    uncertainty_notes: List[str] = field(default_factory=list)

    action_tag: str = "other"
    action_summary: str = ""
    action_type: str = "internal"
    patch_ok: bool = True

    chosen_focus_ids: List[str] = field(default_factory=list)

    # cues to index
    goal_ids: List[str] = field(default_factory=list)
    current_concern_ids: List[str] = field(default_factory=list)

    # needs diff
    needs_before: Dict[str, float] = field(default_factory=dict)
    needs_after: Dict[str, float] = field(default_factory=dict)

    boredom_before: float = 0.0
    boredom_after: float = 0.0

    # goal stats summary (optional)
    goal_progressed: int = 0
    goal_done: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TickRecord":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class EpisodicEvent:
    """
    Event-level episodic memory (核心长期情节记忆单位)
    """
    event_id: str = ""
    start_ts: str = ""
    end_ts: str = ""
    tick_start: int = 0
    tick_end: int = 0

    location: str = ""
    time_of_day: str = ""

    gist: str = ""                      # 核心摘要（检索主键）
    detail: str = ""                    # 细节（可选）
    tags: List[str] = field(default_factory=list)

    current_concern_ids: List[str] = field(default_factory=list)
    goal_ids: List[str] = field(default_factory=list)
    focus_ids: List[str] = field(default_factory=list)

    affect_valence: float = 0.0         # -1..1
    affect_arousal: float = 0.3         # 0..1
    salience: float = 0.5               # 0..1

    retrieval_count: int = 0
    last_retrieved_ts: str = ""

    vec: List[float] = field(default_factory=list)  # hashed vector

    # bookkeeping
    is_archived: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EpisodicEvent":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class SemanticItem:
    sem_id: str = ""
    ts: str = ""
    proposition: str = ""
    domain: str = "general"
    confidence: float = 0.6

    evidence_event_ids: List[str] = field(default_factory=list)
    counterevidence_event_ids: List[str] = field(default_factory=list)

    reinforcement_count: int = 1
    last_updated_ts: str = ""

    vec: List[float] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SemanticItem":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class OptionItem:
    """
    简化的“策略/选项”记忆：情境->行动->预期结果
    """
    opt_id: str = ""
    ts: str = ""
    cue: str = ""
    action_tag: str = "other"
    action_template: str = ""
    expected_outcome: str = ""
    reliability: float = 0.5

    evidence_event_ids: List[str] = field(default_factory=list)

    vec: List[float] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "OptionItem":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


@dataclass
class WorkingMemorySlot:
    slot_id: str = ""
    content: str = ""
    source_type: str = "episodic"       # episodic|semantic|option|thought|perception
    source_id: str = ""
    activation: float = 1.0
    entered_ts: str = ""


@dataclass
class EventBufferState:
    """
    当前正在进行的事件缓冲（未完成事件）
    """
    buffer_id: str = ""
    start_ts: str = ""
    tick_start: int = 0
    records: List[TickRecord] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "buffer_id": self.buffer_id,
            "start_ts": self.start_ts,
            "tick_start": self.tick_start,
            "records": [r.to_dict() for r in self.records],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EventBufferState":
        recs = [TickRecord.from_dict(x) for x in (d.get("records") or []) if isinstance(x, dict)]
        return cls(
            buffer_id=str(d.get("buffer_id", "")),
            start_ts=str(d.get("start_ts", "")),
            tick_start=_safe_int(d.get("tick_start", 0), 0),
            records=recs,
        )


# -----------------------------
# Memory System
# -----------------------------

class MemorySystem:
    def __init__(self, state_dir: str, client: OpenAI):
        self.state_dir = state_dir
        self.client = client

        self._mem_dir = f"{state_dir}/memory"
        os.makedirs(self._mem_dir, exist_ok=True)

        self._ep_hot_path = f"{self._mem_dir}/episodic_events_hot.json"
        self._ep_arch_path = f"{self._mem_dir}/episodic_events_archive.jsonl"
        self._sem_path = f"{self._mem_dir}/semantic.json"
        self._opt_path = f"{self._mem_dir}/options.json"
        self._wm_path = f"{self._mem_dir}/working.json"
        self._buf_path = f"{self._mem_dir}/event_buffer.json"

        self.episodic_hot: List[EpisodicEvent] = []
        self.semantic: List[SemanticItem] = []
        self.options: List[OptionItem] = []
        self.working_mem: List[WorkingMemorySlot] = []
        self.event_buffer: EventBufferState = EventBufferState()

        self._load()

    # -------------------------
    # Persistence
    # -------------------------

    def _load(self):
        self.episodic_hot = _load_list(self._ep_hot_path, EpisodicEvent)
        self.semantic = _load_list(self._sem_path, SemanticItem)
        self.options = _load_list(self._opt_path, OptionItem)
        self.working_mem = _load_list(self._wm_path, WorkingMemorySlot)

        if os.path.exists(self._buf_path):
            try:
                with open(self._buf_path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    self.event_buffer = EventBufferState.from_dict(d)
            except Exception:
                self.event_buffer = EventBufferState()

        # migration: if old episodic_hot.json exists, keep it but don't load (avoid break)
        # (you can write a migration tool later if needed)

    def save(self):
        _save_list(self._ep_hot_path, self.episodic_hot)
        _save_list(self._sem_path, self.semantic)
        _save_list(self._opt_path, self.options)
        _save_list(self._wm_path, self.working_mem)
        with open(self._buf_path, "w", encoding="utf-8") as f:
            json.dump(self.event_buffer.to_dict(), f, ensure_ascii=False, indent=2)

    # -------------------------
    # Vectorization (no Jaccard)
    # -------------------------

    def _vectorize(self, text: str, dim: int = 768) -> List[float]:
        """
        无依赖的 n-gram hashing 向量：比 Jaccard 更稳定、更像 embedding 检索的行为。
        """
        text = _strip_ws(text)
        if not text:
            return [0.0] * dim

        # character trigrams (works for CN/EN)
        s = re.sub(r"\s+", "", text)
        grams = []
        if len(s) <= 3:
            grams = [s]
        else:
            grams = [s[i:i+3] for i in range(len(s) - 2)]

        vec = [0.0] * dim
        for g in grams[:2000]:
            h = int(hashlib.md5(g.encode("utf-8")).hexdigest(), 16)
            idx = h % dim
            vec[idx] += 1.0

        return _l2norm(vec)

    # -------------------------
    # Working memory
    # -------------------------

    def push_working(self, content: str, source_type: str, source_id: str, activation: float, ts: str):
        slot = WorkingMemorySlot(
            slot_id=f"wm_{int(time.time()*1000)}",
            content=(content or "")[:160],
            source_type=source_type,
            source_id=source_id,
            activation=float(activation),
            entered_ts=ts,
        )
        self.working_mem.append(slot)
        cap = int(getattr(cfg, "WORKING_MEM_CAPACITY", 7))
        if len(self.working_mem) > cap:
            self.working_mem.sort(key=lambda s: s.activation, reverse=True)
            self.working_mem = self.working_mem[:cap]

    def tick_working_mem(self, dt_sec: float):
        decay = 0.015 * (dt_sec / 30.0)
        for slot in self.working_mem:
            slot.activation = max(0.0, float(slot.activation) - decay)
        self.working_mem = [s for s in self.working_mem if float(s.activation) > 0.01]

    # -------------------------
    # Event buffer + segmentation + encoding (blocking with LLM)
    # -------------------------

    def observe_tick(
        self,
        rec: TickRecord,
        *,
        use_llm_finalize: bool = True,
    ) -> Optional[EpisodicEvent]:
        """
        每tick调用：把记录加入 event buffer，并在边界时 finalize 为 EpisodicEvent
        返回：若本tick触发事件结束并成功编码，则返回该事件，否则None
        """
        if not self.event_buffer.buffer_id:
            self.event_buffer.buffer_id = f"buf_{int(time.time()*1000)}"
            self.event_buffer.start_ts = rec.ts
            self.event_buffer.tick_start = rec.tick_id

        self.event_buffer.records.append(rec)
        self.save()  # persist buffer to survive crash

        boundary, reason = self._boundary_heuristic()
        max_ticks = int(getattr(cfg, "MEM_EVENT_MAX_TICKS", 6))
        if len(self.event_buffer.records) >= max_ticks:
            boundary = True
            reason = (reason + " | max_ticks").strip(" |")

        if not boundary:
            return None

        ev = self._finalize_event(reason=reason, use_llm=use_llm_finalize)
        return ev

    def _boundary_heuristic(self) -> Tuple[bool, str]:
        """
        规则边界：快、可解释。LLM用于 finalize 压缩与更精细的“边界类型”。
        """
        recs = self.event_buffer.records
        if len(recs) <= 1:
            return False, ""

        first = recs[0]
        last = recs[-1]
        prev = recs[-2]

        reasons = []

        # location change
        if last.location and prev.location and last.location != prev.location:
            reasons.append("location_change")

        # big world event / blocked / uncertainty
        if last.world_events:
            reasons.append("world_events")
        if last.blocked_by:
            reasons.append("blocked")
        if last.uncertainty_notes:
            reasons.append("uncertainty")

        # plan-breaking tag
        if last.action_tag in ("meta_replan", "context_change", "recovery"):
            reasons.append("meta_tag")

        # patch failure
        if last.patch_ok is False:
            reasons.append("patch_fail")

        # focus switch (coarse)
        if prev.chosen_focus_ids and last.chosen_focus_ids:
            if prev.chosen_focus_ids[:1] != last.chosen_focus_ids[:1]:
                reasons.append("focus_switch")

        # large need relief/worsen (prediction-error proxy)
        relief = _need_relief(last.needs_before, last.needs_after)
        worsen = _need_worsen(last.needs_before, last.needs_after)
        if sum(relief.values()) >= 0.12:
            reasons.append("need_relief")
        if sum(worsen.values()) >= 0.10:
            reasons.append("need_worsen")

        if reasons:
            return True, "|".join(reasons)
        return False, ""

    def _finalize_event(self, reason: str, use_llm: bool = True) -> Optional[EpisodicEvent]:
        recs = self.event_buffer.records
        if not recs:
            return None

        start = recs[0]
        end = recs[-1]

        # fallback summary if LLM fails
        fallback_gist = f"{end.location}: {end.action_tag} | {end.action_summary[:60]}"

        if use_llm:
            payload = self._llm_compress_event(recs, boundary_reason=reason)
        else:
            payload = {}

        gist = _strip_ws(str(payload.get("gist") or fallback_gist))[:280] or fallback_gist
        detail = _strip_ws(str(payload.get("detail") or ""))[:900]

        tags = payload.get("tags") if isinstance(payload.get("tags"), list) else []
        tags = [str(t)[:32] for t in tags if str(t).strip()][:8]

        valence = float(_safe_float(payload.get("affect_valence", 0.0), 0.0))
        arousal = float(_safe_float(payload.get("affect_arousal", 0.3), 0.3))
        salience = float(_safe_float(payload.get("salience", 0.5), 0.5))
        valence = max(-1.0, min(1.0, valence))
        arousal = _clamp(arousal)
        salience = _clamp(salience)

        # index ids aggregated
        goal_ids = _unique([gid for r in recs for gid in (r.goal_ids or [])])[:8]
        cc_ids = _unique([cid for r in recs for cid in (r.current_concern_ids or [])])[:8]
        focus_ids = _unique([fid for r in recs for fid in (r.chosen_focus_ids or [])])[:10]

        event_id = f"ev_{int(time.time()*1000)}"
        vec = self._vectorize(gist + " " + detail)

        ev = EpisodicEvent(
            event_id=event_id,
            start_ts=start.ts,
            end_ts=end.ts,
            tick_start=start.tick_id,
            tick_end=end.tick_id,
            location=end.location or start.location,
            time_of_day=end.time_of_day or start.time_of_day,
            gist=gist,
            detail=detail,
            tags=tags,
            current_concern_ids=cc_ids,
            goal_ids=goal_ids,
            focus_ids=focus_ids,
            affect_valence=valence,
            affect_arousal=arousal,
            salience=salience,
            vec=vec,
        )
        self.episodic_hot.append(ev)

        # archive overflow
        keep = int(getattr(cfg, "EPISODIC_HOT_KEEP", 120))
        if len(self.episodic_hot) > keep:
            overflow = self.episodic_hot[:-keep]
            for m in overflow:
                m.is_archived = True
                self._archive_event(m)
            self.episodic_hot = self.episodic_hot[-keep:]

        # push WM with salience
        self.push_working(ev.gist, "episodic", ev.event_id, activation=max(0.15, ev.salience), ts=end.ts)

        # optional: accept LLM semantic claims as "candidates" but low confidence;
        # better: consolidate() will extract more stably.
        sem_claims = payload.get("semantic_claims")
        if isinstance(sem_claims, list):
            for item in sem_claims[:3]:
                if not isinstance(item, dict):
                    continue
                claim = _strip_ws(str(item.get("claim", "")))[:220]
                if not claim:
                    continue
                conf = _clamp(_safe_float(item.get("confidence", 0.45), 0.45), 0.1, 0.85)
                dom = str(item.get("domain", "general"))[:32]
                self.update_semantic(
                    ts=end.ts,
                    proposition=claim,
                    confidence=conf,
                    domain=dom,
                    evidence_event_ids=[event_id],
                    source="event_compress",
                )

        # reset buffer
        self.event_buffer = EventBufferState()
        self.save()
        return ev

    def _llm_compress_event(self, recs: List[TickRecord], boundary_reason: str) -> Dict[str, Any]:
        """
        阻塞式：调用LLM将多个tick压缩成一个事件记忆，并输出显著性/情绪/语义候选。
        """
        model = getattr(cfg, "MODEL_MEMORY", getattr(cfg, "MODEL_DECISION", "gpt-4o-mini"))

        # build compact trace
        lines = []
        for r in recs[-12:]:
            relief = _need_relief(r.needs_before, r.needs_after)
            worsen = _need_worsen(r.needs_before, r.needs_after)
            lines.append(
                f"- {r.ts} loc={r.location} tag={r.action_tag} ok={r.patch_ok} "
                f"focus={','.join((r.chosen_focus_ids or [])[:2])} "
                f"relief={_fmt_need_delta(relief)} worsen={_fmt_need_delta(worsen)} "
                f"events={';'.join((r.world_events or [])[:2])} "
                f"action='{r.action_summary[:60]}'"
            )
        trace = "\n".join(lines)

        system = f"""
你是“事件记忆压缩器”。任务：把多个30秒tick记录压缩为一个人类式“事件记忆”。
要求：
1) 只输出严格JSON对象，不要任何解释文字。
2) gist 必须是可回忆的一句话（含情境+关键变化）。
3) detail 可选，最多900字，强调：情境/行动/结果/感受/未竟关切线索。
4) salience 0..1：由意外性/威胁/奖励/目标推进/需要缓解综合决定。
5) affect_valence -1..1，affect_arousal 0..1：给出合理估计（不要极端除非证据强）。
6) semantic_claims 最多3条，必须谨慎，像“从事件抽取的经验/事实”，带confidence。
7) tags：最多8个，短词即可。

边界触发原因（供参考）：{boundary_reason}

输出JSON schema：
{{
  "gist": "...",
  "detail": "...",
  "tags": ["..."],
  "salience": 0.0,
  "affect_valence": 0.0,
  "affect_arousal": 0.3,
  "semantic_claims": [
    {{"claim":"...","confidence":0.55,"domain":"general|body|social|environment|experience"}}
  ]
}}
""".strip()

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": f"tick轨迹如下：\n{trace}\n\n请输出事件记忆JSON。"}
        ]

        try:
            resp = self.client.chat.completions.create(
                model=model,
                messages=messages,
                stream=False,
                temperature=0.4,
            )
            raw = resp.choices[0].message.content or ""
            return _safe_extract_json(raw) or {}
        except Exception:
            return {}

    def _archive_event(self, ev: EpisodicEvent):
        os.makedirs(os.path.dirname(self._ep_arch_path), exist_ok=True)
        with open(self._ep_arch_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(ev.to_dict(), ensure_ascii=False) + "\n")

    # -------------------------
    # Retrieval (episodic / semantic / option)
    # -------------------------

    def retrieve_events(
        self,
        query_text: str,
        *,
        tick_id: int,
        now_ts: str,
        cue_goal_ids: Optional[List[str]] = None,
        cue_cc_ids: Optional[List[str]] = None,
        cue_location: str = "",
        query_affect: Optional[Tuple[float, float]] = None,  # (valence, arousal)
        top_k: int = 6,
        min_score: float = 0.12,
    ) -> List[Tuple[float, EpisodicEvent]]:
        qvec = self._vectorize(query_text)

        cue_goal_ids = cue_goal_ids or []
        cue_cc_ids = cue_cc_ids or []
        cue_location = cue_location or ""

        scored: List[Tuple[float, EpisodicEvent]] = []
        for ev in self.episodic_hot:
            sim = _dot(qvec, ev.vec) if ev.vec else 0.0

            # recency half-life ~ 1 hour (120 ticks) by default
            tick_diff = max(0, tick_id - int(ev.tick_end or ev.tick_start))
            recency = math.exp(-tick_diff / float(getattr(cfg, "MEM_RECENCY_HALFLIFE_TICKS", 120)))

            # affect congruence
            affect_sim = 0.0
            if query_affect is not None:
                qv, qa = query_affect
                affect_sim = 0.5 * (1.0 - abs(float(qv) - float(ev.affect_valence))) + \
                             0.5 * (1.0 - abs(float(qa) - float(ev.affect_arousal)))
                affect_sim = _clamp(affect_sim)

            # cue matches (goal/cc/location)
            cue_bonus = 0.0
            if cue_location and ev.location and cue_location == ev.location:
                cue_bonus += 0.06
            if cue_goal_ids and any(g in (ev.goal_ids or []) for g in cue_goal_ids):
                cue_bonus += 0.10
            if cue_cc_ids and any(c in (ev.current_concern_ids or []) for c in cue_cc_ids):
                cue_bonus += 0.10

            sal = float(ev.salience or 0.5)
            freq_bonus = 0.05 * math.log1p(int(ev.retrieval_count or 0))

            score = (
                0.46 * sim
                + 0.24 * recency
                + 0.12 * affect_sim
                + 0.10 * sal
                + 0.08 * cue_bonus
                + 0.04 * freq_bonus
            )

            if score >= min_score:
                scored.append((min(1.0, score), ev))

        scored.sort(key=lambda x: x[0], reverse=True)
        results = scored[:top_k]

        for _, ev in results:
            ev.retrieval_count += 1
            ev.last_retrieved_ts = now_ts

        return results

    def retrieve_semantic(
        self,
        query_text: str,
        *,
        top_k: int = 5,
        min_confidence: float = 0.35,
    ) -> List[SemanticItem]:
        qvec = self._vectorize(query_text)
        scored: List[Tuple[float, SemanticItem]] = []
        for s in self.semantic:
            if float(s.confidence) < min_confidence:
                continue
            sim = _dot(qvec, s.vec) if s.vec else 0.0
            score = sim * float(s.confidence)
            scored.append((score, s))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:top_k]]

    def retrieve_options(
        self,
        query_text: str,
        *,
        top_k: int = 4,
        min_reliability: float = 0.35,
    ) -> List[OptionItem]:
        qvec = self._vectorize(query_text)
        scored: List[Tuple[float, OptionItem]] = []
        for o in self.options:
            if float(o.reliability) < min_reliability:
                continue
            sim = _dot(qvec, o.vec) if o.vec else 0.0
            scored.append((sim * float(o.reliability), o))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [o for _, o in scored[:top_k]]

    # -------------------------
    # Semantic update (evidence-linked)
    # -------------------------

    def update_semantic(
        self,
        *,
        ts: str,
        proposition: str,
        confidence: float = 0.6,
        domain: str = "general",
        evidence_event_ids: Optional[List[str]] = None,
        source: str = "consolidation",
    ) -> SemanticItem:
        proposition = _strip_ws(proposition)[:240]
        confidence = _clamp(float(confidence), 0.05, 0.98)
        evidence_event_ids = evidence_event_ids or []

        # merge by vector similarity (approx)
        vec = self._vectorize(proposition)

        best: Optional[SemanticItem] = None
        best_sim = 0.0
        for s in self.semantic:
            sim = _dot(vec, s.vec) if s.vec else 0.0
            if sim > best_sim:
                best_sim = sim
                best = s

        # threshold for merge
        if best and best_sim >= float(getattr(cfg, "SEM_MERGE_SIM", 0.86)):
            best.confidence = min(1.0, best.confidence * 0.75 + confidence * 0.25)
            best.reinforcement_count += 1
            best.last_updated_ts = ts
            # add evidence
            for eid in evidence_event_ids:
                if eid and eid not in best.evidence_event_ids:
                    best.evidence_event_ids.append(eid)
            return best

        sem = SemanticItem(
            sem_id=f"sem_{int(time.time()*1000)}",
            ts=ts,
            proposition=proposition,
            domain=str(domain)[:32],
            confidence=confidence,
            evidence_event_ids=list(evidence_event_ids)[:20],
            reinforcement_count=1,
            last_updated_ts=ts,
            vec=vec,
        )
        self.semantic.append(sem)

        keep = int(getattr(cfg, "SEMANTIC_KEEP", 160))
        if len(self.semantic) > keep:
            self.semantic.sort(key=lambda x: float(x.confidence) * (1.0 + 0.1 * int(x.reinforcement_count)))
            self.semantic = self.semantic[-keep:]

        return sem

    # -------------------------
    # Consolidation (blocking LLM)
    # -------------------------

    def consolidate(self, ts: str):
        """
        周期性巩固（阻塞式）：挑选高显著/高检索事件 -> LLM 抽取 semantic 与 option
        同时对低价值、久未检索事件做衰减/压缩。
        """
        model = getattr(cfg, "MODEL_MEMORY_CONSOLIDATE", getattr(cfg, "MODEL_MEMORY", getattr(cfg, "MODEL_DECISION", "gpt-4o-mini")))

        # 1) choose candidates: high salience or high retrieval
        cands = []
        for ev in self.episodic_hot:
            score = 0.55 * float(ev.salience) + 0.25 * math.log1p(int(ev.retrieval_count)) + 0.20 * (1.0 if (ev.goal_ids or ev.current_concern_ids) else 0.0)
            cands.append((score, ev))
        cands.sort(key=lambda x: x[0], reverse=True)
        chosen = [ev for _, ev in cands[: int(getattr(cfg, "MEM_CONSOLIDATE_TOP_N", 6))]]

        if chosen:
            payload = self._llm_consolidate(chosen, ts=ts, model=model)
            self._apply_consolidation_payload(payload, ts=ts)

        # 2) forgetting/decay: old low-salience, never retrieved
        now_tick = max((int(ev.tick_end or ev.tick_start) for ev in self.episodic_hot), default=0)
        for ev in self.episodic_hot:
            age = now_tick - int(ev.tick_end or ev.tick_start)
            if age > int(getattr(cfg, "MEM_FORGET_AGE_TICKS", 220)) and float(ev.salience) < 0.30 and int(ev.retrieval_count) == 0:
                ev.salience = max(0.05, float(ev.salience) * 0.82)

        self.save()

    def _llm_consolidate(self, events: List[EpisodicEvent], ts: str, model: str) -> Dict[str, Any]:
        # build brief
        lines = []
        for ev in events[:8]:
            lines.append(f"- {ev.start_ts}~{ev.end_ts} loc={ev.location} sal={ev.salience:.2f} | {ev.gist}")

        system = """
你是“记忆巩固模块”。任务：从若干事件记忆中抽取稳定的语义知识与可复用策略(选项)。
要求：
1) 只输出严格JSON对象，不要解释文字。
2) semantic_claims：最多6条，每条必须是可泛化的经验/事实/偏好，带confidence与domain，并给出evidence_event_ids（引用输入事件的event_id）。
3) options：最多4条，每条描述“情境cue -> 行动 -> 预期结果”，带reliability，并给出evidence_event_ids。
4) 不要胡编外部事实；只能从输入事件合理推断。
输出JSON schema：
{
  "semantic_claims":[
    {"proposition":"...","confidence":0.6,"domain":"general|body|social|environment|experience","evidence_event_ids":["ev_xxx"]}
  ],
  "options":[
    {"cue":"...","action_tag":"drink","action_template":"...","expected_outcome":"...","reliability":0.55,"evidence_event_ids":["ev_xxx"]}
  ]
}
""".strip()

        user = f"当前时间 {ts}。输入事件（只依据这些抽取）：\n" + "\n".join(lines)
        # include ids for evidence linking
        id_map = "\n".join([f"{ev.event_id}: {ev.gist}" for ev in events[:8]])
        user += "\n\n事件ID映射：\n" + id_map

        try:
            resp = self.client.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                stream=False,
                temperature=0.35,
            )
            raw = resp.choices[0].message.content or ""
            return _safe_extract_json(raw) or {}
        except Exception:
            return {}

    def _apply_consolidation_payload(self, payload: Dict[str, Any], ts: str):
        if not isinstance(payload, dict):
            return

        sems = payload.get("semantic_claims") or []
        if isinstance(sems, list):
            for item in sems[:6]:
                if not isinstance(item, dict):
                    continue
                prop = _strip_ws(str(item.get("proposition", "")))[:240]
                if not prop:
                    continue
                conf = _clamp(_safe_float(item.get("confidence", 0.55), 0.55), 0.1, 0.95)
                dom = str(item.get("domain", "experience"))[:32]
                evid = item.get("evidence_event_ids") if isinstance(item.get("evidence_event_ids"), list) else []
                evid = [str(x) for x in evid if str(x).strip()][:12]
                self.update_semantic(ts=ts, proposition=prop, confidence=conf, domain=dom, evidence_event_ids=evid, source="consolidation")

        opts = payload.get("options") or []
        if isinstance(opts, list):
            for item in opts[:4]:
                if not isinstance(item, dict):
                    continue
                cue = _strip_ws(str(item.get("cue", "")))[:160]
                action_tag = str(item.get("action_tag", "other"))[:24]
                templ = _strip_ws(str(item.get("action_template", "")))[:200]
                outc = _strip_ws(str(item.get("expected_outcome", "")))[:220]
                rel = _clamp(_safe_float(item.get("reliability", 0.55), 0.55), 0.1, 0.95)
                evid = item.get("evidence_event_ids") if isinstance(item.get("evidence_event_ids"), list) else []
                evid = [str(x) for x in evid if str(x).strip()][:12]

                if not cue or not templ:
                    continue

                opt_text = f"{cue} | {action_tag} | {templ} | {outc}"
                opt = OptionItem(
                    opt_id=f"opt_{int(time.time()*1000)}",
                    ts=ts,
                    cue=cue,
                    action_tag=action_tag,
                    action_template=templ,
                    expected_outcome=outc,
                    reliability=rel,
                    evidence_event_ids=evid,
                    vec=self._vectorize(opt_text),
                )
                self.options.append(opt)

        # prune options
        keep_opt = int(getattr(cfg, "OPTION_KEEP", 80))
        if len(self.options) > keep_opt:
            self.options.sort(key=lambda o: float(o.reliability), reverse=True)
            self.options = self.options[:keep_opt]

    # -------------------------
    # Prompt text for decision
    # -------------------------

    def to_prompt_text(self, max_chars: int = 2000) -> str:
        """
        提供给决策LLM的记忆摘要（更像“人类可用的摘要”，不是dump数据库）。
        """
        lines: List[str] = []
        lines.append("[工作记忆]")
        wm = sorted(self.working_mem, key=lambda s: float(s.activation), reverse=True)[:7]
        for s in wm:
            lines.append(f"  [{s.source_type}] act={float(s.activation):.2f} {s.content}")

        lines.append("[情节记忆-最近事件]")
        for ev in self.episodic_hot[-4:]:
            lines.append(f"  {ev.end_ts} | {ev.gist} (sal={ev.salience:.2f} v={ev.affect_valence:.1f} a={ev.affect_arousal:.1f})")

        lines.append("[语义记忆-高置信]")
        sem_sorted = sorted(self.semantic, key=lambda s: float(s.confidence) * (1 + 0.1 * int(s.reinforcement_count)), reverse=True)[:4]
        for s in sem_sorted:
            lines.append(f"  [{s.domain}] {s.proposition} (conf={s.confidence:.2f})")

        out = "\n".join(lines)
        if len(out) > max_chars:
            out = out[:max_chars] + "\n…"
        return out


# -----------------------------
# Helpers
# -----------------------------

def _unique(xs: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in xs:
        x = str(x).strip()
        if not x or x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out

def _need_relief(before: Dict[str, float], after: Dict[str, float]) -> Dict[str, float]:
    out = {}
    for k, b in (before or {}).items():
        a = (after or {}).get(k, b)
        try:
            d = float(b) - float(a)
        except Exception:
            continue
        if d > 1e-6:
            out[k] = d
    return out

def _need_worsen(before: Dict[str, float], after: Dict[str, float]) -> Dict[str, float]:
    out = {}
    for k, b in (before or {}).items():
        a = (after or {}).get(k, b)
        try:
            d = float(a) - float(b)
        except Exception:
            continue
        if d > 1e-6:
            out[k] = d
    return out

def _fmt_need_delta(d: Dict[str, float]) -> str:
    if not d:
        return "{}"
    items = sorted(d.items(), key=lambda x: x[1], reverse=True)[:3]
    return "{" + ", ".join(f"{k}:{v:.2f}" for k, v in items) + "}"

def _load_list(path: str, cls) -> list:
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            return []
        out = []
        for d in data:
            if isinstance(d, dict):
                out.append(cls.from_dict(d))
        return out
    except Exception:
        return []

def _save_list(path: str, items: list):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump([item.to_dict() if hasattr(item, "to_dict") else asdict(item) for item in items],
                  f, ensure_ascii=False, indent=2)