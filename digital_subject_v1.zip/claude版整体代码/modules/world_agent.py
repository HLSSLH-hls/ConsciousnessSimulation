# modules/world_agent.py
"""
WorldAgent（改造版）：WorldState(真值) + Observation(渲染)

目标：
- 引入最小 world truth：WorldState 只允许执行层修改，确保世界可收敛（尤其 tidy 会“做完”并消失）
- affordances 由 WorldState 规则计算，不再由 LLM 叙事生成（LLM可以“说”，但系统会覆盖）
- LLM observe 仅负责把 state 渲染成感官细节（visual/auditory/somatic/...），不允许写真值

对外接口保持基本一致：
- observe(ts, tick_id, core_state, last_action, use_llm) -> WorldObservation
- apply_action_patch(patch) -> bool （只处理 location/posture）
新增：
- apply_action_effect(tag, duration_sec, patch_ok) -> None  （根据动作改变 WorldState）
- state_snapshot() -> dict
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from openai import OpenAI
import config as cfg


# -----------------------------
# World Truth (可收敛的真值状态)
# -----------------------------

@dataclass
class WorldState:
    ts: str = ""
    tick_id: int = 0

    location: str = "home_bedroom"
    posture: str = "sitting"

    # 最小可收敛变量：厨房台面“湿/脏”
    kitchen_counter_wet: float = 0.35    # 0..1
    kitchen_counter_dirty: float = 0.25  # 0..1

    # 供给类状态（可选最小化）
    has_drinkable_water: bool = True
    has_easy_food: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WorldState":
        valid = set(cls.__dataclass_fields__.keys())
        kw = {k: d.get(k) for k in valid if k in d}
        st = cls(**kw)
        # clamp
        st.kitchen_counter_wet = _clamp(float(st.kitchen_counter_wet), 0.0, 1.0)
        st.kitchen_counter_dirty = _clamp(float(st.kitchen_counter_dirty), 0.0, 1.0)
        return st


# -----------------------------
# Observation (给决策LLM的观察快照)
# -----------------------------

@dataclass
class WorldObservation:
    ts: str = ""
    tick_id: int = 0

    location: str = "home_bedroom"
    posture: str = "sitting"
    nearby_people: List[str] = field(default_factory=list)

    visual: List[str] = field(default_factory=list)
    auditory: List[str] = field(default_factory=list)
    somatic: List[str] = field(default_factory=list)
    olfactory: List[str] = field(default_factory=list)

    affordances: List[str] = field(default_factory=list)
    blocked_by: List[str] = field(default_factory=list)

    events: List[str] = field(default_factory=list)
    social_cues: List[str] = field(default_factory=list)

    time_of_day: str = "morning"
    ambient_energy: float = 0.5

    confidence: float = 0.8
    uncertainty_notes: List[str] = field(default_factory=list)

    # 额外：给决策LLM一点“系统状态提示”（不等于叙事观察）
    system_state_hint: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WorldObservation":
        valid = set(cls.__dataclass_fields__.keys())
        kw = {k: d.get(k) for k in valid if k in d}
        obs = cls(**kw)
        return obs

    def to_prompt_text(self) -> str:
        parts = [
            f"[位置] {self.location} | 姿势: {self.posture} | 时段: {self.time_of_day}",
            f"[视觉] {'; '.join(self.visual) or '无特殊'}",
            f"[听觉] {'; '.join(self.auditory) or '安静'}",
            f"[身体] {'; '.join(self.somatic) or '正常'}",
            f"[可做] {', '.join(self.affordances) or '无明确选项'}",
        ]
        if self.system_state_hint:
            parts.append(f"[系统状态提示] {'; '.join(self.system_state_hint)}")
        if self.events:
            parts.append(f"[事件] {'; '.join(self.events)}")
        if self.social_cues:
            parts.append(f"[社交] {'; '.join(self.social_cues)}")
        if self.blocked_by:
            parts.append(f"[阻碍] {'; '.join(self.blocked_by)}")
        if self.uncertainty_notes:
            parts.append(f"[不确定] {'; '.join(self.uncertainty_notes)}")
        return "\n".join(parts)


class WorldAgent:
    """
    改造要点：
    - self.state: WorldState 真值（可收敛）
    - self.current: WorldObservation 观察渲染（给决策模块）
    """

    def __init__(self, client: OpenAI, state_dir: str):
        self.client = client
        self.state_dir = state_dir
        self._world_path = f"{state_dir}/world.json"
        self._obs_path = f"{state_dir}/world_observation.json"

        self.state: WorldState = WorldState()
        self.current: WorldObservation = WorldObservation()

        self._load()

        # 启动时保证 current 与 state 同步（location/posture/affordances）
        self._refresh_current_from_state()

    # -------------------------
    # persistence
    # -------------------------

    def _load(self):
        # load state truth
        if os.path.exists(self._world_path):
            try:
                with open(self._world_path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    self.state = WorldState.from_dict(d)
            except Exception:
                pass

        # load last observation (optional)
        if os.path.exists(self._obs_path):
            try:
                with open(self._obs_path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    self.current = WorldObservation.from_dict(d)
            except Exception:
                pass

        # if state not set but obs exists, migrate minimal
        if self.state.location == "home_bedroom" and self.current.location:
            self.state.location = self.current.location
            self.state.posture = self.current.posture or self.state.posture

    def _save_state(self):
        os.makedirs(self.state_dir, exist_ok=True)
        with open(self._world_path, "w", encoding="utf-8") as f:
            json.dump(self.state.to_dict(), f, ensure_ascii=False, indent=2)

    def _save_obs(self):
        os.makedirs(self.state_dir, exist_ok=True)
        with open(self._obs_path, "w", encoding="utf-8") as f:
            json.dump(self.current.to_dict(), f, ensure_ascii=False, indent=2)

    def state_snapshot(self) -> Dict[str, Any]:
        return self.state.to_dict()

    # -------------------------
    # affordances from truth
    # -------------------------

    def compute_affordances(self) -> List[str]:
        st = self.state
        aff: List[str] = []

        # posture-based
        if st.posture in ("lying", "sitting"):
            aff.append("stand_up")
        if st.posture in ("standing",):
            aff.append("sit_down")
        if st.posture in ("standing", "walking"):
            aff.append("walk")

        # location-based core affordances
        loc = st.location

        # 允许通过邻接表走动（决策通过 world_patch 申请）
        # 这里只提供“可走动”提示，不直接列出所有邻居避免prompt过长
        if loc.startswith("home_") or loc.startswith("outside_"):
            aff.append("move_adjacent")

        if loc == "home_kitchen":
            if st.has_drinkable_water:
                aff.append("drink_water")
            if st.has_easy_food:
                aff.append("check_food")

            clean_thr = float(getattr(cfg, "WORLD_CLEAN_THRESHOLD", 0.12))
            if st.kitchen_counter_wet > clean_thr or st.kitchen_counter_dirty > clean_thr:
                aff.append("tidy_one")

        elif loc == "home_toilet":
            aff.extend(["use_toilet", "wash_hands"])
        elif loc == "home_bedroom":
            aff.extend(["lie_down", "look_outside"])
        elif loc == "home_living":
            aff.extend(["look_outside"])
        elif loc == "home_yard":
            aff.extend(["look_outside", "stretch"])
        elif loc == "outside_gate":
            aff.extend(["observe_surroundings"])
        elif loc == "outside_road":
            aff.extend(["observe_surroundings"])

        # 去重并稳定排序（按出现顺序）
        seen = set()
        out = []
        for a in aff:
            if a not in seen:
                out.append(a)
                seen.add(a)
        return out

    def _refresh_current_from_state(self):
        """在不进行LLM观察时，也保持 current 的关键字段与 state 同步"""
        st = self.state
        self.current.location = st.location
        self.current.posture = st.posture
        self.current.affordances = self.compute_affordances()

        # system hint：只给与当前地点相关的少量真值提示（让LLM知道“是否还需要tidy”）
        hint: List[str] = []
        if st.location == "home_kitchen":
            hint.append(f"厨房台面 wet={st.kitchen_counter_wet:.2f} dirty={st.kitchen_counter_dirty:.2f}")
        self.current.system_state_hint = hint

    # -------------------------
    # public API
    # -------------------------

    def observe(
        self,
        ts: str,
        tick_id: int,
        core_state: Dict[str, Any],
        last_action: Optional[Dict] = None,
        use_llm: bool = True,
    ) -> WorldObservation:
        """
        生成新的环境观察（渲染）
        - 真值来自 self.state
        - affordances 来自 compute_affordances()
        - LLM 只负责感官细节，不允许写 location/posture/affordances 真值
        """
        # update truth timestamp
        self.state.ts = ts
        self.state.tick_id = tick_id
        self._save_state()

        # ensure base obs synced
        self._refresh_current_from_state()

        if use_llm:
            obs = self._llm_observe(ts, tick_id, core_state, last_action)
        else:
            obs = self._rule_observe(ts, tick_id, last_action)

        self.current = obs
        self._save_obs()
        return obs

    def apply_action_patch(self, patch: Dict[str, Any]) -> bool:
        """
        只处理 location/posture 的合法性验证与应用（真值层）。
        """
        patch = patch or {}
        cur_loc = self.state.location
        new_loc = str(patch.get("location", "") or "").strip()
        new_pos = str(patch.get("posture", "") or "").strip()

        if new_loc:
            neighbors = cfg.WORLD_NEIGHBORS.get(cur_loc, [])
            if new_loc not in cfg.WORLD_LOCATIONS:
                return False
            if new_loc != cur_loc and new_loc not in neighbors:
                return False
            self.state.location = new_loc

        if new_pos:
            if new_pos not in cfg.POSTURES:
                return False
            self.state.posture = new_pos

        self._save_state()
        self._refresh_current_from_state()
        self._save_obs()
        return True

    def apply_action_effect(self, tag: str, duration_sec: float, patch_ok: bool = True):
        """
        根据 action_tag 改变世界真值（让世界可收敛）
        说明：下一批改 main.py 时，会在 apply_decision() 后调用它。
        """
        tag = (tag or "other").strip()
        dur = float(duration_sec or 0.0)
        if dur <= 0:
            dur = float(getattr(cfg, "TICK_SEC", 30))

        st = self.state

        # patch失败时，世界效果应弱化/不发生
        effectiveness = 1.0 if patch_ok else 0.35
        k = effectiveness * _clamp(dur / float(getattr(cfg, "TICK_SEC", 30)), 0.2, 1.0)

        if tag == "tidy" and st.location == "home_kitchen":
            # 每tick最多降低一定幅度，避免“一步到位”
            wet_drop = 0.22 * k
            dirty_drop = 0.18 * k
            st.kitchen_counter_wet = _clamp(st.kitchen_counter_wet - wet_drop, 0.0, 1.0)
            st.kitchen_counter_dirty = _clamp(st.kitchen_counter_dirty - dirty_drop, 0.0, 1.0)

        # 你也可以后续扩展：cook/eat/drink 改变 has_easy_food 等
        # if tag == "eat": ...
        # if tag == "drink": ...

        self._save_state()
        self._refresh_current_from_state()
        self._save_obs()

    # -------------------------
    # internal: LLM observe render
    # -------------------------

    def _build_observe_prompt(
        self,
        ts: str,
        core_state: Dict[str, Any],
        last_action: Optional[Dict],
    ) -> List[Dict[str, str]]:
        st = self.state
        prev = self.current

        needs_brief = _format_needs_brief(core_state.get("needs", []))

        last_act_str = ""
        if last_action:
            last_act_str = (
                f"上一个动作: tag={last_action.get('tag')} "
                f"summary={last_action.get('summary','')} "
                f"duration={last_action.get('duration_sec',30)}s"
            )

        # 给 LLM 的“真值提示”（只用于渲染，不允许改写）
        truth_hint = []
        if st.location == "home_kitchen":
            truth_hint.append(f"厨房台面：wet={st.kitchen_counter_wet:.2f} dirty={st.kitchen_counter_dirty:.2f}")
        if st.has_drinkable_water:
            truth_hint.append("有可饮用水")
        if st.has_easy_food:
            truth_hint.append("有可快速取用的食物/食材线索")
        truth_hint_text = "; ".join(truth_hint) or "（无特殊真值提示）"

        system = f"""
你是"环境感知渲染模块"。你只负责把给定的世界真值(WorldState)渲染成30秒的感官观察。
你不能修改世界真值。你不得编造与真值冲突的事实。

硬规则：
1) 只输出一个严格JSON对象，不含解释文字。
2) 你不得输出或修改 location/posture/affordances（即使你输出了也会被系统覆盖）。
3) 你的输出应主要包含：visual/auditory/somatic/olfactory/events/social_cues/time_of_day/ambient_energy/confidence/uncertainty_notes。
4) 观察要具体、物理连贯；允许不确定就写入 uncertainty_notes。

世界真值（不可更改）：
- 时间: {ts}
- location: {st.location}
- posture: {st.posture}
- truth_hint: {truth_hint_text}

上一次观察（仅作连续性参考）：
- visual={prev.visual}
- somatic={prev.somatic}
{last_act_str}

主体内部参考（只用于推断体感变化，不要复述）：
{needs_brief}

输出JSON Schema：
{{
  "visual":    ["具体视觉细节1", "..."],
  "auditory":  ["具体听觉细节"],
  "somatic":   ["具体身体感觉"],
  "olfactory": [],
  "nearby_people": [],
  "events":      [],
  "blocked_by":  [],
  "social_cues": [],
  "time_of_day": "morning|afternoon|evening|night",
  "ambient_energy": 0.5,
  "confidence": 0.85,
  "uncertainty_notes": []
}}
""".strip()

        return [
            {"role": "system", "content": system},
            {"role": "user", "content": f"生成 {ts} 的环境观察渲染JSON。"}
        ]

    def _llm_observe(
        self,
        ts: str,
        tick_id: int,
        core_state: Dict[str, Any],
        last_action: Optional[Dict],
    ) -> WorldObservation:
        messages = self._build_observe_prompt(ts, core_state, last_action)
        try:
            resp = self.client.chat.completions.create(
                model=cfg.MODEL_WORLD,
                messages=messages,
                stream=False,
                temperature=0.35,
            )
            raw = resp.choices[0].message.content or ""
            d = _safe_extract_json(raw)
            rendered = WorldObservation.from_dict(d)

            # 强制覆盖真值字段
            rendered.ts = ts
            rendered.tick_id = tick_id
            rendered.location = self.state.location
            rendered.posture = self.state.posture
            rendered.affordances = self.compute_affordances()

            hint: List[str] = []
            if self.state.location == "home_kitchen":
                hint.append(f"厨房台面 wet={self.state.kitchen_counter_wet:.2f} dirty={self.state.kitchen_counter_dirty:.2f}")
            rendered.system_state_hint = hint

            return rendered
        except Exception as e:
            obs = self._rule_observe(ts, tick_id, last_action)
            obs.uncertainty_notes.append(f"WorldAgent LLM失败: {type(e).__name__}")
            return obs

    def _rule_observe(
        self,
        ts: str,
        tick_id: int,
        last_action: Optional[Dict],
    ) -> WorldObservation:
        self._refresh_current_from_state()
        obs = WorldObservation(
            ts=ts,
            tick_id=tick_id,
            location=self.state.location,
            posture=self.state.posture,
            nearby_people=[],
            affordances=self.compute_affordances(),
            visual=[f"位于{self.state.location}，光线与物品细节不明（规则模式）"],
            auditory=["环境较安静（规则模式）"],
            somatic=["身体状态平稳（规则模式）"],
            olfactory=[],
            blocked_by=[],
            events=[],
            social_cues=[],
            time_of_day=self.current.time_of_day or "morning",
            ambient_energy=0.45,
            confidence=0.45,
            uncertainty_notes=["规则模式：感知细节不可靠"],
            system_state_hint=self.current.system_state_hint,
        )

        # 轻微应用上一个动作的体感后效（不改变真值）
        if last_action:
            tag = str(last_action.get("tag", "") or "")
            if tag == "rest":
                obs.somatic = ["休息后肌肉略松（规则模式）"]
            elif tag == "walk":
                obs.somatic = ["走动后轻微心跳加快（规则模式）"]
            elif tag == "drink":
                obs.somatic = ["嗓子湿润了一些（规则模式）"]

        return obs


# -------------------------
# helpers
# -------------------------

def _format_needs_brief(needs: List[Dict]) -> str:
    lines = []
    for n in needs:
        try:
            level = float(n.get("level", 0))
        except Exception:
            level = 0.0
        if level > 0.5:
            lines.append(f"  {n.get('name', n.get('id','?'))}: {level:.2f}")
    return "\n".join(lines) if lines else "  （各需求平稳）"


def _safe_extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    s, e = text.find("{"), text.rfind("}")
    if s >= 0 and e > s:
        return json.loads(text[s:e + 1])
    raise ValueError("No JSON found")


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))