# modules/goal_system.py
"""
Goal System（改造版）
- 目标进度必须由 ExecutionEvidence 验证/限幅，并保存 evidence_log
- Evidence 更严格：requirements 缺失/过弱时不再“白给基础分”
- 支持 world_state 变化作为硬证据（例如 tidy 要看到 kitchen_counter_wet 下降）

注意：为了与下一批 main.py 改造一致：
ExecutionEvidence 增加 world_state_before/after，但旧 main 不填也不报错（默认空 dict）。
"""

from __future__ import annotations

import uuid
import json
import os
from dataclasses import dataclass, field, asdict, fields
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from openai import OpenAI
import config as cfg


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _jaccard_char(a: str, b: str) -> float:
    a = (a or "").replace(" ", "")[:200]
    b = (b or "").replace(" ", "")[:200]
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


@dataclass
class ExecutionEvidence:
    ts: str = ""
    tick_id: int = 0

    action_tag: str = "other"
    action_summary: str = ""
    patch_ok: bool = True

    location_before: str = ""
    location_after: str = ""

    needs_before: Dict[str, float] = field(default_factory=dict)
    needs_after: Dict[str, float] = field(default_factory=dict)

    boredom_before: float = 0.0
    boredom_after: float = 0.0

    chosen_focus_goal_ids: List[str] = field(default_factory=list)
    chosen_focus_cc_ids: List[str] = field(default_factory=list)

    # 新增：世界真值变化证据（下一批 main.py 会填充）
    world_state_before: Dict[str, Any] = field(default_factory=dict)
    world_state_after: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GoalEvidenceRecord:
    ts: str = ""
    tick_id: int = 0
    goal_id: str = ""
    proposed_delta: float = 0.0
    applied_delta: float = 0.0
    verdict: str = ""  # accepted|capped|rejected|auto
    reason: str = ""

    action_tag: str = ""
    patch_ok: bool = True
    location_before: str = ""
    location_after: str = ""
    need_relief: Dict[str, float] = field(default_factory=dict)
    world_state_decrease: Dict[str, float] = field(default_factory=dict)

    note: str = ""


@dataclass
class Goal:
    goal_id: str = ""
    deep_concern_id: str = ""
    current_concern_id: str = ""

    title: str = ""
    description: str = ""
    success_criteria: str = ""

    priority: float = 0.5
    progress: float = 0.0
    status: str = "active"  # active|paused|done|abandoned

    created_ts: str = ""
    done_ts: str = ""
    last_touched_ts: str = ""
    last_progress_ts: str = ""

    deadline_ticks: int = 0
    next_action: str = ""
    blocked_reason: str = ""

    source: str = "generated"  # generated|manual|rule_fallback

    evidence_requirements: Dict[str, Any] = field(default_factory=dict)
    evidence_log: List[GoalEvidenceRecord] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["evidence_log"] = [asdict(r) for r in self.evidence_log]
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Goal":
        valid = {f.name for f in fields(cls)}
        log_data = d.get("evidence_log") or []
        g = cls(**{k: v for k, v in d.items() if k in valid and k != "evidence_log"})
        g.evidence_log = []
        for item in log_data[:200]:
            if isinstance(item, dict):
                g.evidence_log.append(GoalEvidenceRecord(**{
                    k: item.get(k) for k in GoalEvidenceRecord.__dataclass_fields__
                }))
        return g

    def bid(self, cc_tension: float = 0.5) -> float:
        if self.status != "active":
            return 0.0
        unfinished = 1.0 - _clamp(self.progress)
        return _clamp(self.priority) * (0.35 + 0.65 * unfinished) * (0.4 + 0.6 * _clamp(cc_tension))


class GoalSystem:
    def __init__(self, state_dir: str, client: OpenAI):
        self._path = f"{state_dir}/goals.json"
        self.client = client
        self.goals: List[Goal] = []
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                self.goals = [Goal.from_dict(d) for d in data if isinstance(d, dict)]
        except Exception:
            self.goals = []

    def save(self):
        os.makedirs(os.path.dirname(self._path), exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump([g.to_dict() for g in self.goals], f, ensure_ascii=False, indent=2)

    # -------------------------
    # CRUD
    # -------------------------

    def add(self, goal: Goal) -> bool:
        goal.goal_id = goal.goal_id or f"goal_{uuid.uuid4().hex}"
        goal.created_ts = goal.created_ts or _now_iso()
        goal.last_touched_ts = goal.last_touched_ts or goal.created_ts
        self.goals.append(goal)
        return True

    def get(self, goal_id: str) -> Optional[Goal]:
        for g in self.goals:
            if g.goal_id == goal_id:
                return g
        return None

    def update(self, goal_id: str, patch: Dict[str, Any], ts: Optional[str] = None) -> bool:
        g = self.get(goal_id)
        if not g:
            return False
        allowed = {
            "title", "description", "success_criteria", "priority",
            "status", "next_action", "blocked_reason", "deadline_ticks",
            "evidence_requirements", "deep_concern_id", "current_concern_id",
            "source",
        }
        for k, v in patch.items():
            if k in allowed and hasattr(g, k):
                setattr(g, k, v)
        g.last_touched_ts = ts or _now_iso()
        return True

    # -------------------------
    # evidence helpers
    # -------------------------

    def _need_relief(self, ev: ExecutionEvidence) -> Dict[str, float]:
        relief: Dict[str, float] = {}
        for nid, before in (ev.needs_before or {}).items():
            after = (ev.needs_after or {}).get(nid, before)
            try:
                before_f = float(before)
                after_f = float(after)
            except Exception:
                continue
            d = before_f - after_f
            if d > 1e-6:
                relief[nid] = d
        return relief

    def _world_state_decrease(self, ev: ExecutionEvidence) -> Dict[str, float]:
        """
        返回每个数值变量的“下降量”(before - after)，仅对可转 float 的字段计算
        """
        dec: Dict[str, float] = {}
        b = ev.world_state_before or {}
        a = ev.world_state_after or {}
        if not b or not a:
            return dec
        for k, vb in b.items():
            if k not in a:
                continue
            try:
                fb = float(vb)
                fa = float(a.get(k))
            except Exception:
                continue
            d = fb - fa
            if d > 1e-9:
                dec[k] = d
        return dec

    def _match_evidence(self, g: Goal, ev: ExecutionEvidence) -> Tuple[float, str]:
        """
        改造点：不再给“缺省requirements”白送分。
        若 evidence_requirements 为空或无效，直接 score=0。
        """
        req = g.evidence_requirements or {}
        if not isinstance(req, dict) or not req:
            return 0.0, "no evidence_requirements"

        # hard gate
        require_patch_ok = bool(req.get("require_patch_ok", False))
        if require_patch_ok and not ev.patch_ok:
            return 0.0, "require_patch_ok but patch_ok=false"

        reasons: List[str] = []
        satisfied_weight = 0.0
        total_weight = 0.0

        # --- tags_any ---
        tags_any = [t for t in (req.get("tags_any") or []) if isinstance(t, str) and t.strip()]
        if tags_any:
            w = 0.45
            total_weight += w
            if ev.action_tag in tags_any:
                satisfied_weight += w
            else:
                reasons.append(f"tag {ev.action_tag} not in tags_any={tags_any}")

        # --- location_any ---
        loc_any = [x for x in (req.get("location_any") or []) if isinstance(x, str) and x.strip()]
        if loc_any:
            w = 0.18
            total_weight += w
            if ev.location_after in loc_any or ev.location_before in loc_any:
                satisfied_weight += w
            else:
                reasons.append(f"location {ev.location_after} not in location_any={loc_any}")

        # --- need_relief_min ---
        need_min = req.get("need_relief_min") or {}
        if isinstance(need_min, dict) and need_min:
            w = 0.25
            total_weight += w
            relief = self._need_relief(ev)
            ok = True
            for nid, thr in need_min.items():
                thr_f = _safe_float(thr, 0.0)
                if relief.get(nid, 0.0) + 1e-9 < thr_f:
                    ok = False
                    reasons.append(f"need_relief {nid}={relief.get(nid,0.0):.3f} < {thr_f:.3f}")
            if ok:
                satisfied_weight += w

        # --- world_state_decrease_min ---
        ws_dec_min = req.get("world_state_decrease_min") or {}
        if isinstance(ws_dec_min, dict) and ws_dec_min:
            w = 0.30
            total_weight += w
            dec = self._world_state_decrease(ev)
            ok = True
            for key, thr in ws_dec_min.items():
                thr_f = _safe_float(thr, 0.0)
                if dec.get(key, 0.0) + 1e-9 < thr_f:
                    ok = False
                    reasons.append(f"world_decrease {key}={dec.get(key,0.0):.3f} < {thr_f:.3f}")
            if ok:
                satisfied_weight += w

        if total_weight <= 1e-9:
            return 0.0, "requirements empty/invalid (no checkable fields)"

        score = _clamp(satisfied_weight / total_weight, 0.0, 1.0)
        return score, ("; ".join(reasons)[:240] or "matched")

    def _cap_progress_delta(self, proposed: float, match_score: float) -> float:
        max_per_tick = float(getattr(cfg, "GOAL_MAX_DELTA_PER_TICK", 0.12))
        cap = max_per_tick * _clamp(match_score)
        if proposed >= 0:
            return min(proposed, cap)
        else:
            return max(proposed, -cap)

    def _append_evidence(self, g: Goal, rec: GoalEvidenceRecord):
        g.evidence_log.append(rec)
        keep = int(getattr(cfg, "GOAL_EVIDENCE_KEEP", 120))
        if len(g.evidence_log) > keep:
            g.evidence_log = g.evidence_log[-keep:]

    # -------------------------
    # apply ops (verified)
    # -------------------------

    def apply_ops(self, ops: Dict[str, Any], ts: str, evidence: Optional[ExecutionEvidence] = None) -> Dict[str, int]:
        ops = ops or {}
        stats = {"added": 0, "updated": 0, "progressed": 0, "done": 0, "rejected": 0, "capped": 0, "auto": 0}

        match_thr = float(getattr(cfg, "GOAL_MATCH_THRESHOLD", 0.55))

        # progress
        for item in (ops.get("progress") or [])[:6]:
            if not isinstance(item, dict):
                continue
            gid = str(item.get("goal_id", "")).strip()
            g = self.get(gid)
            if not g or g.status != "active":
                stats["rejected"] += 1
                continue

            proposed = _safe_float(item.get("delta", 0.0), 0.0)
            note = str(item.get("note", ""))[:200]
            if abs(proposed) < 1e-6:
                stats["rejected"] += 1
                continue

            if evidence is None:
                self._append_evidence(g, GoalEvidenceRecord(
                    ts=ts, tick_id=0, goal_id=gid,
                    proposed_delta=proposed, applied_delta=0.0,
                    verdict="rejected", reason="no evidence provided",
                    note=note
                ))
                stats["rejected"] += 1
                continue

            match, reason = self._match_evidence(g, evidence)
            if match + 1e-9 < match_thr:
                applied = 0.0
                verdict = "rejected"
                stats["rejected"] += 1
            else:
                applied = self._cap_progress_delta(proposed, match)
                verdict = "accepted"
                if abs(applied) < 1e-9:
                    verdict = "rejected"
                    stats["rejected"] += 1
                elif abs(applied - proposed) > 1e-6:
                    verdict = "capped"
                    stats["capped"] += 1

            if verdict in ("accepted", "capped"):
                old = g.progress
                g.progress = _clamp(g.progress + applied)
                g.last_touched_ts = ts
                if applied > 0:
                    g.last_progress_ts = ts
                if g.progress > old + 1e-6:
                    stats["progressed"] += 1

                if g.progress >= 0.999:
                    g.status = "done"
                    g.done_ts = ts
                    stats["done"] += 1

            self._append_evidence(g, GoalEvidenceRecord(
                ts=ts,
                tick_id=evidence.tick_id if evidence else 0,
                goal_id=gid,
                proposed_delta=proposed,
                applied_delta=applied,
                verdict=verdict,
                reason=f"match={match:.2f} thr={match_thr:.2f} {reason}"[:240],
                action_tag=evidence.action_tag if evidence else "",
                patch_ok=bool(evidence.patch_ok) if evidence else True,
                location_before=evidence.location_before if evidence else "",
                location_after=evidence.location_after if evidence else "",
                need_relief=self._need_relief(evidence) if evidence else {},
                world_state_decrease=self._world_state_decrease(evidence) if evidence else {},
                note=note,
            ))

        # update (no direct progress)
        for item in (ops.get("update") or [])[:6]:
            if not isinstance(item, dict):
                continue
            gid = str(item.get("goal_id", "")).strip()
            patch = {k: v for k, v in item.items() if k != "goal_id"}
            patch.pop("progress", None)
            if self.update(gid, patch, ts=ts):
                stats["updated"] += 1

        # done (改造：尽量要求证据，不再无条件 done)
        for gid_raw in (ops.get("done") or [])[:5]:
            gid = str(gid_raw).strip()
            g = self.get(gid)
            if not g or g.status != "active":
                continue

            ok = False
            if g.progress >= 0.95:
                ok = True
            elif evidence is not None:
                match, _ = self._match_evidence(g, evidence)
                if match >= max(0.75, match_thr):
                    ok = True

            if ok:
                g.status = "done"
                g.progress = 1.0
                g.done_ts = ts
                g.last_touched_ts = ts
                stats["done"] += 1
            else:
                stats["rejected"] += 1
                self._append_evidence(g, GoalEvidenceRecord(
                    ts=ts,
                    tick_id=evidence.tick_id if evidence else 0,
                    goal_id=gid,
                    proposed_delta=0.0,
                    applied_delta=0.0,
                    verdict="rejected",
                    reason="done rejected: insufficient evidence/progress",
                    action_tag=evidence.action_tag if evidence else "",
                    patch_ok=bool(evidence.patch_ok) if evidence else True,
                    location_before=evidence.location_before if evidence else "",
                    location_after=evidence.location_after if evidence else "",
                    need_relief=self._need_relief(evidence) if evidence else {},
                    world_state_decrease=self._world_state_decrease(evidence) if evidence else {},
                    note="attempted done",
                ))

        # add
        for item in (ops.get("add") or [])[:2]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "")).strip()[:140]
            if not title:
                continue

            evr = item.get("evidence_requirements") if isinstance(item.get("evidence_requirements"), dict) else {}
            # 强制至少有 tags_any，否则进度验证会很难收敛
            tags_any = [t for t in (evr.get("tags_any") or []) if isinstance(t, str) and t.strip()]
            if not tags_any:
                hint = str(item.get("tag_hint", "observe")).strip() or "observe"
                evr["tags_any"] = [hint]

            g = Goal(
                deep_concern_id=str(item.get("deep_concern_id", ""))[:80],
                current_concern_id=str(item.get("current_concern_id", ""))[:80],
                title=title,
                description=str(item.get("description", ""))[:280],
                success_criteria=str(item.get("success_criteria", ""))[:160],
                priority=_safe_float(item.get("priority", 0.5), 0.5),
                next_action=str(item.get("next_action", ""))[:160],
                evidence_requirements=evr,
                source=str(item.get("source", "generated"))[:40],
                created_ts=ts,
                last_touched_ts=ts,
            )
            self.add(g)
            stats["added"] += 1

        self._prune()
        return stats

    def observe_execution(self, ts: str, evidence: ExecutionEvidence, auto_for_focused: bool = True) -> Dict[str, int]:
        """
        自动进度：仅对“焦点目标”且 evidence 匹配达标时生效
        """
        stats = {"auto_progressed": 0}
        if not auto_for_focused:
            return stats

        match_thr = float(getattr(cfg, "GOAL_MATCH_THRESHOLD", 0.55))

        focus_goal_ids = set(evidence.chosen_focus_goal_ids or [])
        if not focus_goal_ids:
            return stats

        for gid in list(focus_goal_ids)[:3]:
            g = self.get(gid)
            if not g or g.status != "active":
                continue
            match, reason = self._match_evidence(g, evidence)
            if match + 1e-9 < max(match_thr, 0.60):
                continue

            proposed = 0.04
            applied = self._cap_progress_delta(proposed, match)
            if applied <= 1e-6:
                continue

            old = g.progress
            g.progress = _clamp(g.progress + applied)
            g.last_touched_ts = ts
            g.last_progress_ts = ts

            self._append_evidence(g, GoalEvidenceRecord(
                ts=ts,
                tick_id=evidence.tick_id,
                goal_id=gid,
                proposed_delta=proposed,
                applied_delta=applied,
                verdict="auto",
                reason=f"match={match:.2f} {reason}"[:240],
                action_tag=evidence.action_tag,
                patch_ok=evidence.patch_ok,
                location_before=evidence.location_before,
                location_after=evidence.location_after,
                need_relief=self._need_relief(evidence),
                world_state_decrease=self._world_state_decrease(evidence),
                note="auto progress for focused goal",
            ))

            if g.progress > old + 1e-6:
                stats["auto_progressed"] += 1
            if g.progress >= 0.999:
                g.status = "done"
                g.done_ts = ts
        return stats

    # -------------------------
    # forgetting / fade-out
    # -------------------------

    def tick(self, ts: str, active_current_concern_ids: List[str], cc_tension_by_id: Optional[Dict[str, float]] = None):
        active_set = set(active_current_concern_ids or [])
        cc_tension_by_id = cc_tension_by_id or {}

        for g in self.goals:
            if g.status not in ("active", "paused"):
                continue

            if g.current_concern_id and g.current_concern_id not in active_set:
                g.priority = _clamp(g.priority * 0.98)
            else:
                g.priority = _clamp(g.priority * 1.005)

            tension = _safe_float(cc_tension_by_id.get(g.current_concern_id, 0.0), 0.0) if g.current_concern_id else 0.0
            no_progress_long = (g.last_progress_ts == "")
            if tension < 0.18 and no_progress_long and g.progress < 0.3:
                g.status = "paused"
                g.blocked_reason = g.blocked_reason or "当前关切张力较低，目标暂时淡出"
                g.last_touched_ts = ts

        self._prune()

    def _prune(self, keep_done: int = 24, keep_abandoned: int = 20):
        done = [g for g in self.goals if g.status == "done"]
        abandoned = [g for g in self.goals if g.status == "abandoned"]
        active = [g for g in self.goals if g.status not in ("done", "abandoned")]

        done = sorted(done, key=lambda x: x.done_ts or "", reverse=True)[:keep_done]
        abandoned = sorted(abandoned, key=lambda x: x.last_touched_ts or "", reverse=True)[:keep_abandoned]
        self.goals = active + done + abandoned

        cap = int(getattr(cfg, "GOAL_KEEP_TOTAL", 80))
        if len(self.goals) > cap:
            act = [g for g in self.goals if g.status in ("active", "paused")]
            hist = [g for g in self.goals if g.status in ("done", "abandoned")]
            act.sort(key=lambda g: g.priority * (1.0 - g.progress), reverse=True)
            self.goals = act[: max(10, cap - len(hist))] + hist[: max(0, cap - len(act))]

    # -------------------------
    # generation from CurrentConcerns
    # -------------------------

    def generate_from_current_concerns(
        self,
        current_concerns: list,
        deep_concerns: dict,
        world_obs: Any,
        needs_brief: str,
        memory_brief: str,
        ts: str,
        use_llm: bool = True,
    ) -> List[Goal]:
        active_goals = [g for g in self.goals if g.status == "active"]
        if len(active_goals) >= int(getattr(cfg, "GOAL_MAX_ACTIVE", 10)):
            return []

        if not use_llm:
            return self._rule_generate(current_concerns, ts)

        messages = self._build_goal_gen_prompt(
            current_concerns, deep_concerns, world_obs, active_goals, needs_brief, memory_brief, ts
        )
        try:
            resp = self.client.chat.completions.create(
                model=getattr(cfg, "MODEL_GOAL_GEN", "deepseek-chat"),
                messages=messages,
                stream=False,
                temperature=0.55,
            )
            raw = resp.choices[0].message.content or ""
            data = _safe_extract_json(raw)
            new_goals: List[Goal] = []

            for item in (data.get("new_goals") or [])[:3]:
                if not isinstance(item, dict):
                    continue
                cc_id = str(item.get("current_concern_id", "")).strip()
                deep_id = str(item.get("deep_concern_id", "")).strip()

                title = str(item.get("title", "")).strip()[:140]
                if not title:
                    continue

                evr = item.get("evidence_requirements") if isinstance(item.get("evidence_requirements"), dict) else {}
                tags_any = [t for t in (evr.get("tags_any") or []) if isinstance(t, str) and t.strip()]
                if not tags_any:
                    hint = str(item.get("tag_hint", "observe")).strip() or "observe"
                    evr["tags_any"] = [hint]

                g = Goal(
                    deep_concern_id=deep_id,
                    current_concern_id=cc_id,
                    title=title,
                    description=str(item.get("description", ""))[:280],
                    success_criteria=str(item.get("success_criteria", ""))[:160],
                    priority=_safe_float(item.get("priority", 0.5), 0.5),
                    next_action=str(item.get("next_action", ""))[:160],
                    evidence_requirements=evr,
                    source="generated",
                    created_ts=ts,
                    last_touched_ts=ts,
                )

                if self._is_duplicate_goal(g, active_goals):
                    continue

                self.add(g)
                new_goals.append(g)

            return new_goals
        except Exception:
            return self._rule_generate(current_concerns, ts)

    def _is_duplicate_goal(self, g: Goal, active_goals: List[Goal]) -> bool:
        for eg in active_goals:
            if _jaccard_char(g.title, eg.title) > 0.72:
                return True
        return False

    def _build_goal_gen_prompt(
        self,
        current_concerns: list,
        deep_concerns: dict,
        world_obs: Any,
        active_goals: List[Goal],
        needs_brief: str,
        memory_brief: str,
        ts: str,
    ) -> List[Dict[str, str]]:
        cc_lines = []
        for cc in current_concerns[:6]:
            cc_lines.append(
                f"  cc_id={getattr(cc,'cc_id','')} deep={getattr(cc,'deep_concern_id','')} "
                f"ten={getattr(cc,'tension',0.0):.2f} sup={getattr(cc,'suppression',0.0):.2f} "
                f"| {getattr(cc,'title','')}"
            )
        cc_text = "\n".join(cc_lines) or "  （无）"

        active_goals_text = "\n".join([
            f"  {g.goal_id} cc={g.current_concern_id} prog={g.progress:.2f} pr={g.priority:.2f} | {g.title}"
            for g in active_goals[:10]
        ]) or "  （无活跃目标）"

        # 轻量给出系统状态提示（如果 world_obs 有）
        sys_hint = ""
        try:
            hint_list = getattr(world_obs, "system_state_hint", []) or []
            if hint_list:
                sys_hint = " | system_hint: " + "; ".join(hint_list[:3])
        except Exception:
            sys_hint = ""

        system = f"""
你是“目标生成模块”。职责：把当前关切(CurrentConcerns)转化为可执行的短期目标(Goals)。

关键要求：
- 必须输出 evidence_requirements，用于系统验证进度，防止“空口推进”。
- evidence_requirements 越保守越好：宁可推进慢，也不要允许无证据涨进度。

支持的 evidence_requirements 字段示例：
- tags_any: ["drink","tidy"]
- location_any: ["home_kitchen"]
- need_relief_min: {{"need_thirst": 0.05}}
- require_patch_ok: true
- world_state_decrease_min: {{"kitchen_counter_wet": 0.10}}   （适用于 tidy 类目标：必须看到世界真值变量下降）

规则：
1) 只输出严格JSON，不含解释文字。
2) 最多生成3个新目标；避免与已有活跃目标重复。
3) success_criteria 必须可验收（行为/状态变化为准）。
4) next_action 为下一个30秒微行动，尽量匹配世界可行动项。
5) evidence_requirements 至少要包含 tags_any（必填）。

当前时间: {ts}
位置: {getattr(world_obs,'location','')} | 时段: {getattr(world_obs,'time_of_day','')}{sys_hint}
可行动: {getattr(world_obs,'affordances',[])}

[当前关切]
{cc_text}

[已有活跃目标]
{active_goals_text}

[需求摘要]
{needs_brief}

[相关记忆摘要]
{memory_brief}

输出JSON：
{{
  "new_goals": [
    {{
      "current_concern_id": "cc_xxx",
      "deep_concern_id": "con_xxx",
      "title": "...",
      "description": "...",
      "success_criteria": "...",
      "priority": 0.6,
      "next_action": "...",
      "evidence_requirements": {{
        "tags_any": ["..."],
        "location_any": ["..."],
        "need_relief_min": {{"need_thirst": 0.05}},
        "world_state_decrease_min": {{"kitchen_counter_wet": 0.10}},
        "require_patch_ok": true
      }},
      "tag_hint": "drink|eat|tidy|rest|observe|plan|..."
    }}
  ],
  "rationale": "一句话"
}}
""".strip()

        return [
            {"role": "system", "content": system},
            {"role": "user", "content": f"生成 {ts} 的新目标JSON。"}
        ]

    def _rule_generate(self, current_concerns: list, ts: str) -> List[Goal]:
        if not current_concerns:
            return []
        top = max(current_concerns, key=lambda cc: getattr(cc, "tension", 0.0))
        g = Goal(
            current_concern_id=getattr(top, "cc_id", ""),
            deep_concern_id=getattr(top, "deep_concern_id", ""),
            title=f"推进：{getattr(top,'title','')[:40]}（一小步）",
            description="规则fallback生成",
            success_criteria="完成一个明确的30秒行动，并能观察到相关状态变化",
            priority=0.5,
            next_action="选一个与当前关切相关且可执行的微行动",
            evidence_requirements={"tags_any": ["observe"], "require_patch_ok": False},
            source="rule_fallback",
            created_ts=ts,
            last_touched_ts=ts,
        )
        self.add(g)
        return [g]

    # -------------------------
    # attention/prompt helpers
    # -------------------------

    def active_goals(self, top_k: int = None, cc_tension_by_id: Optional[Dict[str, float]] = None) -> List[Goal]:
        if top_k is None:
            top_k = int(getattr(cfg, "GOAL_MAX_ACTIVE", 10))
        cc_tension_by_id = cc_tension_by_id or {}

        active = [g for g in self.goals if g.status == "active"]
        active.sort(
            key=lambda g: g.bid(cc_tension=cc_tension_by_id.get(g.current_concern_id, 0.5)),
            reverse=True
        )
        return active[:top_k]

    def to_prompt_text(self, top_k: int = 8) -> str:
        lines = ["[活跃目标]（进度必须有证据，不允许空口推进）"]
        for g in self.active_goals(top_k=top_k):
            lines.append(
                f"  {g.goal_id} cc={g.current_concern_id} deep={g.deep_concern_id} "
                f"pr={g.priority:.2f} prog={g.progress:.2f} st={g.status} | {g.title}"
            )
            if g.next_action:
                lines.append(f"    → next: {g.next_action}")
            if g.blocked_reason:
                lines.append(f"    × blocked: {g.blocked_reason[:120]}")
        return "\n".join(lines)


def _safe_extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    s, e = text.find("{"), text.rfind("}")
    if s >= 0 and e > s:
        try:
            return json.loads(text[s:e + 1])
        except Exception:
            return {}
    return {}