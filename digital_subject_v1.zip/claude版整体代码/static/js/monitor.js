// ===== 运行监控页面交互逻辑 =====

let updateInterval = null;
let startTime = null;

document.addEventListener('DOMContentLoaded', () => {
    loadAgentStatus();
    startAutoUpdate();
});

// 自动更新
function startAutoUpdate() {
    updateInterval = setInterval(() => {
        loadAgentStatus();
    }, 2000); // 每2秒更新一次
}

// 加载主体状态
async function loadAgentStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        updateStatusBadge(data.is_running);
        updateStats(data);
        updateRecentActions(data.recent_actions || []);
        updateNeeds(data.needs || []);
        updateAttention(data.attention || {});
        updateSystemInfo(data.system_info || {});
        
    } catch (error) {
        console.error('获取状态失败:', error);
    }
}

// 更新状态标签
function updateStatusBadge(isRunning) {
    const badge = document.getElementById('status-badge');
    const statusText = document.getElementById('status-text');
    
    if (isRunning) {
        badge.className = 'status-badge running';
        statusText.textContent = '运行中';
        document.getElementById('btn-start').disabled = true;
        document.getElementById('btn-pause').disabled = false;
    } else {
        badge.className = 'status-badge stopped';
        statusText.textContent = '已停止';
        document.getElementById('btn-start').disabled = false;
        document.getElementById('btn-pause').disabled = true;
    }
}

// 更新统计卡片
function updateStats(data) {
    // 运行时长
    if (data.start_time) {
        const now = new Date();
        const start = new Date(data.start_time);
        const diff = Math.floor((now - start) / 1000);
        const hours = Math.floor(diff / 3600);
        const minutes = Math.floor((diff % 3600) / 60);
        const seconds = diff % 60;
        document.getElementById('runtime').textContent = 
            `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    document.getElementById('tick-count').textContent = data.tick_count || 0;
    document.getElementById('location').textContent = data.location || 'unknown';
    document.getElementById('active-concerns').textContent = data.active_concerns || 0;
}

// 更新最近行动
function updateRecentActions(actions) {
    const container = document.getElementById('recent-actions');
    if (actions.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted); font-size: 0.9rem;">暂无行动记录</p>';
        return;
    }
    
    container.innerHTML = actions.map(action => `
        <div style="padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.05);">
            <span style="color: var(--text-muted); font-size: 0.85rem;">${action.ts}</span>
            <span style="color: var(--primary-cyan); font-weight: 500; margin: 0 8px;">[${action.tag}]</span>
            <span style="color: var(--text-secondary);">${action.summary}</span>
        </div>
    `).join('');
}

// 更新需求状态
function updateNeeds(needs) {
    const container = document.getElementById('needs-status');
    if (needs.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted);">暂无数据</p>';
        return;
    }
    
    container.innerHTML = needs.map(need => `
        <div style="margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: var(--text-secondary); font-size: 0.9rem;">${need.name}</span>
                <span style="color: var(--primary-cyan); font-weight: 600;">${(need.level * 100).toFixed(0)}%</span>
            </div>
            <div style="height: 6px; background: rgba(255,255,255,0.08); border-radius: 3px; overflow: hidden;">
                <div style="height: 100%; background: linear-gradient(90deg, var(--primary-cyan), var(--primary-pink)); width: ${need.level * 100}%; transition: width 0.3s ease;"></div>
            </div>
        </div>
    `).join('');
}

// 更新注意焦点
function updateAttention(attention) {
    const container = document.getElementById('attention-focus');
    if (!attention.top_foci || attention.top_foci.length === 0) {
        container.innerHTML = '<p style="color: var(--text-muted);">暂无焦点数据</p>';
        return;
    }
    
    container.innerHTML = `
        <div style="margin-bottom: 12px;">
            <strong style="color: var(--text-primary);">冲突：</strong>
            <span style="color: var(--text-secondary);">${attention.conflict_description || '无'}</span>
        </div>
        ${attention.top_foci.map((focus, i) => `
            <div style="padding: 8px; background: rgba(255,255,255,0.03); border-radius: 8px; margin-bottom: 8px;">
                <div style="display: flex; justify-content: between;">
                    <span style="color: var(--primary-cyan);">#${i + 1}</span>
                    <span style="color: var(--text-primary); margin-left: 8px;">${focus.label}</span>
                    <span style="margin-left: auto; color: var(--text-muted); font-size: 0.85rem;">占比 ${(focus.share * 100).toFixed(1)}%</span>
                </div>
            </div>
        `).join('')}
    `;
}

// 更新系统信息
function updateSystemInfo(info) {
    if (info.config_path) document.getElementById('config-path').textContent = info.config_path;
    if (info.state_path) document.getElementById('state-path').textContent = info.state_path;
    if (info.last_save) document.getElementById('last-save').textContent = info.last_save;
}

// 启动主体
async function startAgent() {
    if (!confirm('确定要启动数字主体吗？')) return;
    
    try {
        const response = await fetch('/api/start', { method: 'POST' });
        if (response.ok) {
            showToast('主体已启动', 'success');
            loadAgentStatus();
        } else {
            throw new Error('启动失败');
        }
    } catch (error) {
        showToast('启动失败: ' + error.message, 'error');
    }
}

// 暂停主体
async function pauseAgent() {
    try {
        const response = await fetch('/api/pause', { method: 'POST' });
        if (response.ok) {
            showToast('主体已暂停', 'success');
            loadAgentStatus();
        } else {
            throw new Error('暂停失败');
        }
    } catch (error) {
        showToast('暂停失败: ' + error.message, 'error');
    }
}

// 重置主体
async function resetAgent() {
    if (!confirm('⚠️ 警告：这将清除所有运行状态、记忆和目标！\n关切配置将保留。\n\n确定要重置吗？')) return;
    
    try {
        const response = await fetch('/api/reset', { method: 'POST' });
        if (response.ok) {
            showToast('主体已重置', 'success');
            setTimeout(() => loadAgentStatus(), 1000);
        } else {
            throw new Error('重置失败');
        }
    } catch (error) {
        showToast('重置失败: ' + error.message, 'error');
    }
}

// 导出状态
async function exportState() {
    try {
        const response = await fetch('/api/export');
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `agent_state_${new Date().toISOString()}.zip`;
        a.click();
        showToast('状态已导出', 'success');
    } catch (error) {
        showToast('导出失败: ' + error.message, 'error');
    }
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}