// ===== 配置页面交互逻辑 =====

document.addEventListener('DOMContentLoaded', () => {
    loadCurrentConfig();
    initRangeListeners();
});

// 加载当前配置
async function loadCurrentConfig() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();
        
        // 填充表单
        for (const [key, value] of Object.entries(config)) {
            const element = document.getElementById(key);
            if (element) {
                element.value = value;
            }
        }
    } catch (error) {
        console.error('加载配置失败:', error);
    }
}

// 监听range输入，实时更新显示值
function initRangeListeners() {
    const boredomRange = document.getElementById('stuck_boredom');
    const boredomValue = document.getElementById('boredom-value');
    
    boredomRange.addEventListener('input', (e) => {
        boredomValue.textContent = parseFloat(e.target.value).toFixed(2);
    });
}

// 恢复默认配置
function loadDefaults() {
    if (!confirm('确定要恢复默认配置吗？')) return;
    
    const defaults = {
        tick_sec: 30,
        world_observe_every: 3,
        goal_gen_every: 20,
        memory_consolidate_every: 60,
        working_mem_capacity: 7,
        episodic_hot_keep: 200,
        semantic_keep: 300,
        attention_top_k: 3,
        concern_max_active: 6,
        goal_max_active: 10,
        stuck_repeat_tag: 3,
        stuck_no_progress: 20,
        stuck_boredom: 0.78
    };
    
    for (const [key, value] of Object.entries(defaults)) {
        const element = document.getElementById(key);
        if (element) {
            element.value = value;
        }
    }
    
    document.getElementById('boredom-value').textContent = '0.78';
    showToast('已恢复默认配置', 'success');
}

// 表单提交
document.getElementById('config-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        tick_sec: parseInt(document.getElementById('tick_sec').value),
        world_observe_every: parseInt(document.getElementById('world_observe_every').value),
        goal_gen_every: parseInt(document.getElementById('goal_gen_every').value),
        memory_consolidate_every: parseInt(document.getElementById('memory_consolidate_every').value),
        working_mem_capacity: parseInt(document.getElementById('working_mem_capacity').value),
        episodic_hot_keep: parseInt(document.getElementById('episodic_hot_keep').value),
        semantic_keep: parseInt(document.getElementById('semantic_keep').value),
        attention_top_k: parseInt(document.getElementById('attention_top_k').value),
        concern_max_active: parseInt(document.getElementById('concern_max_active').value),
        goal_max_active: parseInt(document.getElementById('goal_max_active').value),
        stuck_repeat_tag: parseInt(document.getElementById('stuck_repeat_tag').value),
        stuck_no_progress: parseInt(document.getElementById('stuck_no_progress').value),
        stuck_boredom: parseFloat(document.getElementById('stuck_boredom').value)
    };
    
    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            showToast('配置保存成功', 'success');
        } else {
            throw new Error('保存失败');
        }
    } catch (error) {
        showToast('保存失败: ' + error.message, 'error');
    }
});

// Toast提示
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}