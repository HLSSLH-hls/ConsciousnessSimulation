// ===== 人格配置页面交互逻辑 =====

let concernCounter = 0;
let semanticCounter = 0;

document.addEventListener('DOMContentLoaded', () => {
    loadPersonalityData();
    initNeedRanges();
});

// 初始化need滑块监听
function initNeedRanges() {
    document.querySelectorAll('.need-range').forEach(range => {
        const valueSpan = range.nextElementSibling;
        range.addEventListener('input', (e) => {
            valueSpan.textContent = parseFloat(e.target.value).toFixed(2);
        });
    });
}

// 加载人格数据
async function loadPersonalityData() {
    try {
        const response = await fetch('/api/personality');
        const data = await response.json();
        
        // 填充identity
        document.getElementById('identity').value = data.identity || '';
        
        // 填充needs
        if (data.needs) {
            data.needs.forEach(need => {
                const range = document.querySelector(`.need-range[data-need="${need.id.replace('need_', '')}"]`);
                if (range) {
                    range.value = need.level;
                    range.nextElementSibling.textContent = need.level.toFixed(2);
                }
            });
        }
        
        // 填充concerns
        if (data.concerns && data.concerns.length > 0) {
            data.concerns.forEach(concern => addConcern(concern));
        } else {
            loadDefaultConcerns();
        }
        
        // 填充semantic
        if (data.semantic && data.semantic.length > 0) {
            data.semantic.forEach(sem => addSemantic(sem));
        }
        
    } catch (error) {
        console.error('加载人格数据失败:', error);
        loadDefaultConcerns();
    }
}

// 默认关切
function loadDefaultConcerns() {
    const defaults = [
        {
            title: "保持身体不难受、能撑得住",
            domain: "wellbeing",
            importance: 0.85,
            is_core: true,
            description: "吃饱、喝够、厕所、休息——基本生理不拖欠"
        },
        {
            title: "屋里屋外有个体面秩序",
            domain: "order",
            importance: 0.65,
            is_core: true,
            description: "东西归位、不乱、能找到——心里才踏实"
        },
        {
            title: "脑子里的事别一直搅",
            domain: "meaning",
            importance: 0.60,
            is_core: false,
            description: "反复冒出来的念头——要么记下来要么想清楚，别让它空转"
        },
        {
            title: "跟人的关系别断了、别生分",
            domain: "social",
            importance: 0.50,
            is_core: false,
            description: "家人、邻居——不用天天联系，但别让关系冷掉"
        }
    ];
    
    defaults.forEach(concern => addConcern(concern));
}

// 添加关切
function addConcern(data = null) {
    const container = document.getElementById('concerns-container');
    const id = concernCounter++;
    
    const concernDiv = document.createElement('div');
    concernDiv.className = 'glass-card';
    concernDiv.style.marginBottom = '16px';
    concernDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 16px;">
            <h3 style="margin: 0;">关切 #${id + 1}</h3>
            <button type="button" class="btn btn-danger" onclick="this.closest('.glass-card').remove()" style="padding: 6px 12px; font-size: 0.85rem;">删除</button>
        </div>
        <div class="form-group">
            <label class="form-label">标题</label>
            <input type="text" class="form-input concern-title" value="${data?.title || ''}" placeholder="例：保持身体不难受">
        </div>
        <div class="form-group">
            <label class="form-label">描述</label>
            <textarea class="form-textarea concern-description" rows="2" placeholder="详细说明这个关切...">${data?.description || ''}</textarea>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group" style="margin: 0;">
                <label class="form-label">领域</label>
                <select class="form-select concern-domain">
                    <option value="wellbeing" ${data?.domain === 'wellbeing' ? 'selected' : ''}>健康/身体</option>
                    <option value="order" ${data?.domain === 'order' ? 'selected' : ''}>秩序/整洁</option>
                    <option value="social" ${data?.domain === 'social' ? 'selected' : ''}>社交/关系</option>
                    <option value="meaning" ${data?.domain === 'meaning' ? 'selected' : ''}>意义/理解</option>
                    <option value="safety" ${data?.domain === 'safety' ? 'selected' : ''}>安全/稳定</option>
                    <option value="growth" ${data?.domain === 'growth' ? 'selected' : ''}>成长/探索</option>
                </select>
            </div>
            <div class="form-group" style="margin: 0;">
                <label class="form-label">重要度</label>
                <input type="range" class="form-range concern-importance" value="${data?.importance || 0.6}" min="0" max="1" step="0.05">
                <span class="range-value">${(data?.importance || 0.6).toFixed(2)}</span>
            </div>
        </div>
        <div class="form-group">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                <input type="checkbox" class="concern-core" ${data?.is_core ? 'checked' : ''}>
                <span class="form-label" style="margin: 0;">核心关切（不可退役）</span>
            </label>
        </div>
    `;
    
    // 添加range监听
    const range = concernDiv.querySelector('.concern-importance');
    const valueSpan = range.nextElementSibling;
    range.addEventListener('input', (e) => {
        valueSpan.textContent = parseFloat(e.target.value).toFixed(2);
    });
    
    container.appendChild(concernDiv);
}

// 添加语义记忆
function addSemantic(data = null) {
    const container = document.getElementById('semantic-container');
    const id = semanticCounter++;
    
    const semDiv = document.createElement('div');
    semDiv.className = 'glass-card';
    semDiv.style.marginBottom = '16px';
    semDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 16px;">
            <h3 style="margin: 0;">信念 #${id + 1}</h3>
            <button type="button" class="btn btn-danger" onclick="this.closest('.glass-card').remove()" style="padding: 6px 12px; font-size: 0.85rem;">删除</button>
        </div>
        <div class="form-group">
            <label class="form-label">信念内容</label>
            <input type="text" class="form-input semantic-claim" value="${data?.claim || ''}" placeholder="例：整理小件东西能让心里安静下来">
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
            <div class="form-group" style="margin: 0;">
                <label class="form-label">置信度</label>
                <input type="range" class="form-range semantic-confidence" value="${data?.confidence || 0.6}" min="0" max="1" step="0.05">
                <span class="range-value">${(data?.confidence || 0.6).toFixed(2)}</span>
            </div>
            <div class="form-group" style="margin: 0;">
                <label class="form-label">领域</label>
                <select class="form-select semantic-domain">
                    <option value="general" ${data?.domain === 'general' ? 'selected' : ''}>一般</option>
                    <option value="body" ${data?.domain === 'body' ? 'selected' : ''}>身体</option>
                    <option value="social" ${data?.domain === 'social' ? 'selected' : ''}>社交</option>
                    <option value="environment" ${data?.domain === 'environment' ? 'selected' : ''}>环境</option>
                </select>
            </div>
        </div>
    `;
    
    // 添加range监听
    const range = semDiv.querySelector('.semantic-confidence');
    const valueSpan = range.nextElementSibling;
    range.addEventListener('input', (e) => {
        valueSpan.textContent = parseFloat(e.target.value).toFixed(2);
    });
    
    container.appendChild(semDiv);
}

// 恢复默认人格
function loadDefaultPersonality() {
    if (!confirm('确定要恢复默认人格配置吗？当前配置将被清空。')) return;
    
    // 清空concerns和semantic
    document.getElementById('concerns-container').innerHTML = '';
    document.getElementById('semantic-container').innerHTML = '';
    concernCounter = 0;
    semanticCounter = 0;
    
    // 恢复默认
    document.getElementById('identity').value = '你是一个"意识转移后的个体"。生前是农村老人，朴实谨慎，重视身体舒服、日常秩序与体面。你以30秒为单位持续运行，会在需要与长期关切之间竞争注意，产生微行动。你不能使用互联网/真实外部工具。';
    loadDefaultConcerns();
    
    showToast('已恢复默认人格配置', 'success');
}

// 表单提交
document.getElementById('personality-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // 收集needs
    const needs = {};
    document.querySelectorAll('.need-range').forEach(range => {
        const needId = 'need_' + range.dataset.need;
        needs[needId] = parseFloat(range.value);
    });
    
    // 收集concerns
    const concerns = [];
    document.querySelectorAll('#concerns-container .glass-card').forEach(card => {
        concerns.push({
            title: card.querySelector('.concern-title').value,
            description: card.querySelector('.concern-description').value,
            domain: card.querySelector('.concern-domain').value,
            importance: parseFloat(card.querySelector('.concern-importance').value),
            is_core: card.querySelector('.concern-core').checked
        });
    });
    
    // 收集semantic
    const semantic = [];
    document.querySelectorAll('#semantic-container .glass-card').forEach(card => {
        semantic.push({
            claim: card.querySelector('.semantic-claim').value,
            confidence: parseFloat(card.querySelector('.semantic-confidence').value),
            domain: card.querySelector('.semantic-domain').value
        });
    });
    
    const data = {
        identity: document.getElementById('identity').value,
        needs: needs,
        concerns: concerns,
        semantic: semantic
    };
    
    try {
        const response = await fetch('/api/personality', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            showToast('人格配置保存成功', 'success');
        } else {
            throw new Error('保存失败');
        }
    } catch (error) {
        showToast('保存失败: ' + error.message, 'error');
    }
});

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}