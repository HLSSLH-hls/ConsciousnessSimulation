# app.py - Flask后端完整实现

from flask import Flask, render_template, request, jsonify, send_file
import json
import os
from datetime import datetime
from config_manager import ConfigManager
from agent_controller import controller

app = Flask(__name__)

# ===== 页面路由 =====

@app.route('/')
def index():
    """首页重定向到监控页面"""
    return render_template('monitor.html')

@app.route('/config')
def config_page():
    """系统配置页面"""
    return render_template('config.html')

@app.route('/personality')
def personality_page():
    """人格配置页面"""
    return render_template('personality.html')

@app.route('/monitor')
def monitor_page():
    """运行监控页面"""
    return render_template('monitor.html')


# ===== API端点 =====

@app.route('/api/config', methods=['GET'])
def get_config():
    """
    读取当前系统配置
    从config.py读取所有可配置参数
    """
    config_data = ConfigManager.load_system_config()
    return jsonify(config_data)

@app.route('/api/config', methods=['POST'])
def save_config():
    """
    保存系统配置
    验证参数合法性并写入config.py
    """
    data = request.get_json()
    
    # 参数验证
    validations = {
        'tick_sec': (10, 120),
        'world_observe_every': (1, 10),
        'goal_gen_every': (5, 60),
        'memory_consolidate_every': (20, 200),
        'working_mem_capacity': (5, 12),
        'episodic_hot_keep': (50, 500),
        'semantic_keep': (100, 1000),
        'attention_top_k': (2, 8),
        'concern_max_active': (3, 10),
        'goal_max_active': (5, 20),
        'stuck_repeat_tag': (2, 6),
        'stuck_no_progress': (10, 50),
        'stuck_boredom': (0.5, 1.0),
    }
    
    for key, (min_val, max_val) in validations.items():
        if key in data:
            value = data[key]
            if not (min_val <= value <= max_val):
                return jsonify({
                    'success': False,
                    'message': f'{key} 必须在 {min_val} 到 {max_val} 之间'
                }), 400
    
    # 保存配置
    success = ConfigManager.save_system_config(data)
    
    if success:
        # 如果主体正在运行，提示需要重启
        warning = ''
        if controller.running:
            warning = '配置已保存，但需要重启主体才能生效'
        
        return jsonify({
            'success': True,
            'message': '配置已保存' + (f'（{warning}）' if warning else '')
        })
    else:
        return jsonify({
            'success': False,
            'message': '保存配置失败'
        }), 500

@app.route('/api/personality', methods=['GET'])
def get_personality():
    """
    读取人格配置
    包括identity、needs初始值、concerns、semantic
    """
    personality_data = ConfigManager.load_personality()
    return jsonify(personality_data)

@app.route('/api/personality', methods=['POST'])
def save_personality():
    """
    保存人格配置
    更新concerns.json、core_state.json、semantic.json、config.py
    """
    data = request.get_json()
    
    # 验证必要字段
    if 'concerns' in data:
        if not isinstance(data['concerns'], list):
            return jsonify({
                'success': False,
                'message': 'concerns必须是数组'
            }), 400
        
        for c in data['concerns']:
            if 'title' not in c or not c['title'].strip():
                return jsonify({
                    'success': False,
                    'message': '每个关切必须有标题'
                }), 400
    
    # 检查主体是否正在运行
    if controller.running:
        return jsonify({
            'success': False,
            'message': '请先停止主体再修改人格配置'
        }), 400
    
    # 保存
    success = ConfigManager.save_personality(data)
    
    if success:
        return jsonify({
            'success': True,
            'message': '人格配置已保存'
        })
    else:
        return jsonify({
            'success': False,
            'message': '保存失败'
        }), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    """
    获取主体当前运行状态
    包括tick计数、位置、需求、注意焦点等
    """
    status = controller.get_status()
    return jsonify(status)

@app.route('/api/start', methods=['POST'])
def start_agent():
    """
    启动数字主体
    在独立线程中运行main.py主循环
    """
    result = controller.start()
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/pause', methods=['POST'])
def pause_agent():
    """
    暂停数字主体
    设置停止标志，等待当前tick完成
    """
    result = controller.pause()
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/reset', methods=['POST'])
def reset_agent():
    """
    重置数字主体
    清除运行状态，保留concerns等人格配置
    """
    result = controller.reset()
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 500

@app.route('/api/export', methods=['GET'])
def export_state():
    """
    导出完整状态
    打包agent_state目录为zip文件
    """
    zip_path = controller.export_state()
    
    if zip_path and os.path.exists(zip_path):
        return send_file(
            zip_path,
            as_attachment=True,
            download_name=os.path.basename(zip_path),
            mimetype='application/zip'
        )
    else:
        return jsonify({
            'success': False,
            'message': '导出失败'
        }), 500


# ===== 错误处理 =====

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Not Found'}), 404

@app.errorhandler(500)
def internal_error(e):
    return jsonify({'error': 'Internal Server Error'}), 500


if __name__ == '__main__':
    # 确保必要目录存在
    os.makedirs('./agent_state', exist_ok=True)
    os.makedirs('./agent_state/memory', exist_ok=True)
    
    print("=" * 60)
    print("数字主体生活模拟 - Web控制台")
    print("=" * 60)
    print("访问地址: http://localhost:5000")
    print("配置页面: http://localhost:5000/config")
    print("人格配置: http://localhost:5000/personality")
    print("运行监控: http://localhost:5000/monitor")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)